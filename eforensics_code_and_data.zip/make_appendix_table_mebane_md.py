import pandas as pd
import numpy as np

df = pd.read_csv('appendix_mebane_md_results.csv')
df['elec'] = df['elec'].astype(str)

elec_label = {'pres16':'Pres02','pres17':'Pres07','18':'Gen08','19':'Gen12','pres18':'Pres12',
              '20':'Gen16','pres19':'Pres17','21':'Gen20','pres20':'Pres22','22':'Gen24','pres21':'Pres25'}
src_label = {'real':'real','marginal_null':'marg.null','joint_null':'joint.null'}
lvl_label = {'dong': 'dong', 'constituency': 'const.'}

def esc(s):
    return str(s).replace('_', '-')

def fmt_md(m, d):
    if pd.isna(m) or pd.isna(d):
        return '--'
    flag = '$^{\\dagger}$' if (m > 0.01 and d < 0.05) else ''
    return f"{m:.4f}/{d:.3f}{flag}"

def make_table(sub, caption, label):
    lines = []
    lines.append(r"{\footnotesize")
    lines.append(r"\begin{longtable}{p{0.9cm}p{0.8cm}p{1.3cm}p{1.15cm}p{1.9cm}p{1.9cm}p{1.9cm}}")
    lines.append(rf"\caption{{{caption}}} \label{{{label}}} \\")
    lines.append(r"\toprule")
    lines.append(r"Elec. & Level & Channel & Source & $M_1$/$D_1$ (no-fraud) & $M_2$/$D_2$ (incr.) & $M_3$/$D_3$ (extr.) \\")
    lines.append(r"\midrule")
    lines.append(r"\endfirsthead")
    lines.append(rf"\multicolumn{{7}}{{c}}{{\tablename\ \thetable{{}} -- continued}} \\")
    lines.append(r"\toprule")
    lines.append(r"Elec. & Level & Channel & Source & $M_1$/$D_1$ (no-fraud) & $M_2$/$D_2$ (incr.) & $M_3$/$D_3$ (extr.) \\")
    lines.append(r"\midrule")
    lines.append(r"\endhead")
    lines.append(r"\bottomrule")
    lines.append(r"\endfoot")
    for _, row in sub.iterrows():
        e = elec_label.get(row['elec'], row['elec'])
        lvl = lvl_label.get(row['level'], row['level'])
        ch = esc(row['channel'])
        src = src_label.get(row['source'], row['source'])
        c1 = fmt_md(row['M1'], row['D1'])
        c2 = fmt_md(row['M2'], row['D2'])
        c3 = fmt_md(row['M3'], row['D3'])
        lines.append(f"{e} & {lvl} & {ch} & {src} & {c1} & {c2} & {c3} \\\\")
    lines.append(r"\end{longtable}")
    lines.append(r"}")
    return '\n'.join(lines)

blocks = []
specs = [
    ('previous_settings', 'dem', "Mebane (2023) multimodality diagnostics, long-chain configuration, Democratic-coded leader. Each cell reports $M(\\pi_j)$ (largest cross-chain gap in chain-specific posterior means) and $D(\\pi_j)$ (Hartigan dip-test $p$-value on pooled draws) for each mixture component $j$. $^{\\dagger}$ marks $M>0.01$ with $D<0.05$, the threshold Mebane (2023) treats as a substantive multimodality signal.", "tab:app_md_prev_dem"),
    ('previous_settings', 'con', "Mebane (2023) multimodality diagnostics, long-chain configuration, conservative-coded leader (partial).", "tab:app_md_prev_con"),
    ('new_settings', 'dem', "Mebane (2023) multimodality diagnostics, short-chain configuration, Democratic-coded leader. Full coverage, all 11 elections.", "tab:app_md_new_dem"),
    ('new_settings', 'con', "Mebane (2023) multimodality diagnostics, short-chain configuration, conservative-coded leader. Full coverage, all 11 elections.", "tab:app_md_new_con"),
]
for dataset, leader, caption, label in specs:
    sub = df[(df['dataset']==dataset) & (df['leader_side']==leader)].copy()
    elec_order = ['18','19','pres16','pres17','pres18','20','pres19','21','pres20','22','pres21']
    sub['eo'] = sub['elec'].map({e:i for i,e in enumerate(elec_order)})
    so = {'real':0,'marginal_null':1,'joint_null':2}
    sub['so'] = sub['source'].map(so)
    sub = sub.sort_values(['eo','level','channel','so'])
    blocks.append(make_table(sub, caption, label))
    print(f"{dataset}/{leader}: {len(sub)} rows")

open('appendix_tables_mebane_md.tex', 'w').write('\n\n\\newpage\n\n'.join(blocks))
print("Written appendix_tables_mebane_md.tex")
