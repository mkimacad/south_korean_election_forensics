#!/bin/bash
# Runs mebane_self_null_pipeline.py (R/JAGS-only) across every
# election/level/channel/leader_side cell, parallelized by spawning multiple
# independent subprocesses concurrently -- NOT batching. Each cell is still
# its own completely separate, un-batched two-stage run (own tempdirs, own
# eforensics() calls, own chains); we're just running several of them AT THE
# SAME TIME as separate OS processes. Mirrors
# run_mebane_r_all_parallel_bidirectional.sh as closely as possible; see that
# script's header for the concurrency/resumability notes, which all apply
# here unchanged.
#
# NOT A "SOURCE": unlike the real/marginal_null/joint_null sweep, there is no
# SOURCES loop here -- every cell is the manuscript's model-consistent
# self-null: (1) fit qbl to the REAL data for that
# election/level/channel/leader_side to harvest its class-1 hyperparameters,
# then (2) simulate a synthetic dataset from those hyperparameters with pi
# forced to (1,0,0) and fit qbl to that. Both stages happen inside a single
# mebane_self_null_pipeline.py invocation, so each cell costs ~2x an ordinary
# single-source cell (real-data fit + refit on the synthetic data).
#
# SEEDING: the self-null simulation step is stochastic. Each cell gets a
# deterministic seed derived from its own cell name (an md5-based hash), so
# a rerun of a specific cell reproduces the same synthetic draw, while
# different cells never accidentally share a seed.
#
# BIDIRECTIONAL: as in the base script, each cell is indexed by leader_side
# ('dem' or 'con'). Controlled by LEADER_SIDES (space-separated, default
# "dem con" here -- both sides, since the self-null grid is meant to check
# both codings from the start):
#   - leader_side=dem -> logs go to output_data/mebane_r_all_logs/<cell>.log
#     (no filename suffix)
#   - leader_side=con -> logs go to output_data/con_leader/<cell>_con.log
#     (separate directory, _con filename suffix)
#
# Usage:
#   ./run_mebane_self_null_parallel.sh                    <- full grid, all 11 elections, dem+con
#   ./run_mebane_self_null_parallel.sh "21 22"             <- just these elections
#   ./run_mebane_self_null_parallel.sh "21" "dong"         <- just this election, this level
#   LEADER_SIDES="con" ./run_mebane_self_null_parallel.sh "pres18 pres17 pres20"
#                                                            <- con-leader only, selected elections
#   MAX_PARALLEL=4 ./run_mebane_self_null_parallel.sh       <- override concurrency (lower default than
#                                                              the base script, since each cell here does 2 fits)
#   FORCE_RERUN=1 ./run_mebane_self_null_parallel.sh "21"  <- ignore existing logs, rerun anyway
#
# Province grouping: 'original' (~17-18 provinces, DEFAULT) or 'megaregion' (4 groups),
# via MEBANE_PROVINCE_GROUPING -- e.g. MEBANE_PROVINCE_GROUPING=megaregion ./run_mebane_self_null_parallel.sh

set -e

ELECTIONS="${1:-21 22 pres20 pres21 18 19 20 pres16 pres17 pres18 pres19}"
LEVELS="${2:-dong constituency}"
# NOTE: 20 (20th general, 2016) removed from NO_EARLY -- the early/sameday/
# pooled/total channel breakdown for that election is now available (the
# earlier archive only had total_no_early for it), so it takes the same
# early-voting-era channel set as 21/22/pres19/pres20/pres21.
NO_EARLY="18 19 pres16 pres17 pres18"
DONG_CHANNELS="early sameday pooled"
CONST_CHANNELS="early early_out early_total sameday total"
LEADER_SIDES="${LEADER_SIDES:-dem con}"   # space-separated subset of: dem con

# R/JAGS fit settings (kept at the settings established as sufficient --
# see the manuscript's convergence discussion: 3-5x more iterations produced
# no significant R-hat improvement, so there is no reason to pay 2x-per-cell
# self-null costs at the longer settings too).
R_N_ITER="${R_N_ITER:-1000}"
R_N_CHAINS="${R_N_CHAINS:-4}"
R_BURN_IN="${R_BURN_IN:-300}"
USE_PARCOMP="${USE_PARCOMP:-0}"   # see concurrency note in the base script -- default OFF

# Base seed; each cell's actual seed is SEED_BASE + a hash of its own cell
# name (see seed_for below), so it's deterministic per-cell rather than
# dependent on launch order.
SEED_BASE="${SEED_BASE:-0}"

# Set to 1 to relaunch cells even if a non-empty log already exists for them.
FORCE_RERUN="${FORCE_RERUN:-0}"

# How many cells to run concurrently. Each cell here does TWO qbl fits
# (real-data fit + self-null refit), so this defaults lower than the base
# script's MAX_PARALLEL=4 -- override via MAX_PARALLEL=N.
MAX_PARALLEL="${MAX_PARALLEL:-2}"

PIPELINE_SCRIPT="mebane_self_null_pipeline.py"

is_no_early() {
  case " $NO_EARLY " in
    *" $1 "*) return 0 ;;
    *) return 1 ;;
  esac
}

# Log directory + filename suffix for a given leader_side: dem -> no suffix,
# con -> a _con filename suffix, each in its own directory. Same directories
# as the base script -- self-null cells are distinguished by "model_self_null"
# in the filename itself, not by a separate directory.
log_dir_for() {
  case "$1" in
    dem) echo "output_data/mebane_r_all_logs" ;;
    con) echo "output_data/con_leader" ;;
    *) echo "run_mebane_self_null_parallel.sh: unknown leader_side '$1' (expected dem or con)" >&2; exit 1 ;;
  esac
}
suffix_for() {
  case "$1" in
    dem) echo "" ;;
    con) echo "_con" ;;
    *) echo "run_mebane_self_null_parallel.sh: unknown leader_side '$1' (expected dem or con)" >&2; exit 1 ;;
  esac
}

# Deterministic per-cell seed: SEED_BASE + (low 6 hex digits of md5(cell) as
# a decimal number, mod 100000). Stable across reruns of the same cell name;
# effectively distinct across different cell names.
seed_for() {
  local cell="$1"
  local hex; hex="$(printf '%s' "$cell" | md5sum | cut -c1-6)"
  echo $(( SEED_BASE + 16#$hex % 100000 ))
}

for ls in $LEADER_SIDES; do
  case "$ls" in
    dem|con) ;;
    *) echo "Invalid LEADER_SIDES entry '$ls' -- must be 'dem' and/or 'con'." >&2; exit 1 ;;
  esac
  mkdir -p "$(log_dir_for "$ls")" "$(log_dir_for "$ls")/.summary_snippets"
done

echo "Model-consistent self-null sweep: LEADER_SIDES='$LEADER_SIDES', MAX_PARALLEL=$MAX_PARALLEL, "
echo "USE_PARCOMP=$USE_PARCOMP, R_N_ITER=$R_N_ITER, R_N_CHAINS=$R_N_CHAINS, R_BURN_IN=$R_BURN_IN, SEED_BASE=$SEED_BASE, "
echo "FORCE_RERUN=$FORCE_RERUN"
echo ""

n_launched=0
n_skipped=0
t_start=$(date +%s)

# Each background job: run one cell (both stages), write its own log AND its
# own summary snippet (avoids concurrent-write races on a shared file --
# snippets get concatenated into the final summary only after all jobs finish).
run_one_cell() {
  local e="$1" level="$2" ch="$3" leader_side="$4"
  local log_dir; log_dir="$(log_dir_for "$leader_side")"
  local suffix; suffix="$(suffix_for "$leader_side")"
  local cell="${e}_${level}_${ch}_model_self_null${suffix}"
  local log_path="${log_dir}/${cell}.log"
  local status_path="${log_dir}/.status_selfnull"
  local snippet_path="${log_dir}/.summary_snippets/${cell}.snippet"
  local seed; seed="$(seed_for "$cell")"

  if python3 "$PIPELINE_SCRIPT" "$e" "$level" "$ch" "$leader_side" \
        "$R_N_ITER" "$R_N_CHAINS" "$R_BURN_IN" "$USE_PARCOMP" "$seed" \
        > "$log_path" 2>&1; then
    echo "OK    -> $cell (seed=$seed)" >> "$status_path"
  else
    echo "FAILED -> $cell (seed=$seed)" >> "$status_path"
  fi

  {
    echo "=== $cell (leader=$leader_side, seed=$seed) ==="
    awk '/^RESULT:/{flag=1} flag; /^END:/{flag=0}' "$log_path"
    echo ""
  } > "$snippet_path"
}
# NOTE: same as the base script -- no `export -f`/`export VAR` needed, since
# run_one_cell is backgrounded (`&`) within THIS SAME bash process. Requires
# bash specifically (not POSIX sh) for `wait -n` / `jobs -r -p`; invoke as
# `./run_mebane_self_null_parallel.sh` or `bash run_mebane_self_null_parallel.sh`,
# never `sh run_mebane_self_null_parallel.sh`.

# Record an already-completed cell (skip case) straight into this run's
# status + snippet files, using the EXISTING log's own RESULT/END block.
record_skipped_cell() {
  local e="$1" level="$2" ch="$3" leader_side="$4" log_path="$5"
  local log_dir; log_dir="$(log_dir_for "$leader_side")"
  local suffix; suffix="$(suffix_for "$leader_side")"
  local cell="${e}_${level}_${ch}_model_self_null${suffix}"
  local status_path="${log_dir}/.status_selfnull"
  local snippet_path="${log_dir}/.summary_snippets/${cell}.snippet"

  echo "SKIP  -> $cell (log already exists, $(wc -c < "$log_path") bytes)" >> "$status_path"
  {
    echo "=== $cell (leader=$leader_side) [SKIPPED -- pre-existing log] ==="
    awk '/^RESULT:/{flag=1} flag; /^END:/{flag=0}' "$log_path"
    echo ""
  } > "$snippet_path"
}

# Reset status + wipe stale self-null snippets per leader_side up front. Only
# this run's OWN cell files (matching *_model_self_null*.snippet) are wiped,
# so the real/marginal_null/joint_null snippets from the base script are left
# untouched -- both sweeps' snippets can coexist in the same .summary_snippets
# directory.
for ls in $LEADER_SIDES; do
  log_dir="$(log_dir_for "$ls")"
  : > "${log_dir}/.status_selfnull"
  rm -f "${log_dir}/.summary_snippets"/*_model_self_null*.snippet 2>/dev/null || true
done

for ls in $LEADER_SIDES; do
  for e in $ELECTIONS; do
    for level in $LEVELS; do
      if is_no_early "$e"; then
        channels="total_no_early"
      elif [ "$level" = "dong" ]; then
        channels="$DONG_CHANNELS"
      else
        channels="$CONST_CHANNELS"
      fi

      for ch in $channels; do
        log_dir="$(log_dir_for "$ls")"
        suffix="$(suffix_for "$ls")"
        cell="${e}_${level}_${ch}_model_self_null${suffix}"
        log_path="${log_dir}/${cell}.log"

        if [ "$FORCE_RERUN" != "1" ] && [ -s "$log_path" ]; then
          # Non-empty log already present -> treat as complete, skip relaunch.
          record_skipped_cell "$e" "$level" "$ch" "$ls" "$log_path"
          n_skipped=$((n_skipped+1))
          elapsed=$(( $(date +%s) - t_start ))
          echo "[skip -> $cell already has a log ($(wc -c < "$log_path") bytes); $n_skipped skipped so far, ${elapsed}s elapsed]"
          continue
        fi
        # A 0-byte (or missing) log is NOT treated as done -- a hung/killed
        # JAGS run at either stage looks like this, and will be relaunched.

        run_one_cell "$e" "$level" "$ch" "$ls" &
        n_launched=$((n_launched+1))

        # Concurrency limit: wait for at least one running job to finish
        # before launching more, once MAX_PARALLEL is reached.
        while [ "$(jobs -r -p | wc -l)" -ge "$MAX_PARALLEL" ]; do
          wait -n
        done

        elapsed=$(( $(date +%s) - t_start ))
        echo "[$n_launched launched, $n_skipped skipped, ${elapsed}s elapsed, $(jobs -r -p | wc -l) currently running]"
      done
    done
  done
done

echo ""
echo "All cells launched -- waiting for the remaining running jobs to finish..."
wait

total_elapsed=$(( $(date +%s) - t_start ))
echo ""
echo "Complete: $n_launched launched (new/rerun), $n_skipped skipped (pre-existing logs), ${total_elapsed}s total wall time."
echo ""

# Per-leader-side tallies + combined summary file (self-null cells only).
for ls in $LEADER_SIDES; do
  log_dir="$(log_dir_for "$ls")"
  summary_file="${log_dir}/mebane_self_null_summary.txt"
  n_done=$(grep -c "^OK" "${log_dir}/.status_selfnull" 2>/dev/null || true); n_done="${n_done:-0}"
  n_failed=$(grep -c "^FAILED" "${log_dir}/.status_selfnull" 2>/dev/null || true); n_failed="${n_failed:-0}"
  n_skip_ls=$(grep -c "^SKIP" "${log_dir}/.status_selfnull" 2>/dev/null || true); n_skip_ls="${n_skip_ls:-0}"

  : > "$summary_file"
  for snippet in "${log_dir}/.summary_snippets"/*_model_self_null*.snippet; do
    [ -e "$snippet" ] || continue
    cat "$snippet" >> "$summary_file"
  done

  echo "leader_side=$ls : $n_done newly OK, $n_failed FAILED, $n_skip_ls skipped (pre-existing)."
  echo "  Per-cell logs: $log_dir/ (files matching *_model_self_null*.log)"
  echo "  Combined summary: $summary_file"
  if [ "$n_failed" -gt 0 ]; then
    echo "  Failed cells:"
    grep "^FAILED" "${log_dir}/.status_selfnull" | sed 's/^FAILED -> /    /'
  fi
done

# --- fast first check instead of the full grid, e.g.: ----------------------
# MAX_PARALLEL=1 LEADER_SIDES="con" ./run_mebane_self_null_parallel.sh "pres18" "dong"
