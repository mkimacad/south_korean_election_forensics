#!/usr/bin/env python3
"""
mebane_self_null_pipeline.py

Implements the model-consistent self-null described in the manuscript
(Section "Confirmation with the model's own no-fraud process: the
self-null"): simulates data from the fitted qbl model's own class-1
data-generating equations with pi forced to (1,0,0), to isolate whether
false positives stem specifically from clean-class misspecification.

This is deliberately a THIRD null generator, separate from
generate_marginal_null / generate_joint_null in mebane_r_pipeline_bidirectional.py.
Those two match the *data's* turnout/vote-share marginals (or province means
plus a pooled covariance) using ad hoc Beta/Gaussian noise chosen by us. This
generator instead draws from the *model's own* posterior class-1 ("no
fraud") data-generating equations -- the same equations eforensics' qbl JAGS
model uses internally for units it classifies as clean -- with every unit
forced into that class by construction (pi = (1,0,0) exactly, not merely
close to it). If eforensics still reports substantial "fraud" on data drawn
from its own no-fraud process, that is the sharpest possible demonstration
that clean-class misspecification (not the choice of null generator) is
driving the false-positive rate.

Two-stage procedure per cell:
  Stage 1 (fit): run mebane_crosscheck_selfnull_fit.R on the REAL data to
      obtain posterior medians of the class-1 hyperparameters (province
      vectors beta.tau1/beta.nu1, random-intercept means tau_alpha/nu_alpha,
      random-intercept variances tb/nb). This is a real qbl fit, so it costs
      the same as any other real-data run in this study.
  Stage 2 (simulate + refit): use those hyperparameters to simulate a
      class-1-only synthetic dataset (generate_model_self_null), then fit
      qbl to that synthetic dataset exactly as done for marginal_null /
      joint_null, using the ordinary mebane_crosscheck.R script.

Total cost per cell is therefore ~2x a single ordinary fit (one real fit to
harvest hyperparameters, one fit on the resulting synthetic data) -- there is
no way around this, since the whole point is to use the *fitted* model's own
parameters rather than assumed ones.

Usage (mirrors mebane_r_pipeline_bidirectional.py's CLI, with a trailing
seed in place of the "source" argument that pipeline uses -- there is no
"source" here, every cell is fit from real data and then self-null-refit):
    python3 mebane_self_null_pipeline.py <elec_id> <level> <channel> <leader_side> \
        [r_n_iter] [r_n_chains] [r_burn_in] [use_parcomp] [seed]

    python3 mebane_self_null_pipeline.py pres18 dong total_no_early con
    python3 mebane_self_null_pipeline.py 21 constituency early dem 1000 4 300 FALSE 7

Requires mebane_r_pipeline_bidirectional.py and mebane_crosscheck_selfnull_fit.R
in the same directory as this script (or on PYTHONPATH), and
mebane_crosscheck.R (the original, unmodified script) available via
mebane_r_pipeline_bidirectional.R_SCRIPT_PATH.
"""

import os
import sys
import subprocess
import tempfile
import time

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mebane_r_pipeline_bidirectional as base  # noqa: E402

SELFNULL_FIT_R_SCRIPT_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), 'mebane_crosscheck_selfnull_fit.R'
)


# ============================================================================
# Stage 1: fit qbl to real data, harvesting class-1 hyperparameters
# ============================================================================

def run_r_model_selfnull_fit(df, r_n_iter=1000, r_n_chains=4, r_burn_in=300,
                              use_parcomp=False, work_dir=None):
    """Same contract as base.run_r_model, but calls
    mebane_crosscheck_selfnull_fit.R and also returns the parsed
    hyperparameters and the prov_code -> design-matrix-position mapping."""
    if base.shutil.which('Rscript') is None:
        raise FileNotFoundError("run_r_model_selfnull_fit: 'Rscript' not found on PATH.")

    work_dir = work_dir or tempfile.mkdtemp(prefix='mebane_selfnull_fit_')
    input_path = os.path.join(work_dir, 'input.csv')
    output_path = os.path.join(work_dir, 'output.csv')
    units_path = os.path.join(work_dir, 'output_units.csv')
    hyper_path = os.path.join(work_dir, 'output_hyperparams.csv')
    levels_path = os.path.join(work_dir, 'output_provlevels.csv')

    required = ['leader_votes', 'total_votes', 'eligible', 'prov_code']
    df[required].to_csv(input_path, index=False)

    argv = ['Rscript', SELFNULL_FIT_R_SCRIPT_PATH, input_path, output_path,
            str(r_n_iter), str(r_n_chains), str(r_burn_in),
            'TRUE' if use_parcomp else 'FALSE']

    print(f"[run_r_model_selfnull_fit] {' '.join(argv)}")
    t0 = time.time()
    result = subprocess.run(argv, capture_output=True, text=True)
    elapsed = time.time() - t0

    print(result.stdout)
    if result.returncode != 0:
        raise RuntimeError(f"R script crashed: {result.stderr}")

    summary = pd.read_csv(output_path).iloc[0].to_dict()
    units = pd.read_csv(units_path)
    hyper_df = pd.read_csv(hyper_path)
    hyper_map = dict(zip(hyper_df['param'], hyper_df['median']))
    levels_df = pd.read_csv(levels_path)  # columns: position, prov_code (ascending)

    n_tau = sum(1 for k in hyper_map if k.startswith('beta_tau1_'))
    n_nu = sum(1 for k in hyper_map if k.startswith('beta_nu1_'))
    hyperparams = {
        'beta_tau1': [hyper_map[f'beta_tau1_{i}'] for i in range(1, n_tau + 1)],
        'beta_nu1': [hyper_map[f'beta_nu1_{i}'] for i in range(1, n_nu + 1)],
        'tau_alpha': hyper_map['tau_alpha'],
        'nu_alpha': hyper_map['nu_alpha'],
        'tb': hyper_map['tb'],
        'nb': hyper_map['nb'],
        'prov_levels_ascending': levels_df['prov_code'].tolist(),  # position i -> prov_code
    }
    return summary, units, hyperparams, elapsed


# ============================================================================
# Stage 2: simulate the model-consistent self-null
# ============================================================================

def generate_model_self_null(real_sub, hyperparams, seed=1):
    """Simulate synthetic (leader_votes, total_votes) from the qbl model's
    own class-1 ("no fraud") generative equations, using posterior-median
    hyperparameters fit to real_sub, with every unit forced into class 1
    (pi = (1, 0, 0) exactly, by construction rather than by approximation).

    Replicates, unit by unit, the qbl JAGS model's Z==1 branch:
        omt[j]    = inprod(Xa[j,], beta.tau1)
        th[j]     ~ Normal(tau_alpha, sd = sqrt(tb))
        mu.tau[j] = ilogit(th[j] + omt[j])
        a[j]      ~ Binomial(N[j], 1 - mu.tau[j])

        omn[j]    = inprod(Xw[j,], beta.nu1)
        nh[j]     ~ Normal(nu_alpha, sd = sqrt(nb))
        mu.nu[j]  = ilogit(nh[j] + omn[j])
        w[j]      ~ Binomial(N[j], mu.nu[j] * (1 - a[j]/N[j]))

    NOTE: uses beta_tau1/beta_nu1 (the raw province design-matrix
    coefficients), NOT beta_tau/beta_nu (the combined vector reported
    elsewhere in this pipeline, which overwrites position 1 with
    tau_alpha/nu_alpha for a different purpose -- see the header comment in
    mebane_crosscheck_selfnull_fit.R). Getting this reversed silently
    produces a self-null with the wrong location and would look like a
    bug-shaped repeat of the marginal/joint null story rather than an actual
    test of clean-class misspecification.
    """
    rng = np.random.default_rng(seed)
    n = len(real_sub)

    prov_code = real_sub['prov_code'].values.astype(int)
    levels_ascending = np.array(hyperparams['prov_levels_ascending'], dtype=int)
    beta_tau1 = np.asarray(hyperparams['beta_tau1'], dtype=float)
    beta_nu1 = np.asarray(hyperparams['beta_nu1'], dtype=float)

    if len(levels_ascending) != len(beta_tau1) or len(levels_ascending) != len(beta_nu1):
        raise ValueError(
            f"Province level count ({len(levels_ascending)}) doesn't match "
            f"beta_tau1 ({len(beta_tau1)}) / beta_nu1 ({len(beta_nu1)}) length. "
            "This dataset's prov_code values must match exactly what stage 1 "
            "was fit on (same real_sub, not a re-derived or re-filtered copy)."
        )

    # position 1 = reference level, contributes only the intercept coefficient
    # (R's default treatment contrasts); positions 2.. are one-hot dummies.
    omt = np.full(n, beta_tau1[0], dtype=float)
    omn = np.full(n, beta_nu1[0], dtype=float)
    for pos in range(1, len(levels_ascending)):
        mask = prov_code == levels_ascending[pos]
        omt[mask] += beta_tau1[pos]
        omn[mask] += beta_nu1[pos]

    tau_alpha = float(hyperparams['tau_alpha'])
    nu_alpha = float(hyperparams['nu_alpha'])
    tb = float(hyperparams['tb'])
    nb = float(hyperparams['nb'])

    th = rng.normal(tau_alpha, np.sqrt(max(tb, 1e-9)), size=n)
    nh = rng.normal(nu_alpha, np.sqrt(max(nb, 1e-9)), size=n)

    mu_tau = 1.0 / (1.0 + np.exp(-(th + omt)))
    mu_nu = 1.0 / (1.0 + np.exp(-(nh + omn)))

    N = real_sub['eligible'].values.astype(int)
    N = np.maximum(N, 1)

    p_a = np.clip(1.0 - mu_tau, 1e-9, 1 - 1e-9)
    a = rng.binomial(N, p_a)  # abstentions

    p_w = np.clip(mu_nu * (1.0 - a / N), 1e-9, 1 - 1e-9)
    w = rng.binomial(N, p_w)  # leader votes

    sim = real_sub.copy()
    sim['total_votes'] = N - a
    sim['leader_votes'] = w
    return sim


# ============================================================================
# Full cell driver
# ============================================================================

def fit_one_cell_selfnull(elec_id, level, channel, leader_side='dem',
                           r_n_iter=1000, r_n_chains=4, r_burn_in=300,
                           use_parcomp=False, seed=1):
    if leader_side not in ('dem', 'con'):
        raise ValueError(f"leader_side must be 'dem' or 'con', got '{leader_side}'")

    if level == 'dong':
        df = base.load_pure_unit_table(elec_id, channel, leader_side=leader_side)
    else:
        df = base.load_pure_constituency_table(elec_id, channel, leader_side=leader_side)
    if df.empty:
        raise ValueError(f"No data matching criteria: {elec_id}/{level}/{channel}/{leader_side}")

    cell_tag = f"{elec_id}/{level}/{channel}/model_self_null/leader={leader_side}"

    print(f"\n{'=' * 70}\n[self_null] STAGE 1/2 (fit real data, harvest class-1 hyperparameters): "
          f"{cell_tag}  N={len(df)}\n{'=' * 70}")
    _, _, hyperparams, elapsed_fit = run_r_model_selfnull_fit(
        df, r_n_iter=r_n_iter, r_n_chains=r_n_chains, r_burn_in=r_burn_in, use_parcomp=use_parcomp
    )

    sim = generate_model_self_null(df, hyperparams, seed=seed)

    print(f"\n{'=' * 70}\n[self_null] STAGE 2/2 (fit qbl to the self-null synthetic data): "
          f"{cell_tag}  N={len(sim)}\n{'=' * 70}")
    summary, units, elapsed_refit = base.run_r_model(
        sim, r_n_iter=r_n_iter, r_n_chains=r_n_chains, r_burn_in=r_burn_in, use_parcomp=use_parcomp
    )

    total_elapsed = elapsed_fit + elapsed_refit
    summary['elapsed_seconds_stage1_fit'] = elapsed_fit
    summary['elapsed_seconds_stage2_refit'] = elapsed_refit
    summary['elapsed_seconds_total'] = total_elapsed
    return summary, units, hyperparams, total_elapsed


# ============================================================================
# CLI
# ============================================================================

if __name__ == '__main__':
    if len(sys.argv) < 5 or len(sys.argv) > 10:
        print(__doc__)
        sys.exit(1)

    elec_id_arg, level_arg, channel_arg, leader_side_arg = sys.argv[1:5]
    r_n_iter_arg = int(sys.argv[5]) if len(sys.argv) >= 6 else 1000
    r_n_chains_arg = int(sys.argv[6]) if len(sys.argv) >= 7 else 4
    r_burn_in_arg = int(sys.argv[7]) if len(sys.argv) >= 8 else 300
    use_parcomp_arg = sys.argv[8].strip().upper() == 'TRUE' if len(sys.argv) >= 9 else False
    seed_arg = int(sys.argv[9]) if len(sys.argv) >= 10 else 1

    result_summary, result_units, hyper, total_time = fit_one_cell_selfnull(
        elec_id_arg, level_arg, channel_arg, leader_side=leader_side_arg,
        r_n_iter=r_n_iter_arg, r_n_chains=r_n_chains_arg, r_burn_in=r_burn_in_arg,
        use_parcomp=use_parcomp_arg, seed=seed_arg
    )

    print(f"\n{'-' * 70}")
    print(f"RESULT: {elec_id_arg}/{level_arg}/{channel_arg}/model_self_null/leader={leader_side_arg}")
    print(f"{'-' * 70}")
    print(f"p_no_fraud_median      : {result_summary.get('p_no_fraud_median'):.4f}")
    print(f"p_incremental_median   : {result_summary.get('p_incremental_median'):.4f}")
    print(f"p_extreme_median       : {result_summary.get('p_extreme_median'):.4f}")
    fraud_share = result_summary.get('p_incremental_median', 0) + result_summary.get('p_extreme_median', 0)
    print(f"fraud_share_median     : {fraud_share:.4f}")
    print(f"rhat_pi                : {result_summary.get('rhat_pi')}")
    print(f"n_regions_flagged      : {result_summary.get('n_regions_flagged')}/{result_summary.get('total_units')}")
    print(f"elapsed_seconds (total, fit+refit): {total_time:.1f}")
    print(f"{'-' * 70}\n")
