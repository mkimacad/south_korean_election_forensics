#!/bin/bash
# run_psrf_dong.sh
#
# The PSRF stopping-rule check at DONG level (run_psrf_constituency.sh covers
# the constituency level). Every dong cell is re-run with the package's PSRF
# stopping rule in place of its default per-chain MCSE rule:
#
#     eforensics(..., autoConv = TRUE, mcmc.conv.diagnostic = "PSRF", max.auto = MAX_AUTO)
#
# After the initial run the chains are extended (burn-in + n.iter more
# iterations each time) until psrf < 1.05 for every pi component, up to
# MAX_AUTO times, and a further n.iter draws are then kept.
#
# Scope: 23 dong cells (6 early-voting-era elections x 3 channels + 5
# pre-early-voting elections x 1 channel) x 3 sources (real, marginal null,
# joint null) x leader codings = 138 runs for dem+con.
#
# COST: dong cells have 2,700-3,600 units (constituency: 198-253), and a run
# that exhausts all MAX_AUTO=10 extensions performs roughly twelve times as many
# iterations as a short-chain run. Expect this to take far longer than the
# constituency check, and more memory per run (the per-unit latent turnout and
# leader share are monitored for the fraudulent-vote counts).
#
# Logs go to output_data_v2_psrf_dong/ (separate from the constituency check).
# Parse them with:   python3 parse_psrf_logs.py output_data_v2_psrf_dong psrf_dong_results.csv
#
# Resumable: cells whose log already exists and is non-empty are skipped.
# Do NOT edit any .R/.py/.sh file in this directory while this is running.
#
# Usage:
#   ./run_psrf_dong.sh                          <- all elections, dem + con, 8 cells at a time
#   LEADER_SIDES=dem ./run_psrf_dong.sh         <- Democratic-coded only (69 runs)
#   ./run_psrf_dong.sh "pres18 21"              <- selected elections
#   MAX_PARALLEL=4 ./run_psrf_dong.sh           <- fewer concurrent runs (e.g. to limit memory)

set -e
cd "$(dirname "$0")"

ELECTIONS="${1:-21 22 pres20 pres21 18 19 20 pres16 pres17 pres18 pres19}"

# ---- preflight: current code only ----
fail=0
need() { grep -q "$2" "$1" 2>/dev/null || { echo "PREFLIGHT FAIL: $1 lacks '$2' ($3)"; fail=1; }; }
need mebane_crosscheck.R 'EFORENSICS_CONV' "PSRF stopping-rule switch"
need mebane_crosscheck.R 'fraud_votes_definition = "model"' "model-consistent fraudulent-vote counts"
need mebane_r_driver_bidirectional.py 'fraud_votes_definition' "driver prints the F definition"
[ -x run_mebane_r_all_parallel_bidirectional.sh ] || { echo "PREFLIGHT FAIL: run_mebane_r_all_parallel_bidirectional.sh missing or not executable"; fail=1; }
[ "$fail" = 0 ] || { echo "Aborting: fix the problems above first."; exit 1; }

export EFORENSICS_CONV=psrf
export EFORENSICS_WFORM="${EFORENSICS_WFORM:-conditional}"
export EFORENSICS_MAX_AUTO="${MAX_AUTO:-10}"
export R_N_ITER="${R_N_ITER:-1000}"
export R_BURN_IN="${R_BURN_IN:-300}"
export R_N_ADAPT="${R_N_ADAPT:-1000}"
export R_N_CHAINS="${R_N_CHAINS:-4}"
export OUT_SUFFIX="${OUT_SUFFIX:-_v2_psrf_dong}"
export MAX_PARALLEL="${MAX_PARALLEL:-8}"
export LEADER_SIDES="${LEADER_SIDES:-dem con}"

echo "After the first runs, confirm the logs contain 'Stopping rule: PSRF' and 'Convergence diagnostic: PSRF'."
echo "PSRF dong sweep: elections='$ELECTIONS', leader=$LEADER_SIDES, max.auto=$EFORENSICS_MAX_AUTO, n.iter=$R_N_ITER, burn-in=$R_BURN_IN, parallel=$MAX_PARALLEL -> output_data${OUT_SUFFIX}/"
exec ./run_mebane_r_all_parallel_bidirectional.sh "$ELECTIONS" "dong"
