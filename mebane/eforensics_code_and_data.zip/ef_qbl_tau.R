## ============================================================================
## ef_qbl_tau.R
##
## Fork of the eforensics "qbl" model that writes the leader-vote probability
## in terms of the LATENT turnout tau_i (the package's mu.tau[j]) instead of
## the realized abstention count a[j]/N[j]. This is the manuscript's equation
## for w_i^* (Ferrari, McAlister and Mebane 2018, eq. 2) used directly as the
## likelihood, rather than its conditional rewriting (their eq. 3), which is
## what the package implements.
##
## ONLY ONE STATEMENT CHANGES. In the package's qbl JAGS code,
##
##   p.w[j] = (Z==1) * mu.nu * (1 - a/N)
##          + (Z==2) * [ mu.nu*((1-iota.s)/(1-iota.m))*(1-iota.m-a/N)
##                       + a/N*((iota.m-iota.s)/(1-iota.m)) + iota.s ]
##          + (Z==3) * [ same with chi ]
##
## becomes
##
##   p.w[j] = (Z==1) * mu.tau*mu.nu
##          + (Z==2) * [ mu.tau*mu.nu + iota.m*(1-mu.tau) + iota.s*mu.tau*(1-mu.nu) ]
##          + (Z==3) * [ mu.tau*mu.nu + chi.m *(1-mu.tau) + chi.s *mu.tau*(1-mu.nu) ]
##
## Priors, fraud proportions, p.a[j], and both binomial likelihood lines are
## untouched. The two forms describe the same data-generating mechanism; they
## differ in that the observed-turnout form evaluates the leader-vote probability
## at the turnout implied by the realized abstentions, whereas this form
## evaluates it at the latent turnout, so A_i and W_i are conditionally
## independent given the latent variables and mu.tau enters BOTH likelihood
## terms (in the observed-turnout form it enters only p.a).
##
## HOW IT IS WIRED IN. The model string is generated at run time from the
## installed package's own qbl() by replacing the p.w statement, so every
## other line stays identical to whatever version is installed. It is then
## swapped into the package namespace with assignInNamespace(), so that
## eforensics(model = "qbl") runs it with the package's own data
## preparation, MCMC and auto-convergence loop, monitoring and fraud
## post-processing unchanged. The name must stay "qbl": the package keys its
## monitored-parameter list and its per-unit fraud monitors on that name.
##
## If the installed package's p.w statement does not match the expected text
## exactly once, activate_tau_form() stops with an error rather than running
## a silently different model.
## ============================================================================

QBL_TAU_PW <- paste0(
  "  p.w[j]  = (Z[j] == 1) * ( mu.tau[j] * mu.nu[j] ) +\n",
  "  (Z[j] == 2) * ( mu.tau[j] * mu.nu[j] + iota.m[j] * (1 - mu.tau[j]) + iota.s[j] * mu.tau[j] * (1 - mu.nu[j]) ) +\n",
  "  (Z[j] == 3) * ( mu.tau[j] * mu.nu[j] + chi.m[j]  * (1 - mu.tau[j]) + chi.s[j]  * mu.tau[j] * (1 - mu.nu[j]) )\n")

## Replace the p.w statement (from "p.w[j]" up to, not including, "## Likelihood").
make_qbl_tau_string <- function(qbl_string) {
  pat <- "  p\\.w\\[j\\]  = \\(Z\\[j\\] == 1\\) \\* \\( mu\\.nu\\[j\\] \\* \\(1 - a\\[j\\]/N\\[j\\]\\) \\) \\+[^#]*?(?=\\n  \\n  ## Likelihood)"
  hits <- gregexpr(pat, qbl_string, perl = TRUE)[[1]]
  if (length(hits) != 1 || hits[1] == -1) {
    stop("ef_qbl_tau.R: expected exactly one observed-turnout p.w statement in qbl(); found ",
         ifelse(hits[1] == -1, 0, length(hits)),
         ". The installed eforensics version differs from the one this fork was written for.")
  }
  out <- sub(pat, sub("\n$", "", QBL_TAU_PW), qbl_string, perl = TRUE)
  if (grepl("a\\[j\\]/N\\[j\\]", out)) stop("ef_qbl_tau.R: a[j]/N[j] still present after replacement.")
  out
}

## Swap the latent-turnout model into the eforensics namespace. Call once, before eforensics().
activate_tau_form <- function() {
  orig <- utils::getFromNamespace("qbl", "eforensics")
  tau_string <- make_qbl_tau_string(orig())
  utils::assignInNamespace("qbl", function() tau_string, ns = "eforensics")
  assign(".qbl_conditional_original", orig, envir = globalenv())
  cat("[ef_qbl_tau] eforensics 'qbl' now uses the LATENT-turnout (tau) form of p.w.\n")
  invisible(tau_string)
}

## Restore the package's original observed-turnout qbl.
deactivate_tau_form <- function() {
  if (exists(".qbl_conditional_original", envir = globalenv())) {
    utils::assignInNamespace("qbl", get(".qbl_conditional_original", envir = globalenv()), ns = "eforensics")
    cat("[ef_qbl_tau] eforensics 'qbl' restored to the observed-turnout form.\n")
  }
}
