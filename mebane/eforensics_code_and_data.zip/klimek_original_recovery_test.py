"""Parameter-recovery test for klimek_original.py (Klimek et al.'s own procedure),
on the same simulated cases as klimek_recovery_test.py, plus three cases at
n = 13,500 (the size of the 투표구-level datasets). Writes
klimek_original_output/klimek_original_recovery_results.csv."""
import os, sys, time
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import klimek_analysis as K
import klimek_original as KO

def simulate(n, fi, fe, theta, alpha, seed):
    r = np.random.default_rng(seed)
    tau = K.trunc_normal(r.random(n), 0.70, 0.07); nu = K.trunc_normal(r.random(n), 0.50, 0.10)
    u = r.random(n); x = K.half_normal_01(r.random(n), theta); y = K.half_normal_01(r.random(n), K.SIGMA_X)
    frac = np.where(u < fi, x, np.where(u < fi + fe, 1 - y, 0.0))
    a = (1 - frac) * (1 - tau); w = tau * nu + frac * (1 - tau) + np.where(frac > 0, frac ** alpha, 0) * (1 - nu) * tau
    t = 1 - a
    return t, np.clip(w / t, 0, 1)

if __name__ == '__main__':
    CASES = [(0, 0, .1, 1, 3500), (0.15, 0.03, 0.1, 1.0, 3500), (0.30, 0.0, 0.2, 0.75, 3500),
             (0, 0, .1, 1, 2700), (0.15, 0.03, 0.1, 1.0, 2700), (0, 0, .1, 1, 250), (0.10, 0.02, 0.1, 1.0, 250),
             (0, 0, .1, 1, 13500), (0.15, 0.03, 0.1, 1.0, 13500), (0.30, 0.0, 0.2, 0.75, 13500)]
    OUT = 'klimek_original_output/klimek_original_recovery_results.csv'
    os.makedirs('klimek_original_output', exist_ok=True)
    done = set()
    if os.path.exists(OUT):     # resumable: cases already present are skipped
        d0 = pd.read_csv(OUT)
        done = set(zip(d0.n, d0.true_fi, d0.true_fe))
    for fi, fe, th, al, n in CASES:
        if (n, fi, fe) in done:
            continue
        t, s = simulate(n, fi, fe, th, al, seed=11)
        t0 = time.time(); r = KO.estimate(t, s)
        row = dict(n=n, true_fi=fi, true_fe=fe, true_theta=th, true_alpha=al, fit_fi=r['fi'], fit_fi_sd=r['fi_sd'],
                   fit_fe=r['fe'], fit_fe_sd=r['fe_sd'], fit_alpha=r['alpha'], sigma_vR=r['sigma_vR'])
        pd.DataFrame([row]).to_csv(OUT, mode='a', header=not os.path.exists(OUT), index=False)
        print(f"true fi={fi:.2f} fe={fe:.2f} th={th} al={al} n={n} -> fi={r['fi']:.3f}({r['fi_sd']:.3f}) "
              f"fe={r['fe']:.3f}({r['fe_sd']:.3f}) alpha={r['alpha']:.2f} sigma_vR={r['sigma_vR']:.3f} [{time.time()-t0:.1f}s]",
              flush=True)
