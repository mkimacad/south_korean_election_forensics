#!/bin/bash
# run_psrf_constituency.sh
#
# Re-runs the eforensics sweep at CONSTITUENCY level only, for all eleven
# elections, with the package's PSRF stopping rule switched on in place of its
# default per-chain MCSE rule:
#
#     eforensics(..., autoConv = TRUE, mcmc.conv.diagnostic = "PSRF", max.auto = MAX_AUTO)
#
# i.e. after the initial run the chains are extended (burn-in + n.iter more
# iterations each time) until psrf < 1.05 for every pi component, up to
# MAX_AUTO times, and a further n.iter draws are then kept. The question this
# answers: does the package's own R-hat rule ever get satisfied if the chains
# are simply allowed to run longer, and do fraud shares change when it is?
#
# Why constituency only: 198-253 units per cell versus 2,700-3,600 at dong
# level. Under a rule that may exhaust all extensions, a single run can reach
# (MAX_AUTO + 2) x (burn-in + n.iter) iterations per chain; at dong level that
# is impractically slow.
#
# Scope: 35 constituency cells (6 early-voting-era elections x 5 channels +
# 5 pre-early-voting elections x 1 channel) x 3 sources (real, marginal null,
# joint null) x leader codings = 210 runs for dem+con.
#
# Starts from the short-chain configuration (n.iter = 1000, burn-in = 300,
# adaptation 1000), so with the default MAX_AUTO = 10 each chain can run up to
# roughly 15,000 iterations before the kept draws.
#
# Logs go to output_data_psrf/ (or output_data_tau_psrf/ if combined with
# EFORENSICS_WFORM=tau), so the published results in output_data/ are never
# overwritten. Parse them with parse_mebane_logs.py as usual. Each log records
# the rule in force in a "[R-Model] Stopping rule:" line and in the package's
# "Convergence diagnostic:" table; those are the durable record (the summary
# CSVs that also carry conv_rule are written to temporary directories).
#
# Usage:
#   ./run_psrf_constituency.sh                          <- all elections, dem + con
#   LEADER_SIDES=dem ./run_psrf_constituency.sh         <- Democratic-coded only (105 runs)
#   MAX_AUTO=20 ./run_psrf_constituency.sh              <- allow more extensions
#   ./run_psrf_constituency.sh "pres18 21"              <- selected elections
#   EFORENSICS_WFORM=tau ./run_psrf_constituency.sh     <- combine with the latent-turnout fork
#   MAX_PARALLEL=8 ./run_psrf_constituency.sh           <- concurrency (default 4)

set -e
cd "$(dirname "$0")"

ELECTIONS="${1:-21 22 pres20 pres21 18 19 20 pres16 pres17 pres18 pres19}"

export EFORENSICS_CONV=psrf
export EFORENSICS_MAX_AUTO="${MAX_AUTO:-10}"
export R_N_ITER="${R_N_ITER:-1000}"
export R_BURN_IN="${R_BURN_IN:-300}"
export R_N_ADAPT="${R_N_ADAPT:-1000}"
export R_N_CHAINS="${R_N_CHAINS:-4}"

# Pre-flight check: the PSRF switch lives in mebane_crosscheck.R. An older copy
# without it silently runs the package's default MCMCSE rule instead (this
# happened once: every log showed "Convergence diagnostic: MCMCSE").
if ! grep -q 'EFORENSICS_CONV' mebane_crosscheck.R; then
  echo "ERROR: mebane_crosscheck.R in $(pwd) has no EFORENSICS_CONV switch; it would run the"
  echo "       default MCMCSE rule, not PSRF. Copy the current mebane_crosscheck.R here first."
  exit 1
fi
echo "After the first runs, confirm the logs contain 'Stopping rule: PSRF' and 'Convergence diagnostic: PSRF'."

echo "PSRF constituency sweep: elections='$ELECTIONS', max.auto=$EFORENSICS_MAX_AUTO, n.iter=$R_N_ITER, burn-in=$R_BURN_IN"
exec ./run_mebane_r_all_parallel_bidirectional.sh "$ELECTIONS" "constituency"
