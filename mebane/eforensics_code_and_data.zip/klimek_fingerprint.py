#!/usr/bin/env python3
"""
klimek_fingerprint.py

A SEPARATE codebase from the eforensics analysis, implementing an approximate
version of the "election fingerprint" diagnostic of Klimek, Yegorov, Hanel &
Thurner (2012, PNAS) and its later formalizations (e.g. Kobak, Shpilkin &
Pshenichnikov). It does not call JAGS, does not fit any Bayesian model, and
does not use the eforensics R package at all -- it is a purely descriptive/
visual diagnostic over the joint (turnout, leader vote-share) distribution.

WHAT IT REUSES from the main study (by import, not reimplementation):
  - load_pure_unit_table / load_pure_constituency_table (unit-level tables)
  - generate_marginal_null / generate_joint_null (the two ad hoc fraud-free
    null generators used throughout the main paper)
from mebane_r_driver_bidirectional.py. This ensures the fingerprint diagnostic
is evaluated on EXACTLY the same real and null data as the eforensics results,
which is what makes the comparison meaningful.

WHAT IS NEW HERE:
  - A 2-D KDE "fingerprint" of (turnout, leader vote-share), the classic
    Klimek-style visualization.
  - A quantitative ROUND-NUMBER EXCESS-MASS statistic. The Klimek/Kobak
    signature is not "jointly elevated turnout and share" in general (which
    is what eforensics's mixture components flag, and what our nulls already
    reproduce) -- it is specifically density clustering at round-number
    turnout/vote-share combinations (multiples of 5 or 10 percentage points),
    a pattern ordinary voter/demographic heterogeneity has no obvious
    mechanical reason to produce. This script measures that signature
    directly, separately from any "joint elevation" measure.

This is a genuine approximation of the published diagnostic, not a literal
reimplementation of Klimek et al. (2012)'s or Kobak et al.'s exact estimator;
see the docstring of round_number_excess_mass() for the precise definition
used and how it differs from the entropy-based statistic in the later
Kobak/Shpilkin/Pshenichnikov formalization.

Usage:
    python3 klimek_fingerprint.py <elec_id> <level> <channel> [leader_side]

    python3 klimek_fingerprint.py 21 dong early dem
    python3 klimek_fingerprint.py pres18 constituency total_no_early con

Output: writes <elec_id>_<level>_<channel>_<leader_side>_fingerprint.csv
(one row per source: real, marginal_null, joint_null) with the round-number
excess-mass statistic and its bootstrap CI, plus a PNG of the three
fingerprint density plots side by side, to the current directory.

Requires: numpy, pandas, scipy, matplotlib. Does NOT require R, JAGS, or the
eforensics package.
"""
import os
import sys

import numpy as np
import pandas as pd
from scipy.stats import gaussian_kde

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mebane_r_driver_bidirectional as base  # noqa: E402  (reused, not reimplemented)


# ============================================================================
# The round-number excess-mass statistic
# ============================================================================

def round_number_excess_mass(tau, nu, grid_step=0.05, window=0.01, n_boot=500, seed=1):
    """Measure clustering of (tau, nu) pairs at round-number combinations.

    Definition: for each grid point (g_t, g_n) with g_t, g_n multiples of
    `grid_step` in (0, 1) (e.g. 0.05, 0.10, ..., 0.95 -- excluding the
    boundary grid points 0 and 1, which are structurally degenerate), count
    the fraction of units falling within `window` (in each coordinate,
    L-infinity ball) of that grid point. Compare this to the fraction that
    would fall in an equivalent-area window under a locally-flat null (i.e.
    proportional to (2*window)^2 relative to the unit square, scaled by a
    local-density correction using a leave-one-out Gaussian KDE evaluated at
    each grid point, so the statistic is not just re-detecting the ordinary
    joint elevation eforensics already flags). The final statistic is the
    sum, across grid points, of (observed count - expected count under the
    local KDE density) restricted to POSITIVE excesses only -- i.e. we count
    "extra" mass sitting on round numbers beyond what smooth local density
    predicts, and ignore round-number cells with a deficit.

    NOTE: this is deliberately a simpler, more transparent statistic than
    the entropy/bimodality measure used in Kobak, Shpilkin & Pshenichnikov's
    later formalization of the same idea. It targets the same substantive
    signature (excess mass ON round numbers specifically, not just in
    high-turnout/high-share regions generally) but should be read as an
    approximation suitable for a null-comparison exercise, not as a
    faithful reimplementation of any single published estimator.

    Returns dict with 'statistic', 'boot_lo', 'boot_hi' (percentile bootstrap
    CI over units, resampled with replacement, n_boot replicates).
    """
    tau = np.asarray(tau, dtype=float)
    nu = np.asarray(nu, dtype=float)
    n = len(tau)
    if n < 50:
        return {'statistic': np.nan, 'boot_lo': np.nan, 'boot_hi': np.nan, 'n': n}

    grid_vals = np.round(np.arange(grid_step, 1.0, grid_step), 4)
    kde = gaussian_kde(np.vstack([tau, nu]))

    def stat_for(t, v):
        total = 0.0
        for gt in grid_vals:
            for gn in grid_vals:
                observed = np.sum((np.abs(t - gt) <= window) & (np.abs(v - gn) <= window))
                local_density = kde((gt, gn))[0]
                expected = local_density * (2 * window) ** 2 * len(t)
                excess = observed - expected
                if excess > 0:
                    total += excess
        return total / len(t)  # normalize by sample size for cross-cell comparability

    point_stat = stat_for(tau, nu)

    rng = np.random.default_rng(seed)
    boot_stats = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, n, size=n)
        boot_stats[b] = stat_for(tau[idx], nu[idx])
    lo, hi = np.percentile(boot_stats, [2.5, 97.5])

    return {'statistic': point_stat, 'boot_lo': lo, 'boot_hi': hi, 'n': n}


# ============================================================================
# Fingerprint plotting
# ============================================================================

def plot_fingerprints(sources, out_path, title):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, len(sources), figsize=(5 * len(sources), 4.5), sharex=True, sharey=True)
    if len(sources) == 1:
        axes = [axes]
    for ax, (label, tau, nu) in zip(axes, sources):
        ax.hist2d(tau, nu, bins=80, range=[[0, 1], [0, 1]], cmap='viridis', cmin=1)
        ax.set_title(label)
        ax.set_xlabel('turnout')
    axes[0].set_ylabel('leader vote share')
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# ============================================================================
# Driver
# ============================================================================

def run_cell(elec_id, level, channel, leader_side='dem', seed=1):
    if level == 'dong':
        real = base.load_pure_unit_table(elec_id, channel, leader_side=leader_side)
    else:
        real = base.load_pure_constituency_table(elec_id, channel, leader_side=leader_side)
    if real.empty:
        raise ValueError(f"No data matching criteria: {elec_id}/{level}/{channel}/{leader_side}")

    marginal = base.generate_marginal_null(real, seed=seed)
    joint = base.generate_joint_null(real, seed=seed)

    rows = []
    plot_sources = []
    for label, df in [('real', real), ('marginal_null', marginal), ('joint_null', joint)]:
        tau = df['total_votes'].values / df['eligible'].values
        nu = np.divide(df['leader_votes'].values, df['total_votes'].values,
                        out=np.zeros_like(df['leader_votes'].values, dtype=float),
                        where=df['total_votes'].values > 0)
        res = round_number_excess_mass(tau, nu, seed=seed)
        res['source'] = label
        rows.append(res)
        plot_sources.append((label, tau, nu))

    out = pd.DataFrame(rows)[['source', 'statistic', 'boot_lo', 'boot_hi', 'n']]
    tag = f"{elec_id}_{level}_{channel}_{leader_side}"
    out.to_csv(f"{tag}_fingerprint.csv", index=False)
    plot_fingerprints(plot_sources, f"{tag}_fingerprint.png",
                       f"Election fingerprint: {elec_id}/{level}/{channel}/{leader_side}")
    return out


if __name__ == '__main__':
    if len(sys.argv) < 4:
        print(__doc__)
        sys.exit(1)
    elec_id_arg, level_arg, channel_arg = sys.argv[1:4]
    leader_side_arg = sys.argv[4] if len(sys.argv) > 4 else 'dem'
    result = run_cell(elec_id_arg, level_arg, channel_arg, leader_side=leader_side_arg)
    print(result.to_string(index=False))
