#!/usr/bin/env python3
"""
make_chainlength_check.py

Chain-length verification from the constituency-level PSRF check. Each PSRF run
is the same cell, data source and leader coding as a short-chain run, but its
chains are extended (burn-in + n.iter more iterations each time, up to
MAX_AUTO = 10 times) until PSRF < 1.05 for every mixture weight, and a fresh
n.iter draws are then kept. Comparing the two answers whether running the
chains much longer changes convergence or the fraud-share estimates.

Inputs : psrf_constituency_results.csv (parse_psrf_logs.py)
         appendix_full_results.csv      (collect_eforensics_results.py; short chain)
Outputs: fig_chainlength_psrf.pdf, chainlength_stats.txt
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

K = ['elec', 'level', 'channel', 'source', 'leader_side']
p = pd.read_csv('psrf_constituency_results.csv')
s = pd.read_csv('appendix_full_results.csv')
for d in (p, s):
    d['elec'] = d.elec.astype(str)
s = s[(s.dataset == 'new_settings') & (s.level == 'constituency')]
m = p.merge(s[K + ['fraud_share', 'rhat', 'elapsed']].rename(columns={'rhat': 'rhat_short', 'elapsed': 'elapsed_short'}),
            on=K, suffixes=('_psrf', '_short'))
if len(m) != len(p):
    raise SystemExit(f"{len(p) - len(m)} PSRF run(s) have no short-chain counterpart")

# Iterations per chain: short chain = burn-in 300 + 1000 kept. A PSRF run with e
# extensions = initial 300 + 1000, e x (300 + 1000), then 1000 kept.
m['iter_short'] = 1300
m['iter_psrf'] = 1300 + m.n_extensions * 1300 + 1000
out = []
P = out.append
met = m.pkg_converged
P(f"runs: {len(m)} ({m.groupby('leader_side').size().to_dict()})")
P(f"PSRF rule met: {int(met.sum())} ({100*met.mean():.1f}%), at first check: {int((met & (m.n_extensions == 0)).sum())}, "
  f"all 10 extensions used without meeting it: {int(((m.n_extensions == 10) & ~met).sum())}")
P(f"iterations per chain, runs that used all extensions: {int(m.iter_psrf.max())} vs {int(m.iter_short.iloc[0])} "
  f"short-chain ({m.iter_psrf.max() / m.iter_short.iloc[0]:.1f}x)")
P(f"median run-time ratio PSRF/short: {np.median(m.elapsed_seconds / m.elapsed_short):.1f}x")
P(f"max R-hat, median: short {m.rhat_short.median():.2f}, PSRF kept draws {m.rhat_kept.median():.2f}; "
  f"share <= 1.05: short {100*(m.rhat_short <= 1.05).mean():.1f}%, PSRF kept {100*(m.rhat_kept <= 1.05).mean():.1f}%")
P(f"R-hat lower after extension in {int((m.rhat_kept < m.rhat_short).sum())} of {len(m)} runs")
d = m.fraud_share_psrf - m.fraud_share_short
P(f"fraud share PSRF vs short: r={m.fraud_share_psrf.corr(m.fraud_share_short):.3f}, median |diff| "
  f"{100*np.median(abs(d)):.2f}pp, 90th pct |diff| {100*np.quantile(abs(d), .9):.2f}pp, max |diff| {100*abs(d).max():.1f}pp; "
  f"mean diff {100*d.mean():+.2f}pp")
nul = m.source != 'real'
P(f"null runs >5% fraud: short {int((m[nul].fraud_share_short > .05).sum())}/{int(nul.sum())}, "
  f"PSRF {int((m[nul].fraud_share_psrf > .05).sum())}/{int(nul.sum())}")
c = m[met]
P(f"runs meeting the rule: fraud share <=1% in {int((c.fraud_share_psrf <= .01).sum())} of {len(c)}, "
  f"max {100*c.fraud_share_psrf.max():.1f}% ({c.loc[c.fraud_share_psrf.idxmax(), K].tolist()})")
P(f"runs meeting the rule, short-chain R-hat median {c.rhat_short.median():.2f}; not meeting: {m[~met].rhat_short.median():.2f}")
open('chainlength_stats.txt', 'w').write("\n".join(out) + "\n")
print("\n".join(out))

plt.rcParams.update({'font.size': 9, 'font.family': 'serif'})
fig, ax = plt.subplots(1, 2, figsize=(9.4, 4.3))
for flag, col, mk, lab in ((False, '#7f7f7f', 'o', 'rule not met'), (True, '#1f4e79', 's', 'rule met')):
    q = m[met == flag]
    ax[0].scatter(100 * q.fraud_share_short, 100 * q.fraud_share_psrf, s=20, alpha=0.75, color=col, marker=mk,
                  label=f"{lab} (n={len(q)})")
    ax[1].scatter(q.rhat_short, q.rhat_kept, s=20, alpha=0.75, color=col, marker=mk, label=f"{lab} (n={len(q)})")
lim = 100 * max(m.fraud_share_short.max(), m.fraud_share_psrf.max()) * 1.05
ax[0].plot([0, lim], [0, lim], 'k--', lw=0.8); ax[0].set_xlim(0, lim); ax[0].set_ylim(0, lim)
ax[0].set_xlabel('fraud share, short chain (%)'); ax[0].set_ylabel('fraud share, extended chains (%)')
ax[0].set_title(f"Fraud share ($r$={m.fraud_share_psrf.corr(m.fraud_share_short):.2f})")
hi = max(m.rhat_short.max(), m.rhat_kept.max()) * 1.05
ax[1].plot([1, hi], [1, hi], 'k--', lw=0.8)
for f in (ax[1].axhline, ax[1].axvline):
    f(1.05, color='#c0392b', lw=0.8, ls=':')
ax[1].set_xscale('log'); ax[1].set_yscale('log'); ax[1].set_xlim(1, hi); ax[1].set_ylim(1, hi)
ticks = [t for t in (1, 1.05, 1.2, 1.5, 2, 3, 5, 10) if t <= hi]
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
for axis in (ax[1].xaxis, ax[1].yaxis):
    axis.set_major_locator(FixedLocator(ticks)); axis.set_major_formatter(FixedFormatter([f"{t:g}" for t in ticks]))
    axis.set_minor_locator(NullLocator())
ax[1].set_xlabel(r'max $\hat{R}$, short chain'); ax[1].set_ylabel(r'max $\hat{R}$, extended chains (kept draws)')
ax[1].set_title(r'Convergence ($\hat{R}=1.05$ dotted)')
for a in ax:
    a.legend(fontsize=7, loc='upper left')
fig.tight_layout(); fig.savefig('fig_chainlength_psrf.pdf')
print("wrote fig_chainlength_psrf.pdf and chainlength_stats.txt")
