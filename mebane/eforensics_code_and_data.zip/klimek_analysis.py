#!/usr/bin/env python3
"""
klimek_analysis.py

Full implementation of the election-fingerprint fraud model of Klimek,
Yegorov, Hanel & Thurner (2012, PNAS 109:16469), applied to exactly the same
real and fraud-free null datasets as the eforensics analysis.

WHAT IT DOES, for one election / level / channel / leader coding cell:

  1. FINGERPRINT. The 2-D histogram of unit turnout t_i = V_i / N_i against
     the leader's vote share s_i = W_i / V_i (Klimek et al.'s Figure 1).

  2. PARAMETRIC FRAUD-MODEL FIT (Klimek et al.'s model, as restated in
     Ferrari and Mebane 2017, Sec. 2.1). Each unit i, with observed N_i:
        true turnout      tau_i ~ N(tau, sd_tau)  truncated to (0,1)
        true leader share nu_i  ~ N(nu,  sd_nu)   truncated to (0,1)
        no fraud   (prob 1-f_i-f_e):  W = N tau nu,               A = N (1-tau)
        incremental(prob f_i): x ~ |N(0,theta)| on (0,1)
                   W = N (tau nu + x (1-tau) + x^alpha (1-nu) tau),  A = N (1-x)(1-tau)
        extreme    (prob f_e): y ~ |N(0,0.075)| on (0,1)
                   W = N (tau nu + (1-y)(1-tau) + (1-y)^alpha (1-nu) tau),  A = N y (1-tau)
     The clean-component parameters (tau, sd_tau, nu, sd_nu) and the fraud
     shape parameters (theta, alpha) are fitted jointly with the fraud
     fractions (f_i, f_e) by minimising the pointwise sum of squared
     differences between the observed and model-simulated 2-D fingerprints.
     THIS DEPARTS FROM KLIMEK ET AL.'S OWN PROCEDURE, which (their SI) plugs in
     the clean component (peaks and left-sided widths) and the incremental
     width (right-sided width sigma_vR), and picks f_i, f_e in {0,0.01,...,1}
     and alpha in {0,0.1,...,5} by minimising the relative statistic
     S = sum_i ((pdf(v_i) - pdf_model(v_i)) / pdf(v_i))^2 on the 1-D
     winner-vote distribution, averaged over 100 realizations. The fraud
     mechanisms themselves (x ~ |N(0,.)|, x^alpha, extreme width 0.075) are
     theirs. See the comment block above fit_klimek() for why the clean
     component is fitted rather than plugged in.
     The estimated fraud share f_i + f_e is the Klimek analogue of the
     eforensics fraud share pi_2 + pi_3.
     IDENTIFICATION (klimek_recovery_test.py): at dong scale (n in the
     thousands) extreme fraud f_e is recovered well; incremental fraud f_i
     is only weakly identified, trading off against theta and the clean
     spread, so each source is fitted under three simulation seeds and the
     median and range are reported. At constituency scale (n ~ 250) the fit
     invents large fraud on fraud-free data, so the analysis is run at dong
     level only.

  3. LOG VOTE-RATE DIAGNOSTIC (Klimek et al.'s Figure 2, following Borghesi
     and Bouchaud 2010). The logarithmic vote rate v_i = ln[(V_i - W_i)/W_i]
     is standardised; Klimek et al. report that fair elections collapse onto
     an approximately Gaussian shape while frauds produce skewed, heavy-tailed
     distributions. Skewness and excess kurtosis are reported.

VARIANTS
  --residualize   Klimek et al. apply the model to the raw national
                  distribution. Strong regional voting (e.g. Honam/Yeongnam)
                  makes a single-Normal clean component badly misspecified,
                  which the fraud components may then absorb. With this flag,
                  logit(t) and logit(s) are demeaned by province and re-centred
                  on the national mean before fitting -- the same residualisation
                  Mebane (2023) uses for his eforensics-plots. Report both.

WHAT IT REUSES (by import, not reimplementation), from
mebane_r_driver_bidirectional.py:
  load_pure_unit_table / load_pure_constituency_table, and the two null
  generators generate_marginal_null / generate_joint_null, called with their
  default seed=1 -- identical to the eforensics runs, so both methods see the
  same synthetic datasets.

USAGE
    python3 klimek_analysis.py <elec_id> <level> <channel> [leader_side] [--residualize] [--outdir DIR] [--no-plot]
    python3 klimek_analysis.py pres18 dong total_no_early dem
    python3 klimek_analysis.py 21 constituency total con --residualize

OUTPUT (in --outdir, default ./klimek_output):
    <tag>_klimek.csv   one row per source (real, marginal_null, joint_null)
    <tag>_klimek.png   fingerprints of the three sources plus the best-fit
                       model simulation for the real data
where <tag> = <elec>_<level>_<channel>_<leader>[_resid].

Requires numpy, pandas, scipy, matplotlib. No R, JAGS or eforensics.
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd
from scipy.special import ndtri, ndtr, logit, expit
from scipy.stats import skew, kurtosis
from scipy.ndimage import gaussian_filter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mebane_r_driver_bidirectional as base  # noqa: E402

SIGMA_X = 0.075                      # Klimek et al.'s fixed extreme-fraud scale
N_REP = 4                            # simulation replicates averaged per fingerprint
EPS = 1e-6
CRN_SEEDS = (1, 2, 3)                # independent simulation seeds per fit (see below)
SMOOTH = 1.0                         # Gaussian smoothing (in bins) applied to both fingerprints


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------

def observed_ts(df):
    N = df['eligible'].to_numpy(float)
    V = df['total_votes'].to_numpy(float)
    W = df['leader_votes'].to_numpy(float)
    ok = (N > 0) & (V > 0) & (W >= 0) & (W <= V) & (V <= N)
    t = V[ok] / N[ok]
    s = W[ok] / V[ok]
    return N[ok], t, s, df.loc[ok, 'prov_code'].to_numpy(), V[ok], W[ok]


def residualize(t, s, prov):
    """Remove province means on the logit scale, re-centre on the national mean."""
    out = []
    for x in (t, s):
        lx = logit(np.clip(x, 1e-4, 1 - 1e-4))
        g = pd.Series(lx).groupby(prov).transform('mean').to_numpy()
        out.append(expit(lx - g + lx.mean()))
    return out[0], out[1]


def n_bins(n):
    return int(np.clip(np.sqrt(n) / 1.5, 12, 40))


def trunc_normal(u, mu, sd):
    """Inverse-CDF draw from N(mu, sd) truncated to (0,1); u ~ U(0,1)."""
    a, b = ndtr((0 - mu) / sd), ndtr((1 - mu) / sd)
    return np.clip(mu + sd * ndtri(a + u * (b - a)), EPS, 1 - EPS)


def half_normal_01(u, scale):
    """Inverse-CDF draw from |N(0, scale)| truncated to (0,1)."""
    top = 2 * ndtr(1.0 / scale) - 1
    return np.clip(scale * ndtri(0.5 + 0.5 * u * top), EPS, 1 - EPS)


# ----------------------------------------------------------------------------
# the Klimek model fit
# ----------------------------------------------------------------------------
#
# Estimation strategy (settled after parameter-recovery testing; see
# klimek_recovery_test.py):
#
#  * The simulated fingerprint is the EXACT mixture expectation
#        H(f_i, f_e) = (1 - f_i - f_e) H_clean + f_i H_incr + f_e H_ext,
#    where each component histogram is built from all simulated units under
#    that class, rather than from a random class assignment. For fixed clean
#    and shape parameters this is linear in (f_i, f_e), so the best fraud
#    fractions are an exact two-variable non-negative least-squares solve.
#  * Simulated points are soft-binned (cloud-in-cell), and both fingerprints
#    are lightly Gaussian-smoothed, so the objective is continuous in the
#    remaining parameters (tau, sd_tau, nu, sd_nu, theta, alpha), which are
#    then fitted jointly by Nelder-Mead from several starts.
#  * Plug-in estimates of the clean component (median/MAD, KDE peak with
#    left half-width, corrected lower quantiles, and a fixed-point iteration
#    of the latter) were all tried first and all failed recovery: incremental
#    fraud is either absorbed into a widened clean component or invented in
#    the right tail of fraud-free data. Fitting the clean component jointly
#    removes that sensitivity.
#  * The same fit with f_i = f_e = 0 forced gives the best fraud-free fit;
#    sse_reduction = 1 - SSE_full / SSE_nofraud measures how much the fraud
#    components improve on it.

from scipy.optimize import minimize, nnls


def soft_hist(t, s, nb):
    """Cloud-in-cell 2-D histogram on [0,1]^2 with nb x nb bins (sums to len(t))."""
    x = np.clip(t * nb - 0.5, 0, nb - 1 - 1e-9)
    y = np.clip(s * nb - 0.5, 0, nb - 1 - 1e-9)
    i0, j0 = np.floor(x).astype(int), np.floor(y).astype(int)
    dx, dy = x - i0, y - j0
    i1, j1 = np.minimum(i0 + 1, nb - 1), np.minimum(j0 + 1, nb - 1)
    H = np.zeros(nb * nb)
    for ii, jj, w in ((i0, j0, (1 - dx) * (1 - dy)), (i1, j0, dx * (1 - dy)),
                      (i0, j1, (1 - dx) * dy), (i1, j1, dx * dy)):
        H += np.bincount(ii * nb + jj, weights=w, minlength=nb * nb)
    return H


def _smooth(H, nb):
    return gaussian_filter(H.reshape(nb, nb), SMOOTH).ravel()


def _unpack(p):
    return dict(tau=float(expit(p[0])), sd_tau=float(np.exp(p[1])),
                nu=float(expit(p[2])), sd_nu=float(np.exp(p[3])),
                # smooth bounded transforms (hard clipping created flat regions
                # that Nelder-Mead drifted into and could not leave)
                theta=float(0.02 + 0.58 * expit(p[4])),
                alpha=float(0.2 + 4.8 * expit(p[5])))


def fit_klimek(t, s, seed=1, n_rep=None):
    n = len(t)
    nb = n_bins(n)
    R = n_rep or N_REP
    obs = _smooth(soft_hist(t, s, nb) / n, nb)

    U = np.random.default_rng(seed).random((4, R * n))   # common random numbers

    def components(q):
        tau_i = trunc_normal(U[0], q['tau'], q['sd_tau'])
        nu_i = trunc_normal(U[1], q['nu'], q['sd_nu'])
        comps = [_smooth(soft_hist(tau_i, nu_i, nb) / (R * n), nb)]
        for frac in (half_normal_01(U[2], q['theta']), 1 - half_normal_01(U[3], SIGMA_X)):
            a = (1 - frac) * (1 - tau_i)
            w = tau_i * nu_i + frac * (1 - tau_i) + frac ** q['alpha'] * (1 - nu_i) * tau_i
            tt = 1 - a
            comps.append(_smooth(soft_hist(tt, np.clip(w / np.maximum(tt, EPS), 0, 1), nb) / (R * n), nb))
        return comps

    def solve_f(comps, allow_fraud=True):
        Hc, Hi, He = comps
        if not allow_fraud:
            return 0.0, 0.0, float(np.sum((Hc - obs) ** 2))
        (fi, fe), _ = nnls(np.column_stack([Hi - Hc, He - Hc]), obs - Hc)
        tot = fi + fe
        if tot > 0.95:
            fi, fe = fi * 0.95 / tot, fe * 0.95 / tot
        sim = (1 - fi - fe) * Hc + fi * Hi + fe * He
        return float(fi), float(fe), float(np.sum((sim - obs) ** 2))

    def fit(allow_fraud):
        def obj(p):
            return solve_f(components(_unpack(p)), allow_fraud)[2]
        mt, st = np.median(t), 1.4826 * np.median(np.abs(t - np.median(t)))
        ms, ss = np.median(s), 1.4826 * np.median(np.abs(s - np.median(s)))
        starts = []
        for th in ([0.06, 0.12, 0.25] if allow_fraud else [0.1]):
            for shrink in [1.0]:
                starts.append([logit(np.clip(mt, .02, .98)), np.log(max(st * shrink, 1e-3)),
                               logit(np.clip(ms, .02, .98)), np.log(max(ss * shrink, 1e-3)),
                               logit((th - 0.02) / 0.58), logit((1.0 - 0.2) / 4.8)])
        best = None
        for x0 in starts:
            r = minimize(obj, x0, method='Nelder-Mead',
                         options=dict(maxiter=600, xatol=1e-3, fatol=1e-12))
            if best is None or r.fun < best.fun:
                best = r
        q = _unpack(best.x)
        fi, fe, sse = solve_f(components(q), allow_fraud)
        q.update(fi=fi, fe=fe, sse=sse)
        return q

    full = fit(True)
    clean = fit(False)
    full.update(sse_nofraud=clean['sse'],
                sse_reduction=(1 - full['sse'] / clean['sse']) if clean['sse'] > 0 else np.nan,
                n=n, bins=nb, fraud_share=full['fi'] + full['fe'])
    q = {k: full[k] for k in ('tau', 'sd_tau', 'nu', 'sd_nu', 'theta', 'alpha')}
    Hc, Hi, He = components(q)
    H_best = (1 - full['fi'] - full['fe']) * Hc + full['fi'] * Hi + full['fe'] * He
    return full, obs.reshape(nb, nb), H_best.reshape(nb, nb)


def log_vote_rate_stats(V, W):
    ok = (W > 0) & (W < V)
    v = np.log((V[ok] - W[ok]) / W[ok])
    z = (v - v.mean()) / v.std()
    return dict(lvr_skew=float(skew(z)), lvr_excess_kurtosis=float(kurtosis(z)))


# ----------------------------------------------------------------------------
# plotting
# ----------------------------------------------------------------------------

def plot_cell(panels, out_path, title):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, len(panels), figsize=(3.6 * len(panels), 3.6), sharex=True, sharey=True)
    for ax, (label, H) in zip(axes, panels):
        ax.imshow(np.ma.masked_equal(H.T, 0), origin='lower', extent=[0, 1, 0, 1],
                  aspect='equal', cmap='viridis', interpolation='nearest')
        ax.set_title(label, fontsize=9)
        ax.set_xlabel('turnout')
    axes[0].set_ylabel('leader vote share')
    fig.suptitle(title, fontsize=10)
    fig.tight_layout()
    fig.savefig(out_path, dpi=130)
    plt.close(fig)


# ----------------------------------------------------------------------------
# driver
# ----------------------------------------------------------------------------

def run_cell(elec_id, level, channel, leader_side='dem', resid=False, outdir='klimek_output',
             plot=True, seed=1):
    os.makedirs(outdir, exist_ok=True)
    loader = base.load_pure_unit_table if level == 'dong' else base.load_pure_constituency_table
    real = loader(elec_id, channel, leader_side=leader_side)
    if real.empty:
        raise ValueError(f"No data for {elec_id}/{level}/{channel}/{leader_side}")
    sources = [('real', real),
               ('marginal_null', base.generate_marginal_null(real)),   # default seed=1, as in eforensics runs
               ('joint_null', base.generate_joint_null(real))]

    rows, panels = [], []
    for label, df in sources:
        N, t, s, prov, V, W = observed_ts(df)
        if resid:
            t, s = residualize(t, s, prov)
        # Incremental fraud f_i is only weakly identified from one fingerprint
        # (it trades off against theta and the clean-component spread; see
        # klimek_recovery_test.py), so each source is fitted under several
        # independent simulation seeds and the median and range are reported.
        # Extreme fraud f_e is stable across seeds.
        fits = [fit_klimek(t, s, seed=sd) for sd in CRN_SEEDS]
        shares = [f[0]['fraud_share'] for f in fits]
        k = int(np.argsort(shares)[len(shares) // 2])          # median-share fit
        fit, H_obs, H_sim = fits[k]
        fit = dict(fit)
        for key in ('fi', 'fe', 'fraud_share'):
            vals = [f[0][key] for f in fits]
            fit[key] = float(np.median(vals))
            fit[key + '_min'], fit[key + '_max'] = float(min(vals)), float(max(vals))
        fit.update(log_vote_rate_stats(V, W))
        fit.update(source=label, elec=elec_id, level=level, channel=channel,
                   leader_side=leader_side, residualized=resid)
        rows.append(fit)
        panels.append((f"{label}\nf_i={fit['fi']:.3f}, f_e={fit['fe']:.3f}", H_obs))
        if label == 'real':
            H_best = H_sim
    panels.append(("best-fit model (real)", H_best))

    cols = ['elec', 'level', 'channel', 'leader_side', 'residualized', 'source', 'n', 'bins',
            'fi', 'fi_min', 'fi_max', 'fe', 'fe_min', 'fe_max',
            'fraud_share', 'fraud_share_min', 'fraud_share_max', 'theta', 'alpha', 'tau', 'sd_tau', 'nu', 'sd_nu',
            'sse', 'sse_nofraud', 'sse_reduction', 'lvr_skew', 'lvr_excess_kurtosis']
    out = pd.DataFrame(rows)[cols]
    tag = f"{elec_id}_{level}_{channel}_{leader_side}" + ("_resid" if resid else "")
    out.to_csv(os.path.join(outdir, f"{tag}_klimek.csv"), index=False)
    if plot:
        plot_cell(panels, os.path.join(outdir, f"{tag}_klimek.png"),
                  f"Klimek fingerprints: {tag}")
    return out


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('elec_id'); ap.add_argument('level'); ap.add_argument('channel')
    ap.add_argument('leader_side', nargs='?', default='dem', choices=['dem', 'con'])
    ap.add_argument('--residualize', action='store_true')
    ap.add_argument('--outdir', default='klimek_output')
    ap.add_argument('--no-plot', action='store_true')
    a = ap.parse_args()
    res = run_cell(a.elec_id, a.level, a.channel, a.leader_side, resid=a.residualize,
                   outdir=a.outdir, plot=not a.no_plot)
    print(res[['source', 'fi', 'fe', 'fraud_share', 'theta', 'alpha', 'sse_reduction',
               'lvr_skew', 'lvr_excess_kurtosis']].to_string(index=False))
