"""Checks that klimek_2018.fit_realization (sparse cumulative-Gram solve)
returns exactly the same minimizer as fit_realization_dense (every grid point
scored from dense cumulative fingerprints), over simulated datasets of several
sizes, fraud levels and bin counts. Writes klimek_2018_output/verify_log.txt."""
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import klimek_2018 as K                       # noqa: E402
import klimek_2018_recovery_test as R         # noqa: E402

lines, mism, tot = [], 0, 0
for case, (n, fi, fe) in enumerate([(250, .1, .02), (2700, .15, .03), (3500, 0, 0), (3500, .3, 0), (13500, 0, 0), (13500, .15, .03)]):
    t, v = R.simulate(n, fi, fe, .1, 1.0, seed=100 + case)
    p = K.plugins(t, v)
    for nb in (25, 100):
        obs = K.fingerprint(t, v, nb)
        rng = np.random.default_rng(case)
        for rep in range(5):
            m = K.model_units(p, n, rng)
            t0 = time.time(); a = K.fit_realization_dense(obs.astype(float), m, nb); t1 = time.time()
            b = K.fit_realization(obs, m, nb); t2 = time.time()
            tot += 1; mism += (a != b)
            lines.append(f"n={n:6d} fi={fi:.2f} fe={fe:.2f} bins={nb:3d} rep={rep} dense={a} sparse={b} "
                         f"{'OK' if a == b else 'MISMATCH'} dense {t1-t0:.2f}s sparse {t2-t1:.2f}s")
lines.append(f"TOTAL: {tot - mism}/{tot} identical minimizers")
os.makedirs('klimek_2018_output', exist_ok=True)
open('klimek_2018_output/verify_log.txt', 'w').write("\n".join(lines) + "\n")
print(lines[-1])
