#!/usr/bin/env python3
"""
parse_selfnull_logs.py

Parses the per-cell .log files written by run_mebane_self_null_parallel.sh
(each containing a "RESULT: <elec>/<level>/<channel>/model_self_null/leader=..."
block from mebane_self_null_driver.py) into the flat CSV schema that
make_appendix_table_selfnull.py and make_fig7_selfnull.py read
(appendix_selfnull_results.csv): dataset, leader_side, elec, level, channel,
n_units, fraud_share, n_flagged, rhat, not_converged, elapsed, p_no_fraud,
p_incremental, p_extreme, plus w_form and the fraud-share intervals when the
log has them.

parse_mebane_logs.py handles the ordinary real/marginal/joint sweeps; this is
its counterpart for the self-null sweep, whose downstream scripts expect the
column names above rather than parse_mebane_logs.py's.

Both leader-side directories of a run are usually passed at once, e.g. for a
latent-turnout (EFORENSICS_WFORM=tau) sweep:

    python3 parse_selfnull_logs.py output_data_tau/mebane_r_all_logs \\
        output_data_tau/con_leader -o appendix_selfnull_results_tau.csv \\
        --dataset new_settings_tau_selfnull

w_form is read from each log's own "w_form :" line; logs written before that
line existed are recorded as 'conditional', which is what they were.
"""
import argparse
import glob
import os
import re

import pandas as pd

RESULT_RE = re.compile(
    r"^RESULT:\s*(?P<elec>[^/]+)/(?P<level>[^/]+)/(?P<channel>[^/]+)/model_self_null/leader=(?P<leader_side>\w+)\s*$",
    re.MULTILINE)
NUM = r"([0-9.eE+-]+)"
FIELDS = {'p_no_fraud': r"^p_no_fraud_median\s*:\s*" + NUM,
          'p_incremental': r"^p_incremental_median\s*:\s*" + NUM,
          'p_extreme': r"^p_extreme_median\s*:\s*" + NUM,
          'fraud_share': r"^fraud_share_median\s*:\s*" + NUM,
          'rhat': r"^rhat_pi\s*:\s*" + NUM,
          'elapsed': r"^elapsed_seconds\s*:\s*" + NUM}
FLAGGED_RE = re.compile(r"^n_regions_flagged\s*:\s*(\d+)/(\d+)", re.MULTILINE)
WFORM_RE = re.compile(r"^w_form\s*:\s*(\w+)", re.MULTILINE)
REDRAW_RE = re.compile(r"^\[self_null\] (\d+) of \d+ unit\(s\) drew leader votes above votes cast", re.MULTILINE)
INTERVALS = {'hpd': re.compile(r"^fraud_share_hpd95\s*:\s*\[\s*" + NUM + r"\s*,\s*" + NUM + r"\s*\]", re.MULTILINE),
             'cons': re.compile(r"^fraud_share_cons95\s*:\s*\[\s*" + NUM + r"\s*,\s*" + NUM + r"\s*\]", re.MULTILINE)}


def parse_log(path, dataset):
    text = open(path, errors='replace').read()
    m = RESULT_RE.search(text)
    if not m:
        return None                      # no RESULT block -> cell never finished
    row = dict(dataset=dataset, **m.groupdict())
    for name, pat in FIELDS.items():
        hit = re.search(pat, text, re.MULTILINE)
        row[name] = float(hit.group(1)) if hit else float('nan')
    flagged = FLAGGED_RE.search(text)
    row['n_flagged'] = int(flagged.group(1)) if flagged else None
    row['n_units'] = int(flagged.group(2)) if flagged else None
    row['not_converged'] = bool(row['rhat'] > 1.05) if row['rhat'] == row['rhat'] else None
    wform = WFORM_RE.search(text)
    row['w_form'] = wform.group(1).lower() if wform else 'conditional'
    rd = REDRAW_RE.search(text)
    row['n_redrawn'] = int(rd.group(1)) if rd else 0   # infeasible units redrawn (see generate_model_self_null)
    for key, pat in INTERVALS.items():
        hit = pat.search(text)
        row[f'fraud_share_{key}_lo'] = float(hit.group(1)) if hit else float('nan')
        row[f'fraud_share_{key}_hi'] = float(hit.group(2)) if hit else float('nan')
    row['source_log'] = os.path.basename(path)
    return row


COLS = ['dataset', 'leader_side', 'elec', 'level', 'channel', 'n_units', 'fraud_share', 'n_flagged',
        'rhat', 'not_converged', 'elapsed', 'p_no_fraud', 'p_incremental', 'p_extreme', 'w_form', 'n_redrawn',
        'fraud_share_hpd_lo', 'fraud_share_hpd_hi', 'fraud_share_cons_lo', 'fraud_share_cons_hi', 'source_log']

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('logs_dirs', nargs='+', help="one or more directories of self-null .log files")
    ap.add_argument('-o', '--out', default='appendix_selfnull_results_tau.csv')
    ap.add_argument('--dataset', default=None,
                    help="label for the 'dataset' column (default: new_settings_tau_selfnull if every "
                         "parsed log used w_form=tau, else new_settings_selfnull)")
    a = ap.parse_args()

    rows, skipped = [], 0
    for d in a.logs_dirs:
        for f in sorted(glob.glob(os.path.join(d, '*self_null*.log'))):   # other sweeps may share the directory
            r = parse_log(f, a.dataset)
            rows.append(r) if r else None
            skipped += r is None
    if not rows:
        raise SystemExit(f"no completed self-null cells found in {a.logs_dirs}")
    df = pd.DataFrame(rows)
    if a.dataset is None:
        df['dataset'] = 'new_settings_tau_selfnull' if (df.w_form == 'tau').all() else 'new_settings_selfnull'
    df = df[COLS].sort_values(['leader_side', 'elec', 'level', 'channel'])
    df.to_csv(a.out, index=False)
    forms = df.w_form.value_counts().to_dict()
    print(f"wrote {a.out}: {len(df)} cells ({skipped} unfinished log(s) skipped); w_form {forms}")
    if len(set(forms)) > 1:
        print("WARNING: mixed likelihood forms in one CSV -- check that the log directories belong to one sweep.")
