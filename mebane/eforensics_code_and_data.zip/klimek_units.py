#!/usr/bin/env python3
"""
klimek_units.py

Unit tables for the Klimek-type fingerprint analysis, at two levels:

  'dong'  -- 읍면동 (administrative neighbourhood; ~2,700-3,600 units)
  'tpg'   -- 투표구 (polling district; ~13,000-13,500 units), the finest level
             published by the National Election Commission

Restricted to the five national elections held before early voting existed
(Pres 2002, Pres 2007, Gen 2008, Gen 2012, Pres 2012). For these, every
regular ballot is cast and counted at its 투표구, so turnout at both levels is
total turnout. (From 2014 on, in-precinct early votes are published only per
읍면동, so a 투표구 fingerprint could only cover same-day votes; those
elections are not analysed here.)

Unit rules follow Klimek et al. (2018), who defer to the model of Klimek et
al. (2012) and state their data rules explicitly:
  * units with an electorate N_i < 100 are removed (2018, "Election data";
    2012 main text and SI);
  * turnout T_i/N_i uses the number of VALID votes T_i (2018: "the number of
    valid votes or turnout, T_i"); here T_i = sum of candidate votes;
  * where a unit reports more valid ballots than registered voters, turnout
    is set to 100% (2012 SI, "Data");
  * no other trimming: units at 100% turnout or 0%/100% vote share are KEPT,
    since that corner is exactly where the model's extreme-fraud mode lives.
    (The eforensics loader in mebane_r_driver_bidirectional.py trims
    tau, nu to (0.001, 0.999); that trim is not applied here.)
One further rule, needed because both leader codings are fit: units where
either major party received zero votes are dropped. In the 2008 and 2012
general elections these are constituencies where that party fielded no
candidate (2008: 805 dong without a Democratic candidate; 2012: 553 without
a Democratic and 280 without a Saenuri candidate), so a zero leader share
there records the ballot, not voters' preferences. The rule is applied
identically for both codings, so both are fit on the same units. (The
eforensics loader drops zero-Democratic units for both codings but drops
zero-conservative units only under conservative coding, through its nu
trim, so its two codings differ by 267 dong in Gen 2012.)

Absentee ballots (부재자투표 and variants) and misfiled ballots are reported
per 구시군/constituency, not per 투표구, and are excluded at both levels,
exactly as in the eforensics pipeline.

Returned columns: province_tag, prov_code, constituency, dong_name,
tpg_name ('' at dong level), eligible (N_i), total_votes (T_i),
leader_votes (W_i), tau = T/N, nu = W/T -- the same schema the null
generators in mebane_r_driver_bidirectional.py consume.
"""
import os
import re
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mebane_r_driver_bidirectional as base   # noqa: E402

PREEARLY = ['pres16', 'pres17', '18', '19', 'pres18']
LABEL = {'pres16': 'Pres 2002', 'pres17': 'Pres 2007', '18': 'Gen 2008', '19': 'Gen 2012', 'pres18': 'Pres 2012'}
WINNER = {'pres16': 'dem', 'pres17': 'con', '18': 'con', '19': 'con', 'pres18': 'con'}
MIN_ELECTORATE = 100
LEVELS = ('dong', 'tpg')
LEVEL_LABEL = {'dong': 'dong (읍면동)', 'tpg': 'polling district (투표구)'}


def _sgg_primary(name):
    if not isinstance(name, str):
        return ''
    if '_' in name:
        c = base.normalize_sigungu(name.split('_', 1)[1])
    else:
        c = base.normalize_sigungu(re.sub(r'[갑을병정무]$', '', name).strip())
    return c[0] if c else ''


def _raw_tpg(elec):
    """One row per 투표구: N, T (valid), W_dem, W_con, with geography."""
    key = base._resolve_election_key(elec)
    cfg = base.ELECTION_CONFIGS[key]
    if not cfg.get('no_early_voting'):
        raise ValueError(f"{elec}: Klimek analysis is restricted to pre-early-voting elections {PREEARLY}")
    d = base._read_csv_auto(cfg['result_csv'], low_memory=False)
    if cfg['election_type'] == 'presidential':
        d = d.rename(columns={'구시군명': '선거구명', '읍면동명': '법정읍면동명'})
        special = base.SPECIAL_DONG_NAMES_PRESIDENTIAL
    else:
        special = base.SPECIAL_DONG_NAMES_GENERAL
    d = d[~d['법정읍면동명'].isin(special)].copy()
    d['득표수'] = pd.to_numeric(d['득표수'], errors='coerce').fillna(0).astype(np.int64)
    geo = ['시도명', '선거구명', '법정읍면동명', '투표구명']
    meta = d['후보자'].isin(base.META_CANDIDATES)
    N = d[d['후보자'] == '선거인수'].groupby(geo)['득표수'].sum().rename('eligible')
    cand = d[~meta]
    T = cand.groupby(geo)['득표수'].sum().rename('total_votes')
    Wd = cand[cand['후보자'].str.contains(cfg['dem_pattern'], na=False)].groupby(geo)['득표수'].sum().rename('dem')
    Wc = cand[cand['후보자'].str.contains(cfg['con_pattern'], na=False)].groupby(geo)['득표수'].sum().rename('con')
    t = pd.concat([N, T, Wd, Wc], axis=1).fillna(0).astype(np.int64).reset_index()
    t['province_tag'] = t['시도명'].map(base.PROV_FULL_TO_SHORT).fillna(t['시도명'])
    seoul = t['province_tag'] == 'Seoul'
    g3 = t['선거구명'].map(_sgg_primary).isin(['강남', '서초', '송파'])
    t.loc[seoul & g3, 'province_tag'] = 'Seoul (Gangnam3gu)'
    t.loc[seoul & ~g3, 'province_tag'] = 'Seoul (Non-Gangnam3gu)'
    return t


def load_units(elec, level, leader_side):
    """Klimek unit table for one pre-early election at level 'dong' or 'tpg'."""
    if level not in LEVELS:
        raise ValueError(f"level must be one of {LEVELS}")
    t = _raw_tpg(elec)
    if level == 'dong':
        t = (t.groupby(['시도명', '선거구명', '법정읍면동명', 'province_tag'], as_index=False)
              [['eligible', 'total_votes', 'dem', 'con']].sum())
        t['투표구명'] = ''
    t = t[(t['eligible'] >= MIN_ELECTORATE) & (t['total_votes'] > 0) & (t['dem'] > 0) & (t['con'] > 0)].copy()
    t['eligible'] = np.maximum(t['eligible'], t['total_votes'])          # >100% turnout -> 100%
    t['leader_votes'] = t[leader_side]
    out = t.rename(columns={'선거구명': 'constituency', '법정읍면동명': 'dong_name', '투표구명': 'tpg_name'})
    out['tau'] = out['total_votes'] / out['eligible']
    out['nu'] = out['leader_votes'] / out['total_votes']
    out['prov_code'], out['prov_group'] = base.compute_prov_code(out['province_tag'], grouping='original')
    return out[['시도명', 'province_tag', 'prov_code', 'prov_group', 'constituency', 'dong_name', 'tpg_name',
                'eligible', 'total_votes', 'leader_votes', 'tau', 'nu']].reset_index(drop=True)


def turnout_share(df):
    """(t, v, prov) arrays for the estimator: t = T/N, v = W/T (no trimming)."""
    return (df['total_votes'] / df['eligible']).to_numpy(float), \
           (df['leader_votes'] / df['total_votes']).to_numpy(float), df['prov_code'].to_numpy()


def complete_levels(df, per_level):
    """Levels whose results are complete (per_level rows); partially run levels are left out
    of tables and figures until their grid finishes."""
    return [lv for lv in LEVELS if (df['level'] == lv).sum() >= per_level]


MAIN_PER_LEVEL = 5 * 2 * 2 * 2      # elections x codings x raw/resid x real/joint null
EXCL_PER_LEVEL = 5 * 3              # elections x three exclusions
