#!/usr/bin/env python3
"""
klimek_2018_from_sweeps.py

Rebuilds results-CSV rows from per-sweep files (klimek_2018_output/sweeps/
<elec>_<level>_<side>_<resid>_<source>_<variant>.npy, each a 200 x 3 array of
fitted (f_i, f_e, alpha)), for runs whose CSVs were not kept (e.g. run on
another machine and only the sweeps copied back). Everything else in a row is
deterministic: n and the plug-in parameters are recomputed from the same unit
table (klimek_units.py), residualization, and joint-null seed as
klimek_2018_all.py uses.

  python3 klimek_2018_from_sweeps.py --check     # rebuild existing rows, compare
  python3 klimek_2018_from_sweeps.py --level tpg # append missing rows for a level
"""
import argparse
import glob
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import klimek_2018 as K18                     # noqa: E402
import klimek_units as KU                     # noqa: E402
import mebane_r_driver_bidirectional as base  # noqa: E402
from klimek_2018_all import COLS, EXCL, EXCLUSIONS, MAIN, OUTDIR, arrays  # noqa: E402

EXCL_MAP = dict(EXCLUSIONS)
_cache = {}


def units(elec, level, side, source):
    k = (elec, level, side)
    if k not in _cache:
        real = KU.load_units(elec, level, side)
        _cache[k] = {'real': real, 'joint_null': base.generate_joint_null(real)}
    return _cache[k][source]


def row_from_sweeps(path):
    name = os.path.basename(path)[:-4]
    elec, level, side, resid, rest = name.split('_', 4)
    source, variant = ('joint_null', rest[len('joint_null_'):]) if rest.startswith('joint_null') else rest.split('_', 1)
    resid = resid == 'True'
    df = units(elec, level, side, source)
    if variant != 'all':
        df = df[~df['province_tag'].isin(EXCL_MAP[variant])]
    t, v = arrays(df, resid)
    fits = np.load(path)
    r = dict(K18.plugins(t, v))
    for k, nm in enumerate(('fi', 'fe', 'alpha')):
        r[nm], r[nm + '_sd'] = float(fits[:, k].mean()), float(fits[:, k].std(ddof=1))
    tot = fits[:, 0] + fits[:, 1]
    r.update(elec=elec, level=level, leader_side=side, residualized=resid, source=source, variant=variant,
             n=len(v), bins=K18.NB, n_real=len(fits), fraud_share=float(tot.mean()),
             fraud_share_sd=float(tot.std(ddof=1)), seconds=np.nan)
    return r


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--level', default=None)
    a = ap.parse_args()
    files = sorted(glob.glob(os.path.join(OUTDIR, 'sweeps', '*.npy')))
    if a.check:
        old = pd.concat([pd.read_csv(p, dtype={'elec': str}) for p in (MAIN, EXCL)])
        key = ['elec', 'level', 'leader_side', 'residualized', 'source', 'variant']
        old = old.set_index(key)
        worst, n = 0.0, 0
        for f in files:
            r = row_from_sweeps(f)
            k = tuple(r[c] for c in key)
            if k in old.index:
                o = old.loc[k]
                assert int(o.n) == r['n'], (k, o.n, r['n'])
                for c in ('a', 'v', 'sigma_a', 'sigma_vL', 'sigma_vR', 'fi', 'fi_sd', 'fe', 'alpha', 'fraud_share', 'fraud_share_sd'):
                    worst = max(worst, abs(float(o[c]) - r[c]))
                n += 1
        print(f"checked {n} existing rows; max abs difference {worst:.2e}")
    if a.level:
        for path, excl in ((MAIN, False), (EXCL, True)):
            have = pd.read_csv(path, dtype={'elec': str})
            keys = set(zip(have.elec, have.level, have.leader_side, have.residualized, have.source, have.variant))
            new = []
            for f in files:
                if f"_{a.level}_" not in os.path.basename(f) or (os.path.basename(f).endswith('_all.npy') == excl):
                    continue
                r = row_from_sweeps(f)
                if (r['elec'], r['level'], r['leader_side'], r['residualized'], r['source'], r['variant']) not in keys:
                    new.append(r)
            if new:
                pd.DataFrame(new)[COLS].to_csv(path, mode='a', header=False, index=False)
            print(f"{path}: appended {len(new)} rows")
