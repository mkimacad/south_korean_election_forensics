#!/bin/bash
# Runs klimek_analysis.py over every election / dong-level channel / leader
# coding, in both the raw and the province-residualized variants, then
# aggregates everything with klimek_summarize.py.
#
# Pure Python (numpy/scipy/matplotlib); no R, JAGS or eforensics needed.
# Each cell fits real + marginal null + joint null, three simulation seeds
# each, which takes about a minute per dong cell on one core.
#
# DONG LEVEL ONLY BY DEFAULT. Constituency cells (198-253 units) are too few
# for the Klimek fingerprint fit: in klimek_recovery_test.py the fit invents
# ~80-90% fraud on fraud-free data at n = 250. Set LEVELS="dong constituency"
# to run them anyway (their results should not be interpreted).
#
# Usage:
#   ./run_klimek_all.sh                        <- all elections, all dong channels, dem+con, raw+resid
#   ./run_klimek_all.sh "pres18 21"            <- selected elections
#   CHANNELS=aggregate ./run_klimek_all.sh     <- only pooled / total_no_early (the paper's main channels)
#   MAX_PARALLEL=4 ./run_klimek_all.sh         <- concurrency (default 1)
#   FORCE_RERUN=1 ./run_klimek_all.sh          <- ignore existing outputs
#   VARIANTS="raw" ./run_klimek_all.sh         <- skip the residualized variant

set -e
cd "$(dirname "$0")"

ELECTIONS="${1:-18 19 20 21 22 pres16 pres17 pres18 pres19 pres20 pres21}"
LEVELS="${LEVELS:-dong}"
LEADER_SIDES="${LEADER_SIDES:-dem con}"
VARIANTS="${VARIANTS:-raw resid}"
CHANNELS="${CHANNELS:-all}"            # all | aggregate
OUTDIR="${OUTDIR:-klimek_output}"
MAX_PARALLEL="${MAX_PARALLEL:-1}"
FORCE_RERUN="${FORCE_RERUN:-0}"
NO_EARLY=" 18 19 pres16 pres17 pres18 "

mkdir -p "$OUTDIR/logs"

channels_for() {   # $1 = election, $2 = level
  if [[ "$NO_EARLY" == *" $1 "* ]]; then echo "total_no_early"; return; fi
  if [ "$CHANNELS" = "aggregate" ]; then
    [ "$2" = "dong" ] && echo "pooled" || echo "total"; return
  fi
  [ "$2" = "dong" ] && echo "early sameday pooled" || echo "early early_out early_total sameday total"
}

run_one() {
  local e="$1" lvl="$2" ch="$3" ls="$4" var="$5"
  local flag="" suffix=""
  [ "$var" = "resid" ] && flag="--residualize" && suffix="_resid"
  local tag="${e}_${lvl}_${ch}_${ls}${suffix}"
  if [ "$FORCE_RERUN" != "1" ] && [ -s "$OUTDIR/${tag}_klimek.csv" ]; then
    echo "SKIP  $tag"; return
  fi
  if python3 klimek_analysis.py "$e" "$lvl" "$ch" "$ls" $flag --outdir "$OUTDIR" \
        > "$OUTDIR/logs/${tag}.log" 2>&1; then
    echo "OK    $tag"
  else
    echo "FAIL  $tag (see $OUTDIR/logs/${tag}.log)"
  fi
}

t0=$(date +%s)
for e in $ELECTIONS; do
  for lvl in $LEVELS; do
    for ch in $(channels_for "$e" "$lvl"); do
      for ls in $LEADER_SIDES; do
        for var in $VARIANTS; do
          while [ "$(jobs -r -p | wc -l)" -ge "$MAX_PARALLEL" ]; do wait -n; done
          run_one "$e" "$lvl" "$ch" "$ls" "$var" &
        done
      done
    done
  done
done
wait
echo "All cells done in $(( $(date +%s) - t0 )) s."

python3 klimek_summarize.py --outdir "$OUTDIR"
