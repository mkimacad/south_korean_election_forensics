#!/usr/bin/env Rscript
# mebane_crosscheck.R
#
# Fits the Ferrari/Mebane eforensics quasi-binomial-logistic ("qbl") election
# fraud model to a single election/level/channel/source cell and writes out
# posterior summaries.
#
# Usage:
#   Rscript mebane_crosscheck.R <input.csv> <output.csv> [n_iter] [n_chains] [burn_in] [use_parcomp] [n_adapt]
#
# input.csv must contain columns: leader_votes, total_votes, eligible, prov_code

suppressMessages(library(eforensics))

# --- Optional latent-turnout (tau) form of the leader-vote likelihood -------
# Set EFORENSICS_WFORM=tau to swap the package's qbl model for the fork in
# ef_qbl_tau.R, which writes p.w[j] in terms of the latent turnout mu.tau[j]
# instead of the realized abstentions a[j]/N[j]. Unset (default) or
# "conditional" runs the package's own qbl unchanged.
W_FORM <- tolower(Sys.getenv("EFORENSICS_WFORM", "conditional"))
if (W_FORM == "tau") {
  script_dir <- tryCatch(dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]))),
                         error = function(e) ".")
  source(file.path(script_dir, "ef_qbl_tau.R"))
  activate_tau_form()
} else if (W_FORM != "conditional") {
  stop("EFORENSICS_WFORM must be 'conditional' (default) or 'tau', got '", W_FORM, "'")
}

# --- Optional PSRF (Gelman-Rubin) stopping rule -----------------------------
# eforensics() defaults to autoConv = TRUE with mcmc.conv.diagnostic = "MCMCSE"
# (per-chain Monte Carlo SE of pi below 0.05; up to max.auto = 10 extensions).
# Set EFORENSICS_CONV=psrf to use the package's own alternative rule instead,
# which requires psrf < 1.05 for every monitored pi component, extending the
# chains up to EFORENSICS_MAX_AUTO times (default: the package's 10). Unset
# (default) or "mcmcse" leaves the package defaults untouched.
CONV_RULE <- tolower(Sys.getenv("EFORENSICS_CONV", "mcmcse"))
if (!CONV_RULE %in% c("mcmcse", "psrf")) stop("EFORENSICS_CONV must be 'mcmcse' (default) or 'psrf', got '", CONV_RULE, "'")
MAX_AUTO <- suppressWarnings(as.integer(Sys.getenv("EFORENSICS_MAX_AUTO", "10")))
if (is.na(MAX_AUTO) || MAX_AUTO < 0) MAX_AUTO <- 10L
suppressMessages(library(coda))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2) {
  stop("Usage: Rscript mebane_crosscheck.R <input.csv> <output.csv> [n_iter] [n_chains] [burn_in] [use_parcomp] [n_adapt]")
}

input_path   <- args[1]
output_path  <- args[2]
n_iter       <- if (length(args) >= 3) as.integer(args[3]) else 1000   # short-chain default
n_chains     <- if (length(args) >= 4) as.integer(args[4]) else 4
burn_in      <- if (length(args) >= 5) as.integer(args[5]) else 300    # short-chain default
use_parcomp  <- if (length(args) >= 6) as.logical(args[6]) else TRUE
n_adapt      <- if (length(args) >= 7) as.integer(args[7]) else 1000

cat(sprintf("[R-Model] Reading input data from: %s\n", input_path))
raw <- read.csv(input_path)

required_cols <- c("leader_votes", "total_votes", "eligible", "prov_code")
missing <- setdiff(required_cols, names(raw))
if (length(missing) > 0) {
  stop(sprintf("Input CSV missing required column(s): %s", paste(missing, collapse = ", ")))
}

# Map raw count data to the eforensics overdispersed-binomial schema. `prov`
# is an arbitrary integer grouping code (e.g. province) supplied by the
# caller in prov_code; this script simply factors whatever codes it is given.
data <- data.frame(
  w = round(raw$leader_votes),
  a = round(raw$eligible - raw$total_votes),
  N = round(raw$eligible),
  prov = factor(raw$prov_code)
)

bad <- data$w < 0 | data$a < 0 | (data$w + data$a) > data$N
if (any(bad)) {
  stop(sprintf("Data sanity error: %d row(s) have invalid vote counts (w<0, a<0, or w+a>N).", sum(bad)))
}

cat(sprintf("[R-Model] N=%d units, %d province(s). Fitting Quasi-Binomial-Logistic ('qbl') model...\n",
            nrow(data), nlevels(data$prov)))

mcmc_params <- list(burn.in = burn_in, n.adapt = n_adapt, n.iter = n_iter, n.chains = n_chains)
cat(sprintf("[R-Model] MCMC settings: n.iter=%d, n.chains=%d, burn.in=%d, n.adapt=%d, parComp=%s\n",
            n_iter, n_chains, burn_in, n_adapt, use_parcomp))

# Different released forks of the eforensics package spell the
# eligible-voters argument to eforensics() differently ("eligible.voters" vs.
# "elegible.voters"); detect the installed spelling at runtime rather than
# hardcoding one.
ef_formal_names <- names(formals(eforensics))
if ("eligible.voters" %in% ef_formal_names) {
  eligible_arg_name <- "eligible.voters"
} else if ("elegible.voters" %in% ef_formal_names) {
  eligible_arg_name <- "elegible.voters"
} else {
  stop(sprintf(paste0("Could not find an eligible-voters argument in the installed eforensics ",
                       "package's eforensics() function (checked 'eligible.voters' and ",
                       "'elegible.voters'). Formal arguments found: %s"),
               paste(ef_formal_names, collapse = ", ")))
}
cat(sprintf("[R-Model] Detected eforensics() eligible-voters argument name: '%s'\n", eligible_arg_name))

# parameters="all" delegates to an internal helper that has no case for
# model=="qbl" in at least one package fork, causing an error. Passing the
# explicit parameter list below bypasses that helper and is equivalent to
# what "all" resolves to for the bl/qbl/bbl model family: the base
# parameters plus "Z" (per-unit latent class draws, needed for piZi/get_Z()
# to be populated).
# "mu.tau" and "mu.nu" (per-unit latent turnout and leader share) are monitored
# so that fraudulent-vote counts can be computed from the model's own
# definition (see the Ft/Fw block below). Monitoring deterministic nodes does
# not change what JAGS samples.
qbl_parameters <- c("pi", "beta.tau", "beta.nu", "beta.iota.m", "beta.iota.s",
                     "beta.chi.m", "beta.chi.s", "Z", "mu.tau", "mu.nu")

ef_args <- list(
  formula1 = w ~ prov,   # location equation for leader vote share
  formula2 = a ~ prov,   # location equation for abstention share
  data = data,
  model = "qbl",   # quasi-binomial model: per-unit random effects on all of tau, nu, iota, and chi
  mcmc = mcmc_params,
  get.dic = 0,
  parComp = use_parcomp,
  parameters = qbl_parameters
)
ef_args[[eligible_arg_name]] <- "N"
ef_args$autoConv <- TRUE
ef_args$max.auto <- MAX_AUTO
if (CONV_RULE == "psrf") {
  ef_args$mcmc.conv.diagnostic <- "PSRF"
  cat(sprintf("[R-Model] Stopping rule: PSRF < 1.05 on pi, up to %d extensions.\n", MAX_AUTO))
} else {
  # Logged in both cases so that every log records which rule was in force.
  cat(sprintf("[R-Model] Stopping rule: MCMCSE < 0.05 on pi (package default), up to %d extensions.\n", MAX_AUTO))
}

t0 <- Sys.time()
samples <- do.call(eforensics, ef_args)
elapsed <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
cat(sprintf("[R-Model] Execution complete in %.1f seconds.\n", elapsed))

# Population-level mixing weights (pi) across chains
pi_pooled <- do.call(rbind, lapply(samples, function(ch) {
  ch$parameters[, c("pi[1]", "pi[2]", "pi[3]")]
}))
pi_median <- apply(pi_pooled, 2, median)

pi_hpd <- coda::HPDinterval(coda::as.mcmc(pi_pooled), prob = 0.95)

# --- Fraud share (pi[2] + pi[3]) -------------------------------------------
# Computed per MCMC draw, so that its 95% HPD interval is a TRUE interval for
# the sum rather than the sum of the two component intervals. The two differ
# because pi[2] and pi[3] are posteriorly dependent: adding the separate HPD
# bounds ignores that dependence and yields a strictly conservative (wider)
# outer bound. Both are written out below so downstream tables can report
# either. Note also that median(pi[2] + pi[3]) is not in general equal to
# median(pi[2]) + median(pi[3]); the manuscript's headline fraud share is the
# sum of the component medians, reported here as fraud_share_sum_of_medians,
# while fraud_share_joint_median is the median of the per-draw sum.
fraud_share_draws <- as.numeric(pi_pooled[, "pi[2]"]) + as.numeric(pi_pooled[, "pi[3]"])
fraud_share_joint_median <- median(fraud_share_draws)
fraud_share_joint_hpd <- coda::HPDinterval(
  coda::as.mcmc(matrix(fraud_share_draws, ncol = 1)), prob = 0.95)

pi_mcmc_list <- coda::mcmc.list(lapply(samples, function(ch) {
  coda::as.mcmc(ch$parameters[, c("pi[1]", "pi[2]", "pi[3]")])
}))
rhat <- tryCatch({
  gd <- coda::gelman.diag(pi_mcmc_list, autoburnin = FALSE, multivariate = FALSE)
  max(gd$psrf[, "Point est."])
}, error = function(e) NA_real_)

# Mebane (2023) posterior-multimodality diagnostics.
# M(pi_j): largest absolute difference between chain-specific posterior means.
chain_pi_means <- do.call(rbind, lapply(samples, function(ch) {
  colMeans(ch$parameters[, c("pi[1]", "pi[2]", "pi[3]")])
}))
M_pi <- if (nrow(chain_pi_means) > 1) apply(chain_pi_means, 2, function(x) max(x) - min(x)) else c(NA_real_, NA_real_, NA_real_)

# D(pi_j): Hartigan & Hartigan (1985) dip test for unimodality, pooling all
# chains together. Requires the 'diptest' package; degrades to NA rather
# than failing the run if it isn't installed.
D_pi <- tryCatch({
  if (!requireNamespace("diptest", quietly = TRUE)) stop("diptest not installed")
  apply(pi_pooled, 2, function(x) diptest::dip.test(x)$p.value)
}, error = function(e) {
  cat(sprintf("[R-Model] NOTE: D(pi_j) dip test unavailable (%s) -- reporting NA. Install the 'diptest' R package for this diagnostic.\n", conditionMessage(e)))
  c(NA_real_, NA_real_, NA_real_)
})

# Ft (manufactured votes) / Fw (total fraudulent votes).
#
# FRAUDULENT-VOTE COUNTS (model-consistent).
# The qbl model's fraud quantities are RATES: iota.m / chi.m is the share of
# would-be abstainers counted for the leader, iota.s / chi.s the share of
# would-be opposition votes counted for the leader (see p.a and p.w in the
# package's qbl model). The number of fraudulent votes the model implies in
# unit i, for one posterior draw, is therefore
#     manufactured_i = N_i * f.m_i * (1 - tau_i)
#     stolen_i       = N_i * f.s_i * tau_i * (1 - nu_i)
# with (f.m, f.s) = (iota.m, iota.s) if Z_i = 2, (chi.m, chi.s) if Z_i = 3, and
# 0 if Z_i = 1, and tau_i = mu.tau[i], nu_i = mu.nu[i] the latent turnout and
# leader share. This is also how the package's own data simulator
# (ef_simulate_data.R) generates fraudulent votes. It is NOT what
# attr(samples, "frauds") contains: that attribute summarizes the rates
# themselves, and multiplying them by N_i (as ef_get_local_fraud() does)
# overstates the vote counts. That package-convention total is still reported,
# as Ft_pkg_total / Fw_pkg_total, for comparison only.
#
# Totals are computed per draw from the raw monitored chains in
# attr(samples, "samples"), so the reported intervals are exact joint 95% HPD
# intervals of the totals (earlier versions summed per-unit HPD bounds).
#   Ft = manufactured votes only; Fw = manufactured + stolen.
fraud_votes <- tryCatch({
  raw <- attr(samples, "samples")
  if (is.null(raw)) stop("attr(samples, 'samples') is NULL -- package version does not expose raw draws")
  chains <- raw[[1]]
  n_units <- nrow(data)
  unit_cols <- function(ch, node) {
    cn <- paste0(node, "[", seq_len(n_units), "]")
    miss <- setdiff(cn, colnames(ch))
    if (length(miss)) stop(sprintf("node '%s' not monitored (missing e.g. %s)", node, miss[1]))
    ch[, cn, drop = FALSE]
  }
  Ft_d <- Fw_d <- Ftp_d <- Fwp_d <- numeric(0)
  unit_m <- unit_s <- numeric(n_units); n_draws <- 0
  for (ch in chains) {
    ch  <- as.matrix(ch)
    Z   <- unit_cols(ch, "Z")
    tau <- unit_cols(ch, "mu.tau")
    nu  <- unit_cols(ch, "mu.nu")
    f_m <- (Z == 2) * unit_cols(ch, "iota.m") + (Z == 3) * unit_cols(ch, "chi.m")
    f_s <- (Z == 2) * unit_cols(ch, "iota.s") + (Z == 3) * unit_cols(ch, "chi.s")
    m <- f_m * (1 - tau)
    s <- f_s * tau * (1 - nu)
    Ft_d  <- c(Ft_d,  as.vector(m %*% data$N))
    Fw_d  <- c(Fw_d,  as.vector((m + s) %*% data$N))
    Ftp_d <- c(Ftp_d, as.vector(f_m %*% data$N))
    Fwp_d <- c(Fwp_d, as.vector((f_m + f_s) %*% data$N))
    unit_m <- unit_m + colSums(m); unit_s <- unit_s + colSums(s)
    n_draws <- n_draws + nrow(ch)
  }
  hpd <- function(x) coda::HPDinterval(coda::as.mcmc(matrix(x, ncol = 1)), prob = 0.95)[1, ]
  ht <- hpd(Ft_d); hw <- hpd(Fw_d)
  list(Ft_total = mean(Ft_d), Ft_total_lo = unname(ht["lower"]), Ft_total_hi = unname(ht["upper"]),
       Fw_total = mean(Fw_d), Fw_total_lo = unname(hw["lower"]), Fw_total_hi = unname(hw["upper"]),
       Ft_pkg_total = mean(Ftp_d), Fw_pkg_total = mean(Fwp_d),
       unit_manufactured = data$N * unit_m / n_draws, unit_stolen = data$N * unit_s / n_draws,
       available = TRUE)
}, error = function(e) {
  cat(sprintf("[R-Model] NOTE: Ft/Fw computation failed (%s) -- reporting NA.\n", conditionMessage(e)))
  list(Ft_total = NA_real_, Ft_total_lo = NA_real_, Ft_total_hi = NA_real_,
       Fw_total = NA_real_, Fw_total_lo = NA_real_, Fw_total_hi = NA_real_,
       Ft_pkg_total = NA_real_, Fw_pkg_total = NA_real_,
       unit_manufactured = rep(NA_real_, nrow(data)), unit_stolen = rep(NA_real_, nrow(data)),
       available = FALSE)
})

# Per-unit Maximum A Posteriori (MAP) classification
piZi_avg <- Reduce(`+`, lapply(samples, function(ch) ch$piZi)) / length(samples)
map_class <- apply(piZi_avg, 1, which.max)  # 1=No Fraud, 2=Incremental, 3=Extreme

n_no_fraud    <- sum(map_class == 1)
n_incremental <- sum(map_class == 2)
n_extreme     <- sum(map_class == 3)
n_flagged     <- n_incremental + n_extreme

out_summary <- data.frame(
  total_units = nrow(data),
  p_no_fraud_median = pi_median[1],
  p_incremental_median = pi_median[2],
  p_extreme_median = pi_median[3],
  p_no_fraud_hpd95_lo = pi_hpd["pi[1]", "lower"],
  p_no_fraud_hpd95_hi = pi_hpd["pi[1]", "upper"],
  p_incremental_hpd95_lo = pi_hpd["pi[2]", "lower"],
  p_incremental_hpd95_hi = pi_hpd["pi[2]", "upper"],
  p_extreme_hpd95_lo = pi_hpd["pi[3]", "lower"],
  p_extreme_hpd95_hi = pi_hpd["pi[3]", "upper"],
  fraud_share_sum_of_medians = pi_median[2] + pi_median[3],
  fraud_share_joint_median = fraud_share_joint_median,
  fraud_share_hpd95_lo = fraud_share_joint_hpd[1, "lower"],
  fraud_share_hpd95_hi = fraud_share_joint_hpd[1, "upper"],
  fraud_share_cons_hpd95_lo = pi_hpd["pi[2]", "lower"] + pi_hpd["pi[3]", "lower"],
  fraud_share_cons_hpd95_hi = pi_hpd["pi[2]", "upper"] + pi_hpd["pi[3]", "upper"],
  rhat_pi = rhat,
  w_form = W_FORM,
  conv_rule = CONV_RULE,
  max_auto = MAX_AUTO,
  M_pi_no_fraud = M_pi[1],
  M_pi_incremental = M_pi[2],
  M_pi_extreme = M_pi[3],
  D_pi_no_fraud = D_pi[1],
  D_pi_incremental = D_pi[2],
  D_pi_extreme = D_pi[3],
  Ft_total = fraud_votes$Ft_total,
  Ft_total_hpd95_lo = fraud_votes$Ft_total_lo,
  Ft_total_hpd95_hi = fraud_votes$Ft_total_hi,
  Fw_total = fraud_votes$Fw_total,
  Fw_total_hpd95_lo = fraud_votes$Fw_total_lo,
  Fw_total_hpd95_hi = fraud_votes$Fw_total_hi,
  Ft_pkg_total = fraud_votes$Ft_pkg_total,                    # package convention (rates x N), comparison only
  Fw_pkg_total = fraud_votes$Fw_pkg_total,
  fraud_votes_available = fraud_votes$available,             # FALSE means the Ft/Fw fields above are all NA
  fraud_votes_definition = "model",                           # N*[f.m*(1-tau) + f.s*tau*(1-nu)], per draw
  fraud_votes_interval_is_conservative_sum = FALSE,           # exact joint 95% HPD of the per-draw totals
  n_regions_flagged = n_flagged,
  n_regions_no_fraud = n_no_fraud,
  n_regions_incremental = n_incremental,
  n_regions_extreme = n_extreme,
  elapsed_seconds = elapsed,
  n_iter = n_iter,
  n_chains = n_chains,
  burn_in = burn_in,
  n_adapt = n_adapt,
  use_parcomp = use_parcomp
)
write.csv(out_summary, output_path, row.names = FALSE)

units_path <- sub("\\.csv$", "_units.csv", output_path)
write.csv(data.frame(unit_index = seq_len(nrow(data)),
                     p_no_fraud = piZi_avg[, 1],
                     p_incremental = piZi_avg[, 2],
                     p_extreme = piZi_avg[, 3],
                     map_class = map_class - 1,
                     manufactured_votes = fraud_votes$unit_manufactured,
                     stolen_votes = fraud_votes$unit_stolen),
          units_path, row.names = FALSE)

cat(sprintf("[R-Model] Summaries saved to %s and %s\n", output_path, units_path))
