"""
make_figures.py

Generates every figure used in manuscript.tex. Two data generations are used:
  - "long-chain configuration": n.iter=5000, burn.in=1000, n.adapt=1000.
    Full coverage (dem: 174/174 cells; con: 174/174 cells) across all 11
    elections, both leader codings.
  - "short-chain configuration": n.iter=1000, burn.in=300, n.adapt=1000.
    Full coverage (dem: 174/174 cells; con: 174/174 cells) across all 11
    elections, both leader codings.

Run from a directory containing:
  eforensics_parsed_results_dem.csv   (long-chain configuration, dem-coded, 174 rows)
  parsed_con_results.csv              (long-chain configuration, con-coded, 174 rows)
  test_parsed_dem.csv                 (short-chain configuration, dem-coded, 174 rows)
  test_parsed_con.csv                 (short-chain configuration, con-coded, 174 rows)

Each CSV has one row per election/level/channel/source/leader_side cell, with
columns elec, level, channel, source, fraud_share, rhat (see
parse_mebane_logs.py, which builds these files from the per-cell sweep logs
written by run_mebane_r_all_parallel_bidirectional.sh).
"""
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'font.family': 'serif'})

# ---------- Load both data generations ----------
prev_dem = pd.read_csv('eforensics_parsed_results_dem.csv')
prev_con = pd.read_csv('parsed_con_results.csv')
prev_dem['elec'] = prev_dem['elec'].astype(str)
prev_con['elec'] = prev_con['elec'].astype(str)
# Long-chain con-coded grid now has full coverage at n.iter=5000, so no
# elections need to be excluded here (previously pres20 was dropped because
# the long-chain con grid was still partial at that election).

new_dem = pd.read_csv('test_parsed_dem.csv')
new_con = pd.read_csv('test_parsed_con.csv')
new_dem['elec'] = new_dem['elec'].astype(str)
new_con['elec'] = new_con['elec'].astype(str)

# ======================================================================
# Figure 1a: real vs null scatter, PREVIOUS settings (n.iter=5000)
# ======================================================================
def make_scatter(dem, con, fname, title_suffix):
    p = dem.pivot_table(index=['elec','level','channel'], columns='source', values='fraud_share')
    pr = p.dropna()
    pc = con.pivot_table(index=['elec','level','channel'], columns='source', values='fraud_share')
    prc = pc.dropna()

    fig, ax = plt.subplots(1, 2, figsize=(9, 4.2))
    for a, nullcol, title in zip(ax, ['marginal_null','joint_null'], ['Marginal null', 'Joint null']):
        a.scatter(pr[nullcol], pr['real'], s=22, alpha=0.75, color='#1f4e79', label=f'Dem-coded (n={len(pr)})')
        a.scatter(prc[nullcol], prc['real'], s=32, alpha=0.9, color='#c0392b', marker='^', label=f'Con-coded (n={len(prc)})')
        lim = max(pr[nullcol].max(), pr['real'].max(), prc[nullcol].max(), prc['real'].max()) * 1.05
        a.plot([0, lim], [0, lim], 'k--', linewidth=0.8, label='45\u00b0 (real = null)')
        a.set_xlim(0, lim); a.set_ylim(0, lim)
        a.set_xlabel(f'{title} fraud share')
        a.set_ylabel('Real-data fraud share')
        a.set_title(f'{title}{title_suffix}')
        a.legend(fontsize=7, loc='upper left')
    plt.tight_layout()
    plt.savefig(fname)
    plt.close()
    r_m = pr['real'].corr(pr['marginal_null']); r_j = pr['real'].corr(pr['joint_null'])
    print(f"{fname}: dem trios={len(pr)}, con trios={len(prc)}, corr_marginal={r_m:.4f}, corr_joint={r_j:.4f}")

make_scatter(prev_dem, prev_con, 'fig1a_prev_settings.pdf', ' (long-chain configuration)')
make_scatter(new_dem, new_con, 'fig1b_new_settings.pdf', ' (short-chain configuration, full grid)')

# ======================================================================
# Figure 2: real fraud share by election x channel, chronological (NEW settings)
# ======================================================================
elec_order = ['pres16','pres17','18','19','pres18','20','pres19','21','pres20','22','pres21']
elec_label = {'pres16':'Pres(02)','pres17':'Pres(07)','18':'Gen(08)','19':'Gen(12)','pres18':'Pres(12)',
              '20':'Gen(16)','pres19':'Pres(17)','21':'Gen(20)','pres20':'Pres(22)','22':'Gen(24)','pres21':'Pres(25)'}
real = new_dem[new_dem['source']=='real'].copy()
real = real[real['level']=='dong']
# Note: by this point new_dem already has election 20's bonus total_no_early cells removed
# (see the exclusion above); total_no_early rows for the five genuinely pre-early-voting
# elections (18, 19, pres16, pres17, pres18) are retained, since that is their only channel.
real['elec_o'] = real['elec'].map({e:i for i,e in enumerate(elec_order)})
real = real.sort_values(['elec_o'])

fig, ax = plt.subplots(figsize=(9, 4))
channels_order = ['total_no_early','sameday','early','pooled']
colors = {'total_no_early':'#7f7f7f','sameday':'#2ca02c','early':'#ff7f0e','pooled':'#1f4e79'}
width = 0.2
xs = np.arange(len(elec_order))
for i, ch in enumerate(channels_order):
    sub = real[real['channel']==ch].set_index('elec_o')['fraud_share']
    vals = [sub.get(x, np.nan) for x in xs]
    ax.bar(xs + (i-1.5)*width, vals, width=width, label=ch, color=colors[ch])
ax.axvline(4.5, color='k', linestyle=':', linewidth=1)
ax.text(4.55, ax.get_ylim()[1]*0.92, 'early voting introduced (2014)', fontsize=7, rotation=0)
ax.axvline(6.5, color='r', linestyle=':', linewidth=1)
ax.text(6.55, ax.get_ylim()[1]*0.80, '2020 fraud claims begin', fontsize=7, color='r')
ax.set_xticks(xs)
ax.set_xticklabels([elec_label[e] for e in elec_order], rotation=45, ha='right')
ax.set_ylabel('Real-data fraud share (dong level)')
ax.legend(fontsize=7, ncol=4, loc='upper left')
plt.tight_layout()
plt.savefig('fig2_chronological.pdf')
plt.close()

# ======================================================================
# Figure 3: pres18 dem vs con grouped bars (NEW settings)
# ======================================================================
fig, axes = plt.subplots(1, 2, figsize=(8, 3.6), sharey=True)
sources = ['real','marginal_null','joint_null']
src_labels = ['Real','Marginal\nnull','Joint\nnull']
for ax, level in zip(axes, ['dong','constituency']):
    d_vals = [new_dem[(new_dem['elec']=='pres18')&(new_dem['level']==level)&(new_dem['channel']=='total_no_early')&(new_dem['source']==s)]['fraud_share'].values[0] for s in sources]
    c_vals = [new_con[(new_con['elec']=='pres18')&(new_con['level']==level)&(new_con['channel']=='total_no_early')&(new_con['source']==s)]['fraud_share'].values[0] for s in sources]
    xs = np.arange(3)
    ax.bar(xs-0.18, d_vals, width=0.36, label='Dem-coded leader', color='#1f4e79')
    ax.bar(xs+0.18, c_vals, width=0.36, label='Con-coded leader', color='#c0392b')
    ax.set_xticks(xs); ax.set_xticklabels(src_labels)
    ax.set_title(f'pres18 (2012), {level}')
    ax.set_ylabel('Fraud share' if level=='dong' else '')
axes[0].legend(fontsize=8, loc='upper right')
plt.tight_layout()
plt.savefig('fig3_pres18_bidirectional.pdf')
plt.close()

# ======================================================================
# Figure 4: 2024 general election (22) dem vs con grouped bars (NEW settings)
# ======================================================================
fig, axes = plt.subplots(1, 2, figsize=(8, 3.6), sharey=False)
panels = [('constituency', 'total', '22, constituency/total'), ('dong', 'pooled', '22, dong/pooled')]
for ax, (level, ch, title) in zip(axes, panels):
    d_vals = [new_dem[(new_dem['elec']=='22')&(new_dem['level']==level)&(new_dem['channel']==ch)&(new_dem['source']==s)]['fraud_share'].values[0] for s in sources]
    c_vals = [new_con[(new_con['elec']=='22')&(new_con['level']==level)&(new_con['channel']==ch)&(new_con['source']==s)]['fraud_share'].values[0] for s in sources]
    xs = np.arange(3)
    ax.bar(xs-0.18, d_vals, width=0.36, label='Dem-coded leader', color='#1f4e79')
    ax.bar(xs+0.18, c_vals, width=0.36, label='Con-coded leader', color='#c0392b')
    ax.set_xticks(xs); ax.set_xticklabels(src_labels)
    ax.set_title(title)
    ax.set_ylabel('Fraud share')
axes[0].legend(fontsize=8, loc='upper right')
plt.tight_layout()
plt.savefig('fig4_2024_bidirectional.pdf')
plt.close()

# ======================================================================
# Figure 5: settings-robustness check (previous vs new, matched dem cells)
# ======================================================================
merged = prev_dem.merge(new_dem, on=['elec','level','channel','source'], suffixes=('_prev','_new'))
fig, ax = plt.subplots(1, 2, figsize=(9, 4.2))
lim_r = max(merged['rhat_prev'].max(), merged['rhat_new'].max()) * 1.05
ax[0].scatter(merged['rhat_prev'], merged['rhat_new'], s=18, alpha=0.6, color='#1f4e79')
ax[0].plot([0, lim_r], [0, lim_r], 'k--', linewidth=0.8)
ax[0].set_xlabel('max R-hat, long-chain configuration (n.iter=5000, burn=1000)')
ax[0].set_ylabel('max R-hat, short-chain configuration (n.iter=1000, burn=300)')
ax[0].set_title(f'R-hat: corr={merged["rhat_prev"].corr(merged["rhat_new"]):.2f}')
ax[0].set_xlim(0, lim_r); ax[0].set_ylim(0, lim_r)

lim_f = max(merged['fraud_share_prev'].max(), merged['fraud_share_new'].max()) * 1.05
ax[1].scatter(merged['fraud_share_prev'], merged['fraud_share_new'], s=18, alpha=0.6, color='#1f4e79')
ax[1].plot([0, lim_f], [0, lim_f], 'k--', linewidth=0.8)
ax[1].set_xlabel('Fraud share, long-chain configuration')
ax[1].set_ylabel('Fraud share, short-chain configuration')
ax[1].set_title(f'Fraud share: corr={merged["fraud_share_prev"].corr(merged["fraud_share_new"]):.3f}')
ax[1].set_xlim(0, lim_f); ax[1].set_ylim(0, lim_f)
plt.tight_layout()
plt.savefig('fig6_settings_robustness.pdf')
plt.close()
print(f"fig6: matched cells={len(merged)}, rhat corr={merged['rhat_prev'].corr(merged['rhat_new']):.4f}, "
      f"fraud_share corr={merged['fraud_share_prev'].corr(merged['fraud_share_new']):.4f}")

print("All figures written.")
