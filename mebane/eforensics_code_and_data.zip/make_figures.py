"""
make_figures.py

Generates the eforensics figures of the main text: the real-versus-null scatter
(fig1b_new_settings.pdf), the chronological bar chart (fig2_chronological.pdf)
and the two bidirectional leader-coding bar charts (fig3_pres18_bidirectional.pdf,
fig4_2024_bidirectional.pdf).

Input: appendix_full_results.csv, written by collect_eforensics_results.py from
the per-cell run logs. Only the short-chain configuration (dataset
'new_settings'; n.iter=1000, burn-in=300, n.adapt=1000) is used, under both
leader codings. Each row is one election/level/channel/source/leader_side cell.
"""
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'font.family': 'serif'})

# ---------- Load results (short-chain configuration) ----------
# From collect_eforensics_results.py. The long-chain configuration is no longer
# part of the paper (its CSVs are kept in long_chain_archive/).
_full = pd.read_csv('appendix_full_results.csv')
_full['elec'] = _full['elec'].astype(str)
_short = _full[_full['dataset'] == 'new_settings']
new_dem = _short[_short['leader_side'] == 'dem'].copy()
new_con = _short[_short['leader_side'] == 'con'].copy()

# ======================================================================
# Figure 1a: real vs null scatter, PREVIOUS settings (n.iter=5000)
# ======================================================================
def make_scatter(dem, con, fname, title_suffix):
    p = dem.pivot_table(index=['elec','level','channel'], columns='source', values='fraud_share')
    pr = p.dropna()
    pc = con.pivot_table(index=['elec','level','channel'], columns='source', values='fraud_share')
    prc = pc.dropna()

    fig, ax = plt.subplots(1, 2, figsize=(9, 4.2))
    for a, nullcol, title in zip(ax, ['marginal_null','joint_null'], ['Marginal null', 'Joint null']):
        a.scatter(pr[nullcol], pr['real'], s=22, alpha=0.75, color='#1f4e79', label=f'Dem-coded (n={len(pr)})')
        a.scatter(prc[nullcol], prc['real'], s=32, alpha=0.9, color='#c0392b', marker='^', label=f'Con-coded (n={len(prc)})')
        lim = max(pr[nullcol].max(), pr['real'].max(), prc[nullcol].max(), prc['real'].max()) * 1.05
        a.plot([0, lim], [0, lim], 'k--', linewidth=0.8, label='45\u00b0 (real = null)')
        a.set_xlim(0, lim); a.set_ylim(0, lim)
        a.set_xlabel(f'{title} fraud share')
        a.set_ylabel('Real-data fraud share')
        r_dem = pr['real'].corr(pr[nullcol]); r_con = prc['real'].corr(prc[nullcol])
        a.set_title(f'{title}{title_suffix}\n(Dem $r$={r_dem:.2f}, Con $r$={r_con:.2f})')
        a.legend(fontsize=7, loc='upper left')
    plt.tight_layout()
    plt.savefig(fname)
    plt.close()
    r_m = pr['real'].corr(pr['marginal_null']); r_j = pr['real'].corr(pr['joint_null'])
    print(f"{fname}: dem trios={len(pr)}, con trios={len(prc)}, corr_marginal={r_m:.4f}, corr_joint={r_j:.4f}")

make_scatter(new_dem, new_con, 'fig1b_new_settings.pdf', ' (short-chain configuration)')

# ======================================================================
# Figure 2: real fraud share by election x channel, chronological (NEW settings)
# ======================================================================
elec_order = ['pres16','pres17','18','19','pres18','20','pres19','21','pres20','22','pres21']
elec_label = {'pres16':'Pres(02)','pres17':'Pres(07)','18':'Gen(08)','19':'Gen(12)','pres18':'Pres(12)',
              '20':'Gen(16)','pres19':'Pres(17)','21':'Gen(20)','pres20':'Pres(22)','22':'Gen(24)','pres21':'Pres(25)'}
real = new_dem[new_dem['source']=='real'].copy()
real = real[real['level']=='dong']
# Democratic-coded leader. total_no_early rows exist only for the five pre-early-voting
# elections (18, 19, pres16, pres17, pres18), where it is the only channel.
real['elec_o'] = real['elec'].map({e:i for i,e in enumerate(elec_order)})
real = real.sort_values(['elec_o'])

fig, ax = plt.subplots(figsize=(9, 4))
channels_order = ['total_no_early','sameday','early','pooled']
colors = {'total_no_early':'#7f7f7f','sameday':'#2ca02c','early':'#ff7f0e','pooled':'#1f4e79'}
hatches = {'total_no_early':'', 'sameday':'...', 'early':'///', 'pooled':'xxx'}   # readable in black and white
width = 0.2
xs = np.arange(len(elec_order))
for i, ch in enumerate(channels_order):
    sub = real[real['channel']==ch].set_index('elec_o')['fraud_share']
    vals = [sub.get(x, np.nan) for x in xs]
    ax.bar(xs + (i-1.5)*width, vals, width=width, label=ch, color=colors[ch], hatch=hatches[ch], edgecolor='black', linewidth=0.4)
ax.axvline(4.5, color='k', linestyle=':', linewidth=1)
ax.text(4.55, ax.get_ylim()[1]*0.92, 'early voting introduced (2014)', fontsize=7, rotation=0)
ax.axvline(6.5, color='r', linestyle=':', linewidth=1)
ax.text(6.55, ax.get_ylim()[1]*0.80, '2020 fraud claims begin', fontsize=7, color='r')
ax.set_xticks(xs)
ax.set_xticklabels([elec_label[e] for e in elec_order], rotation=45, ha='right')
ax.set_ylabel('Real-data fraud share (dong level)')
ax.legend(fontsize=7, ncol=4, loc='upper left')
plt.tight_layout()
plt.savefig('fig2_chronological.pdf')
plt.close()

# ======================================================================
# Figure 3: pres18 dem vs con grouped bars (NEW settings)
# ======================================================================
fig, axes = plt.subplots(1, 2, figsize=(8, 3.6), sharey=True)
sources = ['real','marginal_null','joint_null']
src_labels = ['Real','Marginal\nnull','Joint\nnull']
for ax, level in zip(axes, ['dong','constituency']):
    d_vals = [new_dem[(new_dem['elec']=='pres18')&(new_dem['level']==level)&(new_dem['channel']=='total_no_early')&(new_dem['source']==s)]['fraud_share'].values[0] for s in sources]
    c_vals = [new_con[(new_con['elec']=='pres18')&(new_con['level']==level)&(new_con['channel']=='total_no_early')&(new_con['source']==s)]['fraud_share'].values[0] for s in sources]
    xs = np.arange(3)
    ax.bar(xs-0.18, d_vals, width=0.36, label='Dem-coded leader', color='#1f4e79', edgecolor='black', linewidth=0.4)
    ax.bar(xs+0.18, c_vals, width=0.36, label='Con-coded leader', color='#c0392b', hatch='///', edgecolor='black', linewidth=0.4)
    ax.set_xticks(xs); ax.set_xticklabels(src_labels)
    ax.set_title(f'pres18 (2012), {level}')
    ax.set_ylabel('Fraud share' if level=='dong' else '')
axes[0].legend(fontsize=8, loc='upper right')
plt.tight_layout()
plt.savefig('fig3_pres18_bidirectional.pdf')
plt.close()

# ======================================================================
# Figure 4: 2024 general election (22) dem vs con grouped bars (NEW settings)
# ======================================================================
fig, axes = plt.subplots(1, 2, figsize=(8, 3.6), sharey=False)
panels = [('constituency', 'total', '22, constituency/total'), ('dong', 'pooled', '22, dong/pooled')]
for ax, (level, ch, title) in zip(axes, panels):
    d_vals = [new_dem[(new_dem['elec']=='22')&(new_dem['level']==level)&(new_dem['channel']==ch)&(new_dem['source']==s)]['fraud_share'].values[0] for s in sources]
    c_vals = [new_con[(new_con['elec']=='22')&(new_con['level']==level)&(new_con['channel']==ch)&(new_con['source']==s)]['fraud_share'].values[0] for s in sources]
    xs = np.arange(3)
    ax.bar(xs-0.18, d_vals, width=0.36, label='Dem-coded leader', color='#1f4e79', edgecolor='black', linewidth=0.4)
    ax.bar(xs+0.18, c_vals, width=0.36, label='Con-coded leader', color='#c0392b', hatch='///', edgecolor='black', linewidth=0.4)
    ax.set_xticks(xs); ax.set_xticklabels(src_labels)
    ax.set_title(title)
    ax.set_ylabel('Fraud share')
axes[0].legend(fontsize=8, loc='upper right')
plt.tight_layout()
plt.savefig('fig4_2024_bidirectional.pdf')
plt.close()


print("All figures written.")
