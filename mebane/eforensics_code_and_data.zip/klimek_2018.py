#!/usr/bin/env python3
"""

Terminology: 'plug-in' parameters below (a, v, sigma_a, sigma_vL, sigma_vR) are what
the manuscript calls the fraud-free distributions computed from the observed data
before estimation.
klimek_2018.py

The ballot-stuffing fit of Klimek, Jimenez, Hidalgo, Hinteregger & Thurner
(2018, PLOS ONE 13(10):e0204975; "K18"), which applies the parametric model
of Klimek, Yegorov, Hanel & Thurner (2012, PNAS 109:16469; "K12").

Where K18 specifies a step, K18 is followed; where it is silent, K12's main
text and SI are followed. Step by step:

  Model (K18: "we apply the parametric model that was proposed in [K12]").
      Clean turnout a_i ~ N(a, sigma_a), clean leader share v_i ~
      N(v, sqrt(2) sigma_vL), both on (0,1). With probability f_i,
      incremental fraud: x_i ~ |N(0, sigma_vR)| on (0,1); turnout becomes
      a + x(1-a), leader votes a v + x(1-a) + x^alpha (1-v) a (per elector).
      With probability f_e, extreme fraud: the same with y_i = 1-|N(0,
      sigma_x)|, sigma_x = 0.075. [K12 SI protocol iii-v.]
  Plug-ins (K18: "means and standard deviations estimated from the data";
      the specific estimators are K12's): a, v = maximizing 1%-bin of the
      empirical turnout / leader-share distributions (K12 main text: "the
      value that maximizes"; the SI's "(first local) maximum" is read as the
      maximizing bin); sigma_vL, sigma_vR = one-sided RMS deviations of v_i
      below / above v (K12 SI Eqs. S1-S2); sigma_a = RMS deviation of a_i
      from a over units with a_i < a and v_i < v (K12 SI).
      NOTE: the K12 SI typesets the incremental-fraud draw as
      |N(0, sqrt(sigma_vR))|. We use |N(0, sigma_vR)|: sigma_vR is defined
      in Eq. S2 as a width in vote-share units and is called "the
      incremental fraud width", and a square root would make x_i's scale
      depend on the units of v. This reading is unchanged from earlier
      versions of the code.
  Objective (K18): residual sum of squares between the observed and model
      two-dimensional turnout/leader-share fingerprints (unit counts per
      cell). Bin width: K18 does not state one; K12 bins at 1% ("one bin
      corresponding to 1%"), so the fingerprint is 100 x 100.
  Grid (K12 SI): f_i, f_e in {0, 0.01, ..., 1}, f_i + f_e <= 1;
      alpha in {0, 0.1, ..., 5}.
  Repetition (K18): "Results are taken from 200 sweeps over the feasible
      parameter range"; mean and SD over sweeps are reported. Each sweep is
      one fresh realization of model units scored over the whole grid.
      N_REAL = 200.

EXACT GRID SOLVE. Each model unit carries one uniform U_i: incremental if
U_i < f_i, extreme if f_i <= U_i < f_i + f_e. Since f_i and f_i + f_e lie on
the 0.01 grid, the model fingerprint at grid point (j, l) is
    clean + A_j + B_l,   A_j = sum_{k<j} a_k,  B_l = sum_{k<l} b_k,
where a_k, b_k are the (sparse) changes to the fingerprint from the units
with U in [k/100, (k+1)/100). RSS(j,l) = ||r - A_j - B_l||^2 with
r = observed - clean, and every term is a 2-D cumulative sum of Gram
matrices of the sparse a_k, b_k, so the full 101 x 101 grid is scored
exactly, in integer arithmetic, per alpha. This returns the same minimizer
as scoring each grid point directly (fit_realization_dense below, kept as
the reference; see klimek_2018_verify.py).

USAGE: library; estimate(t, v) -> dict. Drivers: klimek_2018_all.py.
"""
import numpy as np
import scipy.sparse as sp

from klimek_original import (AGRID, SIGMA_X, fraud_share, half_normal_01,  # noqa: F401
                             plugins, trunc_normal)

NB = 100            # 1% bins per axis (K12 SI)
N_REAL = 200        # sweeps (K18)
FSTEPS = 101        # f grid 0..1 step 0.01 (K12 SI)


def bin2d(t, v, nb=NB):
    it = np.clip((t * nb).astype(np.int64), 0, nb - 1)
    iv = np.clip((v * nb).astype(np.int64), 0, nb - 1)
    return it * nb + iv


def fingerprint(t, v, nb=NB):
    return np.bincount(bin2d(t, v, nb), minlength=nb * nb).astype(np.int64)


def model_units(p, n, rng):
    u = rng.random((5, n))
    return dict(a=trunc_normal(u[0], p['a'], p['sigma_a']),
                v=trunc_normal(u[1], p['v'], np.sqrt(2) * p['sigma_vL']),
                x=half_normal_01(u[2], p['sigma_vR']),
                y=1 - half_normal_01(u[3], SIGMA_X), U=u[4])


def _cum2(M):
    out = np.zeros((M.shape[0] + 1, M.shape[1] + 1), dtype=np.int64)
    out[1:, 1:] = M.cumsum(0).cumsum(1)
    return out


def fit_realization(obs_hist, m, nb=NB):
    """Exact minimizer (f_i, f_e, alpha) of the 2-D RSS for one realization."""
    C = nb * nb
    n = len(m['U'])
    g = np.minimum((m['U'] * 100).astype(np.int64), FSTEPS - 2)
    clean_bin = bin2d(m['a'], m['v'], nb)
    r = obs_hist.astype(np.int64) - np.bincount(clean_bin, minlength=C)
    ones = np.ones(n, np.int64)

    def inc(bins):
        return sp.csr_matrix((ones, (g, bins)), shape=(FSTEPS - 1, C))

    Dc = inc(clean_bin)
    t_inc = m['a'] + m['x'] * (1 - m['a'])
    t_ext = m['a'] + m['y'] * (1 - m['a'])
    jj, ll = np.meshgrid(np.arange(FSTEPS), np.arange(FSTEPS), indexing='ij')
    invalid = ll < jj
    big = np.iinfo(np.int64).max
    best_S, best = None, None
    for alpha in AGRID:
        Di = inc(bin2d(t_inc, fraud_share(m, m['x'], alpha), nb))
        De = inc(bin2d(t_ext, fraud_share(m, m['y'], alpha), nb))
        Da, Db = (Di - De).tocsr(), (De - Dc).tocsr()
        na = np.diag(_cum2((Da @ Da.T).toarray()))
        nbb = np.diag(_cum2((Db @ Db.T).toarray()))
        cab = _cum2((Da @ Db.T).toarray())
        ar = np.concatenate([[0], np.cumsum(Da @ r)])
        br = np.concatenate([[0], np.cumsum(Db @ r)])
        S = (na - 2 * ar)[:, None] + (nbb - 2 * br)[None, :] + 2 * cab
        S[invalid] = big
        k = np.unravel_index(np.argmin(S), S.shape)
        if best_S is None or S[k] < best_S:
            best_S, best = S[k], (k[0] / 100, (k[1] - k[0]) / 100, float(alpha))
    return best


def fit_realization_dense(obs_hist, m, nb=NB):
    """Reference implementation: every grid point scored from dense cumulative
    fingerprints (the original solver). Used only for verification."""
    C = nb * nb
    clean_bin = bin2d(m['a'], m['v'], nb)
    clean_hist = np.bincount(clean_bin, minlength=C).astype(float)
    g = np.minimum((m['U'] * 100).astype(int), 100)

    def cum_hist(bins):
        c = np.bincount(g * C + bins, minlength=101 * C).reshape(101, C)
        return np.vstack([np.zeros((1, C)), np.cumsum(c, axis=0)[:-1]])

    r = obs_hist - clean_hist
    CleanCum = cum_hist(clean_bin)
    jj, ll = np.meshgrid(np.arange(101), np.arange(101), indexing='ij')
    best = (np.inf, None)
    for alpha in AGRID:
        IncCum = cum_hist(bin2d(m['a'] + m['x'] * (1 - m['a']), fraud_share(m, m['x'], alpha), nb))
        ExtCum = cum_hist(bin2d(m['a'] + m['y'] * (1 - m['a']), fraud_share(m, m['y'], alpha), nb))
        A, B = IncCum - ExtCum, ExtCum - CleanCum
        S = ((A ** 2).sum(1) - 2 * (A @ r))[:, None] + ((B ** 2).sum(1) - 2 * (B @ r))[None, :] + 2 * (A @ B.T)
        S = np.where(ll >= jj, S, np.inf)
        k = np.unravel_index(np.argmin(S), S.shape)
        if S[k] < best[0]:
            best = (S[k], (k[0] / 100, (k[1] - k[0]) / 100, float(alpha)))
    return best[1]


def estimate(t_obs, v_obs, n_real=N_REAL, seed=0, nb=NB, return_fits=False):
    """K18 fit: plug-in clean component, 2-D RSS on 1% fingerprints, exact grid,
    mean and SD over n_real sweeps."""
    t_obs, v_obs = np.asarray(t_obs, float), np.asarray(v_obs, float)
    p = plugins(t_obs, v_obs)
    obs_hist = fingerprint(t_obs, v_obs, nb)
    rng = np.random.default_rng(seed)
    fits = np.array([fit_realization(obs_hist, model_units(p, len(v_obs), rng), nb) for _ in range(n_real)])
    out = dict(p)
    for k, name in enumerate(('fi', 'fe', 'alpha')):
        out[name] = float(fits[:, k].mean())
        out[name + '_sd'] = float(fits[:, k].std(ddof=1))
    tot = fits[:, 0] + fits[:, 1]
    out.update(fraud_share=float(tot.mean()), fraud_share_sd=float(tot.std(ddof=1)),
               n=len(v_obs), bins=nb, n_real=n_real)
    if return_fits:
        out['fits'] = fits
    return out
