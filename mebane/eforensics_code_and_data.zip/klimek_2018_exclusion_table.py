"""Main-text table of incremental-fraud shares f_i with regional voting blocs
excluded (winner coding, raw fingerprints, real data), both unit levels."""
import pandas as pd
import klimek_units as KU

m = pd.read_csv('klimek_2018_output/klimek_2018_winner_results.csv', dtype={'elec': str})
m = m[(m.source == 'real') & (~m.residualized)]
x = pd.read_csv('klimek_2018_output/klimek_2018_exclusion_results.csv', dtype={'elec': str})
d = pd.concat([m, x], ignore_index=True)
LEVELS = [lv for lv in KU.complete_levels(x, KU.EXCL_PER_LEVEL) if (m.level == lv).sum() == 5]
VAR = ['all', 'noH', 'noHY', 'noHTK']


def cell(r):
    v, s = 100 * r.fi, 100 * r.fi_sd
    return f"{v:.0f}" if s < 1 else f"{v:.0f} [{max(v - s, 0):.0f}, {v + s:.0f}]"


lines = [r"\begin{tabular}{lcccc}", r"\toprule",
         r"Election & All units & Excl.\ H & Excl.\ H, Y & Excl.\ H, GD \\"]
for lv, head in [(l, h) for l, h in (('dong', 'Dong'), ('tpg', 'Polling district')) if l in LEVELS]:
    lines += [r"\midrule"] + ([rf"\multicolumn{{5}}{{l}}{{\emph{{{head}}}}} \\"] if len(LEVELS) > 1 else [])
    for e in KU.PREEARLY:
        rows = {r.variant: r for r in d[(d.elec == e) & (d.level == lv)].itertuples()}
        lines.append(f"{KU.LABEL[e]} & " + " & ".join(cell(rows[v]) for v in VAR) + r" \\")
    nn = [d[(d.level == lv) & (d.variant == v)].n for v in VAR]
    lines.append(r"Units retained & " + " & ".join(f"{s.min():,}--{s.max():,}" for s in nn) + r" \\")
lines += [r"\bottomrule", r"\end{tabular}"]
d[d.level.isin(LEVELS)].to_csv('klimek_2018_output/klimek_preearly_exclusion_results.csv', index=False)
open('klimek_2018_output/klimek_exclusion_table.tex', 'w').write("\n".join(lines) + "\n")
print("wrote klimek_2018_output/klimek_exclusion_table.tex")
