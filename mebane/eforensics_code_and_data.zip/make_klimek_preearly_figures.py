#!/usr/bin/env python3
"""
make_klimek_preearly_figures.py

Fingerprint figures for the Klimek et al. (2018)-procedure analysis of the
five elections held before early voting existed, at the polling-district
(투표구) level, national winner as leader. Nothing is refitted: fitted
parameters are read from klimek_2018_output/klimek_2018_winner_results.csv
and klimek_2018_exclusion_results.csv (written by klimek_2018_all.py and
klimek_2018_winner_table.py).

  fig_klimek_preearly_fit_pres.pdf, fig_klimek_preearly_fit_gen.pdf
      Per election: observed fingerprint | units coloured by region |
      model fingerprint at the fitted mean parameters.
  fig_klimek_preearly_nulls_pres.pdf, fig_klimek_preearly_nulls_gen.pdf
      Per election: fingerprints of the real returns and of the joint null.
  fig_klimek_pres2012.pdf
      Pres 2012: observed, regions, model on all units (top); model with
      Honam, Honam+Yeongnam, Honam+Gyeongbuk/Daegu excluded (bottom).

All fingerprints use the fit's own 1% bins. Usage: python3 make_klimek_preearly_figures.py [--level tpg]
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import klimek_2018_viz as V                     # noqa: E402
import klimek_units as KU                       # noqa: E402
import mebane_r_driver_bidirectional as base    # noqa: E402
from klimek_2018_all import EXCLUSIONS, HONAM, TK, YEONGNAM   # noqa: E402

PRES = ['pres16', 'pres17', 'pres18']
GEN = ['18', '19']
VLAB = {'noH': 'Honam excluded', 'noHY': 'Honam and Yeongnam excluded', 'noHTK': 'Honam and Gyeongbuk/Daegu excluded'}


def panel(ax, H, vmin, vmax, title):
    from matplotlib.colors import LogNorm
    ax.imshow(np.ma.masked_less_equal(H.T, 0), origin='lower', extent=[0, 1, 0, 1], aspect='equal',
              cmap='viridis', norm=LogNorm(vmin=vmin, vmax=vmax), interpolation='nearest')
    ax.set_title(title, fontsize=8.5); ax.tick_params(labelsize=7)


def region_panel(ax, df, title):
    t, v = df['tau'], df['nu']
    tag = df['province_tag']
    for lab, msk, c, a in [('elsewhere', ~tag.isin(HONAM | YEONGNAM), '0.6', 0.3),
                           ('Yeongnam, other', tag.isin(YEONGNAM - TK), 'tab:cyan', 0.45),
                           ('Gyeongbuk/Daegu', tag.isin(TK), 'navy', 0.5),
                           ('Honam', tag.isin(HONAM), 'tab:red', 0.55)]:
        ax.scatter(t[msk], v[msk], s=0.8, c=c, alpha=a, lw=0, label=lab, rasterized=True)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.set_aspect('equal')
    ax.set_title(title, fontsize=8.5); ax.tick_params(labelsize=7)
    ax.legend(fontsize=6, loc='upper left', markerscale=6, frameon=False)


def vrange(*Hs):
    pos = np.concatenate([H[H > 0] for H in Hs])
    return pos.min(), pos.max()


def fit_title(r, head):
    return f"{head}\n$f_i$={r.fi:.2f} [SD {r.fi_sd:.2f}], $f_e$={r.fe:.3f}"


def main(level, outdir):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    w = pd.read_csv('klimek_2018_output/klimek_2018_winner_results.csv', dtype={'elec': str})
    fit = {e: w[(w.elec == e) & (w.level == level) & (~w.residualized) & (w.source == 'real')].iloc[0]
           for e in KU.PREEARLY}
    x = pd.read_csv('klimek_2018_output/klimek_2018_exclusion_results.csv', dtype={'elec': str})
    reals = {e: KU.load_units(e, level, KU.WINNER[e]) for e in KU.PREEARLY}
    lvname = 'polling-district' if level == 'tpg' else 'dong'

    for group, tag in ((PRES, 'pres'), (GEN, 'gen')):
        fig, axes = plt.subplots(len(group), 3, figsize=(7.6, 2.7 * len(group)), squeeze=False)
        for i, e in enumerate(group):
            Ho, Hm = V.observed(reals[e]['tau'], reals[e]['nu']), V.model(fit[e])
            vmin, vmax = vrange(Ho, Hm)
            panel(axes[i, 0], Ho, vmin, vmax, f"{KU.LABEL[e]}\nobserved (n={len(reals[e]):,})")
            region_panel(axes[i, 1], reals[e], f"{KU.LABEL[e]}\nunits by region")
            panel(axes[i, 2], Hm, vmin, vmax, fit_title(fit[e], "fitted Klimek model"))
            axes[i, 0].set_ylabel('winner vote share', fontsize=8)
        for ax in axes[-1]:
            ax.set_xlabel('turnout', fontsize=8)
        fig.tight_layout(); fig.savefig(os.path.join(outdir, f'fig_klimek_preearly_fit_{tag}.pdf'), dpi=200); plt.close(fig)

        fig, axes = plt.subplots(len(group), 2, figsize=(5.0, 2.45 * len(group)), squeeze=False)
        for i, e in enumerate(group):
            nul = base.generate_joint_null(reals[e])
            Hs = [V.observed(reals[e]['tau'], reals[e]['nu']), V.observed(nul['tau'], nul['nu'])]
            vmin, vmax = vrange(*Hs)
            for c, (H, nm) in enumerate(zip(Hs, ('real', 'joint null'))):
                panel(axes[i, c], H, vmin, vmax, f"{KU.LABEL[e]}: {nm}")
            axes[i, 0].set_ylabel('winner vote share', fontsize=8)
        for ax in axes[-1]:
            ax.set_xlabel('turnout', fontsize=8)
        fig.tight_layout(); fig.savefig(os.path.join(outdir, f'fig_klimek_preearly_nulls_{tag}.pdf'), dpi=200); plt.close(fig)

    e = 'pres18'
    fig, axes = plt.subplots(2, 3, figsize=(10.5, 7.4))
    Ho, Hm = V.observed(reals[e]['tau'], reals[e]['nu']), V.model(fit[e])
    vmin, vmax = vrange(Ho, Hm)
    panel(axes[0, 0], Ho, vmin, vmax, "observed (all units)")
    region_panel(axes[0, 1], reals[e], "units by region")
    panel(axes[0, 2], Hm, vmin, vmax, fit_title(fit[e], "fitted Klimek model, all units"))
    for c, (var, _) in enumerate(EXCLUSIONS):
        r = x[(x.elec == e) & (x.level == level) & (x.variant == var)].iloc[0]
        Hx = V.model(r)
        panel(axes[1, c], Hx, *vrange(Hx), fit_title(r, f"fitted model, {VLAB[var]}"))
    for ax in axes[:, 0]:
        ax.set_ylabel('winner vote share', fontsize=8)
    for ax in axes[1]:
        ax.set_xlabel('turnout', fontsize=8)
    fig.suptitle(f"Pres 2012, {lvname} level (winner: conservative candidate)", fontsize=10)
    fig.tight_layout(); fig.savefig(os.path.join(outdir, 'fig_klimek_pres2012.pdf'), dpi=200); plt.close(fig)
    print("wrote fig_klimek_preearly_{fit,nulls}_{pres,gen}.pdf and fig_klimek_pres2012.pdf")


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--level', default='tpg', choices=list(KU.LEVELS))
    ap.add_argument('--outdir', default='.')
    a = ap.parse_args()
    main(a.level, a.outdir)
