#!/usr/bin/env python3
"""
klimek_2018_all.py

Runs the Klimek et al. (2018) fit (klimek_2018.py: 1% 2-D fingerprints, RSS,
plug-in clean component, exact grid, 200 sweeps) over the five national
elections held before early voting existed, at two unit levels (dong and
투표구 polling district; klimek_units.py).

  main grid       5 elections x 2 levels x 2 leader codings x
                  {raw, province-residualized} x {real, joint null}  = 80 fits
                  -> klimek_2018_output/klimek_2018_all_results.csv
  exclusions      winner coding, raw fingerprint, real data, with Honam /
                  Honam+Yeongnam / Honam+Gyeongbuk-Daegu removed, both levels
                  = 30 fits (the 'all units' column is the main-grid fit)
                  -> klimek_2018_output/klimek_2018_exclusion_results.csv

The marginal null is not run: it keeps every unit at its observed turnout and
vote share plus small independent noise, so its fingerprint is essentially
the real one and it is not a fraud-free control for a fingerprint method.

Resumable: rows already present are skipped. Per-sweep fits are stored in
klimek_2018_output/sweeps/<key>.npy.

Usage: python3 klimek_2018_all.py [--part main|exclusion|all] [--levels dong,tpg] [--n-real 200]
  e.g. polling-district level only:  python3 klimek_2018_all.py --levels tpg
"""
import argparse
import os
import sys
import time

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import klimek_2018 as K18                       # noqa: E402
import klimek_analysis as KA                    # noqa: E402  (residualize only)
import klimek_units as KU                       # noqa: E402
import mebane_r_driver_bidirectional as base    # noqa: E402

OUTDIR = 'klimek_2018_output'
MAIN = os.path.join(OUTDIR, 'klimek_2018_all_results.csv')
EXCL = os.path.join(OUTDIR, 'klimek_2018_exclusion_results.csv')
SOURCES = ('real', 'joint_null')
HONAM = {'Gwangju', 'Jeonbuk', 'Jeonnam'}
YEONGNAM = {'Busan', 'Daegu', 'Ulsan', 'Gyeongbuk', 'Gyeongnam'}
TK = {'Daegu', 'Gyeongbuk'}
EXCLUSIONS = [('noH', HONAM), ('noHY', HONAM | YEONGNAM), ('noHTK', HONAM | TK)]
COLS = ['elec', 'level', 'leader_side', 'residualized', 'source', 'variant', 'n', 'bins', 'n_real',
        'a', 'v', 'sigma_a', 'sigma_vL', 'sigma_vR', 'fi', 'fi_sd', 'fe', 'fe_sd', 'alpha', 'alpha_sd',
        'fraud_share', 'fraud_share_sd', 'seconds']


def arrays(df, resid):
    t, v, prov = KU.turnout_share(df)
    if resid:
        t, v = KA.residualize(t, v, prov)
    return t, v


def done_keys(path):
    if not os.path.exists(path):
        return set()
    d = pd.read_csv(path, dtype={'elec': str})
    return set(zip(d.elec, d.level, d.leader_side, d.residualized, d.source, d.variant))


def fit_and_write(path, key, t, v, n_real):
    elec, level, side, resid, src, variant = key
    t0 = time.time()
    r = K18.estimate(t, v, n_real=n_real, return_fits=True)
    os.makedirs(os.path.join(OUTDIR, 'sweeps'), exist_ok=True)
    np.save(os.path.join(OUTDIR, 'sweeps', '_'.join(map(str, key)) + '.npy'), r.pop('fits'))
    row = dict(elec=elec, level=level, leader_side=side, residualized=resid, source=src, variant=variant,
               seconds=round(time.time() - t0, 1), **r)
    pd.DataFrame([row])[COLS].to_csv(path, mode='a', header=not os.path.exists(path), index=False)
    print(f"{elec:7s} {level:4s} {side} {'resid' if resid else 'raw  '} {src:10s} {variant:5s} n={r['n']:6d} "
          f"fi={r['fi']:.3f}±{r['fi_sd']:.3f} fe={r['fe']:.4f} alpha={r['alpha']:.2f} [{row['seconds']}s]", flush=True)


def run_main(n_real, levels):
    done = done_keys(MAIN)
    for level in levels:
        for elec in KU.PREEARLY:
            for side in ('dem', 'con'):
                real = KU.load_units(elec, level, side)
                data = {'real': real, 'joint_null': base.generate_joint_null(real)}
                for resid in (False, True):
                    for src in SOURCES:
                        key = (elec, level, side, resid, src, 'all')
                        if key not in done:
                            fit_and_write(MAIN, key, *arrays(data[src], resid), n_real)


def run_exclusion(n_real, levels):
    done = done_keys(EXCL)
    for level in levels:
        for elec in KU.PREEARLY:
            side = KU.WINNER[elec]
            real = KU.load_units(elec, level, side)
            for variant, excl in EXCLUSIONS:
                key = (elec, level, side, False, 'real', variant)
                if key not in done:
                    fit_and_write(EXCL, key, *arrays(real[~real['province_tag'].isin(excl)], False), n_real)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--part', default='all', choices=['main', 'exclusion', 'all'])
    ap.add_argument('--n-real', type=int, default=K18.N_REAL)
    ap.add_argument('--levels', default='dong,tpg', help="comma-separated subset of: dong,tpg")
    a = ap.parse_args()
    os.makedirs(OUTDIR, exist_ok=True)
    if a.part in ('main', 'all'):
        run_main(a.n_real, a.levels.split(','))
    if a.part in ('exclusion', 'all'):
        run_exclusion(a.n_real, a.levels.split(','))
    print("done", flush=True)
