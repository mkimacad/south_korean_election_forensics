#!/usr/bin/env python3
"""
make_tau_comparison.py

Latent-turnout (latent-turnout) robustness check. Parses the eforensics logs of the
latent-turnout sweep (EFORENSICS_WFORM=tau; ef_qbl_tau.R), pairs every run with the
observed-turnout run of the same cell, source and leader coding from
appendix_full_results.csv (short-chain configuration, dataset 'new_settings'),
and writes

  tau_comparison.csv          one row per paired run (both forms side by side)
  tau_summary_table.tex       main-text summary table (by data source)
  appendix_tables_tau.tex     appendix listing of every paired run
  tau_stats.txt               every number the manuscript cites
  fig_tau_vs_cond.pdf         latent vs conditional fraud share, every paired run
  fig_tau_real_vs_null.pdf    real vs null fraud share under the latent-turnout form
                              (mirrors the observed-turnout real-vs-null figures)
Figures include whichever leader codings are present (Dem-coded, and
Con-coded once output_data_tau/con_leader/ exists).

Only logs that carry the fork's "[ef_qbl_tau] ... LATENT-turnout" marker are
used, so a stray observed-turnout log cannot enter the comparison. Self-null
logs are excluded here (reported separately once that sweep is complete).

Usage: python3 make_tau_comparison.py [logs_dir ...]
       Logs must declare 'fraud_votes_definition : model' (current mebane_crosscheck.R);
       ALLOW_PACKAGE_FW=1 accepts older package-convention logs (not for the manuscript).
       default: output_data_tau/mebane_r_all_logs and, if present, output_data_tau/con_leader
"""
import glob
import os
import re
import sys

import numpy as np
import pandas as pd

MARK = "LATENT-turnout"
RES = re.compile(r"^RESULT:\s*([^/]+)/([^/]+)/([^/]+)/([^/]+)/leader=(\w+)", re.M)


def num(pat, s, cast=float):
    m = re.search(pat, s, re.M)
    return cast(m.group(1)) if m else np.nan


def parse(dirs):
    rows, skipped = [], {'no_marker': 0, 'no_result': 0}
    for d in dirs:
        for f in sorted(glob.glob(os.path.join(d, '*.log'))):
            s = open(f, errors='replace').read()
            if MARK not in s:
                skipped['no_marker'] += 1
                continue
            m = RES.search(s)
            if not m:
                skipped['no_result'] += 1
                continue
            fl = re.search(r"^n_regions_flagged\s*:\s*(\d+)/(\d+)", s, re.M)
            rows.append(dict(elec=m.group(1), level=m.group(2), channel=m.group(3), source=m.group(4),
                             leader_side=m.group(5),
                             fraud_share=num(r"^fraud_share_median\s*:\s*([0-9.]+)", s),
                             Fw=num(r"^Fw_total \(total fraud\)\s*:\s*([0-9.]+)", s),
                             fw_def=(re.search(r"^fraud_votes_definition\s*:\s*(\w+)", s, re.M) or [None, 'package'])[1],
                             rhat=num(r"^rhat_pi\s*:\s*([0-9.]+)", s),
                             n_flagged=int(fl.group(1)) if fl else np.nan,
                             n_units=int(fl.group(2)) if fl else np.nan))
    return pd.DataFrame(rows), skipped


def main():
    dirs = sys.argv[1:] or [p for p in ('output_data_tau/mebane_r_all_logs', 'output_data_tau/con_leader')
                            if os.path.isdir(p)]
    t, skipped = parse(dirs)
    t = t[t.source != 'model_self_null']
    if (t.fw_def != 'model').any() and os.environ.get('ALLOW_PACKAGE_FW') != '1':
        raise SystemExit(f"{int((t.fw_def != 'model').sum())} tau log(s) report fraudulent votes in the package "
                         "convention (rates x N). Rerun with the current mebane_crosscheck.R, or set "
                         "ALLOW_PACKAGE_FW=1 (not for the manuscript).")
    c = pd.read_csv('appendix_full_results.csv')
    c = c[c.dataset == 'new_settings'].copy()
    c['elec'] = c.elec.astype(str)
    k = ['elec', 'level', 'channel', 'source', 'leader_side']
    m = c[k + ['fraud_share', 'Fw', 'rhat', 'n_flagged']].merge(t, on=k, suffixes=('_cond', '_tau'))
    if len(m) != len(t):
        raise SystemExit(f"{len(t) - len(m)} tau run(s) have no conditional counterpart")
    m.to_csv('tau_comparison.csv', index=False)

    out = []
    P = out.append
    sides = sorted(m.leader_side.unique())
    P(f"tau runs paired: {len(m)} (leader codings: {sides}); logs skipped: {skipped}")
    P(f"cells per source: {m.groupby('source').size().to_dict()}")
    grp = [('real', m[m.source == 'real']), ('marginal_null', m[m.source == 'marginal_null']),
           ('joint_null', m[m.source == 'joint_null']), ('both nulls', m[m.source != 'real']), ('all', m)]
    tab = []
    for lab, d in grp:
        fc, ft = d.fraud_share_cond, d.fraud_share_tau
        st = dict(lab=lab, n=len(d), gt5_c=100 * (fc > .05).mean(), gt5_t=100 * (ft > .05).mean(),
                  n5_c=int((fc > .05).sum()), n5_t=int((ft > .05).sum()),
                  med_c=100 * fc.median(), med_t=100 * ft.median(), max_c=100 * fc.max(), max_t=100 * ft.max(),
                  nc_c=100 * (d.rhat_cond > 1.05).mean(), nc_t=100 * (d.rhat_tau > 1.05).mean(),
                  r=np.corrcoef(fc, ft)[0, 1], mad=100 * np.median(abs(fc - ft)), up=int((ft > fc).sum()))
        tab.append(st)
        P(f"[{lab}] n={st['n']} >5%: cond {st['n5_c']} ({st['gt5_c']:.1f}%) tau {st['n5_t']} ({st['gt5_t']:.1f}%); "
          f"median cond {st['med_c']:.1f} tau {st['med_t']:.1f}; max cond {st['max_c']:.1f} tau {st['max_t']:.1f}; "
          f"not converged cond {st['nc_c']:.0f}% tau {st['nc_t']:.0f}%; r={st['r']:.2f}; median|diff| {st['mad']:.1f}pp; "
          f"tau>cond in {st['up']}")
    for side in sides:
        for form in ('cond', 'tau'):
            s = m[m.leader_side == side]
            idx = ['elec', 'level', 'channel']
            r = s[s.source == 'real'].set_index(idx)['fraud_share_' + form]
            for nul in ('joint_null', 'marginal_null'):
                n = s[s.source == nul].set_index(idx)['fraud_share_' + form]
                j = pd.concat([r, n], axis=1, keys=['real', 'null']).dropna()   # cells present for both
                P(f"[{side} {form}] r(real,{nul})={j.real.corr(j.null):.2f}; {nul}>=real in "
                  f"{int((j.null >= j.real).sum())}/{len(j)}")
    nn = m[m.source != 'real']
    top = nn.loc[nn.fraud_share_tau.idxmax()]
    P(f"largest tau null: {top.elec}/{top.level}/{top.channel}/{top.source}/{top.leader_side} "
      f"fraud share {100*top.fraud_share_tau:.1f}% (cond {100*top.fraud_share_cond:.1f}%), Fw {top.Fw_tau:,.0f}, "
      f"flagged {top.n_flagged_tau:.0f}/{top.n_units:.0f}")
    pe = m[(m.channel == 'total_no_early') & (m.source == 'real') & m.elec.str.startswith('pres')]
    for side in sides:
        q = pe[pe.leader_side == side]
        P(f"[{side}] pre-early presidential real: tau {100*q.fraud_share_tau.min():.1f}-{100*q.fraud_share_tau.max():.1f}% "
          f"(cond {100*q.fraud_share_cond.min():.1f}-{100*q.fraud_share_cond.max():.1f}%); "
          f"Fw tau {q.Fw_tau.min():,.0f}-{q.Fw_tau.max():,.0f}")
        for r in q.sort_values(['elec', 'level']).itertuples():
            P(f"    {r.elec} {r.level}: cond {100*r.fraud_share_cond:.1f}% -> tau {100*r.fraud_share_tau:.1f}%, "
              f"Fw {r.Fw_tau:,.0f}, flagged {r.n_flagged_tau:.0f}/{r.n_units:.0f}")
    open('tau_stats.txt', 'w').write("\n".join(out) + "\n")
    print("\n".join(out))

    lab = {'real': 'Real data', 'marginal_null': 'Marginal null', 'joint_null': 'Joint null', 'both nulls': 'Both nulls'}
    L = [r"\begin{tabular}{lr cc cc cc c}", r"\toprule",
         r" & & \multicolumn{2}{c}{Runs with fraud share $>5\%$} & \multicolumn{2}{c}{Median fraud share} & "
         r"\multicolumn{2}{c}{Not converged} & \\",
         r"\cmidrule(lr){3-4}\cmidrule(lr){5-6}\cmidrule(lr){7-8}",
         r"Data & Runs & Observed & Latent & Observed & Latent & Observed & Latent & $r$ \\", r"\midrule"]
    for st in tab[:4]:
        if st['lab'] == 'both nulls':
            L.append(r"\midrule")
        L.append(f"{lab[st['lab']]} & {st['n']} & {st['n5_c']} ({st['gt5_c']:.0f}\\%) & {st['n5_t']} ({st['gt5_t']:.0f}\\%) & "
                 f"{st['med_c']:.1f}\\% & {st['med_t']:.1f}\\% & {st['nc_c']:.0f}\\% & {st['nc_t']:.0f}\\% & {st['r']:.2f} \\\\")
    L += [r"\bottomrule", r"\end{tabular}"]
    open('tau_summary_table.tex', 'w').write("\n".join(L) + "\n")

    SH = {'pres16': 'Pres02', 'pres17': 'Pres07', 'pres18': 'Pres12', 'pres19': 'Pres17', 'pres20': 'Pres22',
          'pres21': 'Pres25', '18': 'Gen08', '19': 'Gen12', '20': 'Gen16', '21': 'Gen20', '22': 'Gen24'}
    SRC = {'real': 'real', 'marginal_null': 'marginal', 'joint_null': 'joint'}
    order = {e: i for i, e in enumerate(SH)}
    m['_o'] = m.elec.map(order)
    m = m.sort_values(['leader_side', '_o', 'level', 'channel', 'source'])
    rows = []
    for r in m.itertuples():
        rows.append(" & ".join([r.leader_side, SH[r.elec], r.level[:5] if r.level == 'constituency' else r.level,
                                r.channel.replace('_', '-'), SRC[r.source], f"{int(r.n_units)}",
                                f"{100*r.fraud_share_cond:.1f}", f"{100*r.fraud_share_tau:.1f}",
                                f"{r.rhat_cond:.2f}", f"{r.rhat_tau:.2f}",
                                f"{int(r.n_flagged_cond)}", f"{int(r.n_flagged_tau)}"]) + r" \\")
    head = (r"Lead. & Elec. & Level & Channel & Source & $n$ & \multicolumn{2}{c}{Fraud share \%} & "
            r"\multicolumn{2}{c}{$\max\hat{R}$} & \multicolumn{2}{c}{Flagged} \\" + "\n" +
            r" & & & & & & Obs. & Latent & Obs. & Latent & Obs. & Latent \\")
    cap = (r"Every eforensics run with the latent-turnout form, paired with the observed-turnout (package-default) run of the same cell, "
           r"data source and leader coding (short-chain configuration). ``Const.'' is the constituency level.")
    T = [r"{\footnotesize", r"\setlength{\tabcolsep}{3pt}", r"\begin{longtable}{llllllrrrrrr}",
         rf"\caption{{{cap}}} \label{{tab:app_tau}} \\", r"\toprule", head, r"\midrule", r"\endfirsthead",
         r"\multicolumn{12}{c}{\tablename\ \thetable{} -- continued} \\", r"\toprule", head, r"\midrule",
         r"\endhead", r"\bottomrule", r"\endfoot"] + [x.replace('const', 'Const.') for x in rows] + [r"\end{longtable}", "}"]
    open('appendix_tables_tau.tex', 'w').write("\n".join(T) + "\n")
    print(f"wrote tau_comparison.csv, tau_summary_table.tex, appendix_tables_tau.tex ({len(rows)} rows), tau_stats.txt")
    make_figures(m)


def make_figures(m):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 9, 'font.family': 'serif'})
    STY = {'dem': dict(color='#1f4e79', marker='o', s=22, alpha=0.75, lab='Dem-coded'),
           'con': dict(color='#c0392b', marker='^', s=32, alpha=0.9, lab='Con-coded')}
    SRC = {'real': ('Real data', 'o', '#1f4e79'), 'marginal_null': ('Marginal null', 's', '#e69f00'),
           'joint_null': ('Joint null', '^', '#c0392b')}
    sides = [x for x in ('dem', 'con') if x in set(m.leader_side)]

    # Figure A: latent vs conditional, every paired run, coloured by data source
    fig, ax = plt.subplots(figsize=(5.2, 4.8))
    lim = max(m.fraud_share_cond.max(), m.fraud_share_tau.max()) * 1.05
    for src, (lab, mk, col) in SRC.items():
        d = m[m.source == src]
        for side in sides:
            q = d[d.leader_side == side]
            ax.scatter(q.fraud_share_cond, q.fraud_share_tau, s=24, marker=mk, alpha=0.75,
                       facecolors=col if side == 'dem' else 'none', edgecolors=col, linewidths=0.8,
                       label=f"{lab}, {STY[side]['lab']} (n={len(q)})")
    ax.plot([0, lim], [0, lim], 'k--', linewidth=0.8, label='45\u00b0 (latent = observed)')
    ax.set_xlim(0, lim); ax.set_ylim(0, lim)
    ax.set_xlabel('Fraud share, observed-turnout form (package default)')
    ax.set_ylabel('Fraud share, latent-turnout form')
    r = m.fraud_share_cond.corr(m.fraud_share_tau)
    ax.set_title(f'Latent-turnout vs observed-turnout form, short-chain configuration\n(all {len(m)} paired runs, $r$={r:.2f})')
    ax.legend(fontsize=7, loc='upper left')
    fig.tight_layout(); fig.savefig('fig_tau_vs_cond.pdf'); plt.close(fig)

    # Figure B: real vs null under the latent-turnout form (as in the observed-turnout real-vs-null figures)
    fig, axes = plt.subplots(1, 2, figsize=(9, 4.2))
    idx = ['elec', 'level', 'channel']
    for a, nullcol, title in zip(axes, ['marginal_null', 'joint_null'], ['Marginal null', 'Joint null']):
        lim, rs = 0, []
        for side in sides:
            q = m[m.leader_side == side].pivot_table(index=idx, columns='source', values='fraud_share_tau').dropna()
            st = STY[side]
            a.scatter(q[nullcol], q['real'], s=st['s'], alpha=st['alpha'], color=st['color'], marker=st['marker'],
                      label=f"{st['lab']} (n={len(q)})")
            lim = max(lim, q[nullcol].max(), q['real'].max())
            rs.append(f"{st['lab'].split('-')[0]} $r$={q['real'].corr(q[nullcol]):.2f}")
        lim *= 1.05
        a.plot([0, lim], [0, lim], 'k--', linewidth=0.8, label='45\u00b0 (real = null)')
        a.set_xlim(0, lim); a.set_ylim(0, lim)
        a.set_xlabel(f'{title} fraud share'); a.set_ylabel('Real-data fraud share')
        a.set_title(f"{title}, latent-turnout form\n({', '.join(rs)})")
        a.legend(fontsize=7, loc='upper left')
    fig.tight_layout(); fig.savefig('fig_tau_real_vs_null.pdf'); plt.close(fig)
    print("wrote fig_tau_vs_cond.pdf and fig_tau_real_vs_null.pdf")


if __name__ == '__main__':
    main()
