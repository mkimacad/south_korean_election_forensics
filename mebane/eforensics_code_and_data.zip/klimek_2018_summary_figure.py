"""Klimek et al. (2018)-procedure summary figure: real vs joint-null total
fraud share (f_i+f_e) and extreme-fraud share (f_e), raw and province-adjusted
fingerprints, five pre-early-voting elections x two leader codings, both
unit levels (Pearson r per level in the legend)."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import klimek_units as KU
d = pd.read_csv('klimek_2018_output/klimek_2018_all_results.csv', dtype={'elec': str})
d = d[d.level.isin(KU.complete_levels(d, KU.MAIN_PER_LEVEL))]
STY = {'dong': dict(marker='o', fc='tab:blue', lab='dong'), 'tpg': dict(marker='^', fc='tab:orange', lab='polling district')}
fig, axes = plt.subplots(2, 2, figsize=(10, 9))
for col, var in enumerate((False, True)):
    for row, key in enumerate(('fraud_share', 'fe')):
        ax = axes[row, col]
        sub = d[d.residualized == var]
        lim = max(0.01, float(np.nanmax(sub[key])) * 1.1)
        for lv, s in [(l, t) for l, t in STY.items() if l in set(d.level)]:
            q = sub[sub.level == lv]
            j = pd.concat([q[q.source == 'real'].set_index(['elec', 'leader_side'])[key],
                           q[q.source == 'joint_null'].set_index(['elec', 'leader_side'])[key]],
                          axis=1, keys=['real', 'null']).dropna()
            r = j['real'].corr(j['null']) if j['real'].std() > 0 and j['null'].std() > 0 else float('nan')
            rtxt = f"$r$={r:.2f}" if r == r else "$r$ n/a (no variation)"
            ax.scatter(j['null'], j['real'], marker=s['marker'], s=46, facecolors=s['fc'], edgecolors='black',
                       linewidths=0.5, alpha=0.8, label=f"{s['lab']} (n={len(j)}, {rtxt})")
        ax.plot([0, lim], [0, lim], 'k--', lw=0.8)
        ax.set_xlim(-0.01 * lim, lim); ax.set_ylim(-0.01 * lim, lim)
        lab = r'fraud share $f_i+f_e$' if key == 'fraud_share' else r'extreme-fraud share $f_e$'
        ax.set_xlabel(f'joint null: {lab}'); ax.set_ylabel(f'real: {lab}')
        ax.set_title(('raw' if not var else 'province-adjusted') + ' fingerprints')
        ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig('klimek_2018_output/klimek_summary.pdf')
print("wrote klimek_2018_output/klimek_summary.pdf")
