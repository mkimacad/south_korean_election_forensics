"""Regenerates fig7_selfnull_scatter.pdf: real-data vs model-consistent self-null
fraud share, short-chain, both leader codings, all cells in appendix_selfnull_results.csv."""
import sys
import pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
# Optional: python3 make_fig7_selfnull.py [selfnull.csv] [out.pdf] [real_source_csv]
# Defaults are the observed-turnout files; for a tau sweep pass the CSV from
# parse_selfnull_logs.py, an output name, and the tau real-data results so both
# axes come from the same likelihood form.
SN_CSV = sys.argv[1] if len(sys.argv) > 1 else 'appendix_selfnull_results.csv'
OUT_PDF = sys.argv[2] if len(sys.argv) > 2 else 'fig7_selfnull_scatter.pdf'
REAL_CSV = sys.argv[3] if len(sys.argv) > 3 else 'appendix_full_results.csv'
sn = pd.read_csv(SN_CSV); sn['elec'] = sn.elec.astype(str)
r = pd.read_csv(REAL_CSV); r['elec'] = r.elec.astype(str)
r = r[(r.dataset == 'new_settings') & (r.source == 'real')]
if 'leader_side' not in sn:
    sn['leader_side'] = 'dem'
m = sn.merge(r[['elec', 'level', 'channel', 'leader_side', 'fraud_share']],
             on=['elec', 'level', 'channel', 'leader_side'], suffixes=('_self', '_real'))
COL = {'dem': '#1f4e79', 'con': '#c0392b'}; LAB = {'dem': 'Dem-coded', 'con': 'Con-coded'}
fig, ax = plt.subplots(figsize=(5.4, 5.2))
rs = []
for side in [x for x in ('dem', 'con') if x in set(m.leader_side)]:
    q = m[m.leader_side == side]
    rs.append(f"{LAB[side].split('-')[0]} r={q.fraud_share_real.corr(q.fraud_share_self):.2f}")
    mk = {'dem': 'o', 'con': '^'}[side]          # coding by shape (black-and-white safe)
    for lvl, filled in (('dong', True), ('constituency', False)):   # level by fill
        d = q[q.level == lvl]
        ax.scatter(100 * d.fraud_share_real, 100 * d.fraud_share_self, marker=mk, s=28, alpha=0.8,
                   facecolors=COL[side] if filled else 'none', edgecolors=COL[side], linewidths=0.9,
                   label=f"{LAB[side]}, {lvl} (n={len(d)})")
lim = 100 * max(m.fraud_share_real.max(), m.fraud_share_self.max()) * 1.05
ax.plot([0, lim], [0, lim], 'k--', lw=0.8); ax.set_xlim(0, lim); ax.set_ylim(0, lim)
ax.set_xlabel('real-data fraud share (%)'); ax.set_ylabel('self-null fraud share (%)')
ax.set_title(f"{len(m)} cells ({', '.join(rs)})", fontsize=10)
ax.legend(fontsize=7, loc='upper left'); fig.tight_layout(); fig.savefig(OUT_PDF); print(len(m), 'cells plotted;', ', '.join(rs))
