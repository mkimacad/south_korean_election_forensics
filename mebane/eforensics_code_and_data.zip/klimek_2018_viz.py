"""Shared helpers for the Klimek et al. (2018)-procedure figures: observed
fingerprints and the model fingerprint at fitted mean parameters. Nothing
here refits; fitted parameters come from klimek_2018_output/*.csv."""
import numpy as np
import klimek_2018 as K18

NB_PLOT = 100          # same 1% bins as the fit


def observed(t, v, nb=NB_PLOT):
    H, _, _ = np.histogram2d(t, v, bins=nb, range=[[0, 1], [0, 1]])
    return H / H.sum()


def model(row, n=200000, nb=NB_PLOT, seed=777):
    """Fingerprint of a large simulated sample (n units) from the model at the
    fitted plug-ins and the mean fitted (f_i, f_e, alpha) of one results row."""
    p = {k: float(row[k]) for k in ('a', 'v', 'sigma_a', 'sigma_vL', 'sigma_vR')}
    m = K18.model_units(p, n, np.random.default_rng(seed))
    inc = m['U'] < row['fi']
    ext = (m['U'] >= row['fi']) & (m['U'] < row['fi'] + row['fe'])
    frac = np.where(inc, m['x'], np.where(ext, m['y'], 0.0))
    t = m['a'] + frac * (1 - m['a'])
    v = np.where(inc | ext, K18.fraud_share(m, frac, float(row['alpha'])), m['v'])
    return observed(t, v, nb)
