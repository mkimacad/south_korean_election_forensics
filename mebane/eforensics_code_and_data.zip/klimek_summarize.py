#!/usr/bin/env python3
"""
klimek_summarize.py

Aggregates the per-cell outputs of klimek_analysis.py (run via
run_klimek_all.sh) into:

  <outdir>/klimek_all_results.csv   every cell x source x variant, one row each
  <outdir>/klimek_summary.pdf       real vs null Klimek fraud share (f_i + f_e)
                                    and extreme-fraud share f_e, raw and
                                    province-residualized, both leader codings
  <outdir>/klimek_table.tex         LaTeX table of the aggregate dong channels
                                    (pooled / total_no_early), Democratic-coded

Usage: python3 klimek_summarize.py [--outdir klimek_output]
"""
import argparse
import glob
import os

import numpy as np
import pandas as pd

ELEC_LABEL = {'pres16': 'Pres 2002', 'pres17': 'Pres 2007', '18': 'Gen 2008', '19': 'Gen 2012',
              'pres18': 'Pres 2012', '20': 'Gen 2016', 'pres19': 'Pres 2017', '21': 'Gen 2020',
              'pres20': 'Pres 2022', '22': 'Gen 2024', 'pres21': 'Pres 2025'}
ELEC_ORDER = ['pres16', 'pres17', '18', '19', 'pres18', '20', 'pres19', '21', 'pres20', '22', 'pres21']
CAP = 0.95   # klimek_analysis caps f_i + f_e at 0.95


def load(outdir):
    files = sorted(glob.glob(os.path.join(outdir, '*_klimek.csv')))
    if not files:
        raise SystemExit(f"No *_klimek.csv files in {outdir}")
    d = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    d['elec'] = d['elec'].astype(str)
    d['variant'] = np.where(d['residualized'], 'residualized', 'raw')
    return d


def fmt_share(med, lo, hi):
    def p(x):
        return r'$\geq$95' if x >= CAP - 1e-9 else f"{100 * x:.1f}"
    if hi - lo < 0.005:
        return p(med)
    return f"{p(med)} [{p(lo)}, {p(hi)}]"


def make_table(d, path):
    sub = d[(d.level == 'dong') & d.channel.isin(['pooled', 'total_no_early']) & (d.leader_side == 'dem')]
    lines = [r"\begin{tabular}{llccc}", r"\toprule",
             r"Election & Variant & Real & Marginal null & Joint null \\", r"\midrule"]
    for e in ELEC_ORDER:
        for var in ('raw', 'residualized'):
            r = sub[(sub.elec == e) & (sub.variant == var)].set_index('source')
            if r.empty:
                continue
            cells = [fmt_share(r.loc[s, 'fraud_share'], r.loc[s, 'fraud_share_min'], r.loc[s, 'fraud_share_max'])
                     if s in r.index else '--' for s in ('real', 'marginal_null', 'joint_null')]
            lab = ELEC_LABEL.get(e, e) if var == 'raw' else ''
            lines.append(f"{lab} & {'raw' if var == 'raw' else 'resid.'} & " + " & ".join(cells) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(path, 'w').write("\n".join(lines) + "\n")


def winner_table(d, path):
    """Winner-coded Klimek fraud share f_i+f_e (%), real vs joint null, raw and residualized."""
    # Official winners: the elected president's party, and for general elections
    # the party winning the most seats (2016: Democratic, 123 seats to 122). Vote
    # sums from the unit tables are not used, because the leader coding in some
    # general elections does not reproduce national party vote totals.
    win = {'pres16': 'dem', 'pres17': 'con', '18': 'con', '19': 'con', 'pres18': 'con', '20': 'dem',
           'pres19': 'dem', '21': 'dem', 'pres20': 'con', '22': 'dem', 'pres21': 'dem'}
    w = d[(d.level == 'dong') & d.channel.isin(['pooled', 'total_no_early'])]
    w = w[w.apply(lambda r: r.leader_side == win[r.elec], axis=1)]

    def cell(r):
        v, lo, hi = 100 * r.fraud_share, 100 * r.fraud_share_min, 100 * r.fraud_share_max
        txt = f"{v:.0f}" if hi - lo < 2 else f"{v:.0f} [{lo:.0f}, {hi:.0f}]"
        return txt
    lines = [r"\begin{tabular}{llcccc}", r"\toprule",
             r" & & \multicolumn{2}{c}{Raw fingerprint} & \multicolumn{2}{c}{Province-adjusted} \\",
             r"\cmidrule(lr){3-4}\cmidrule(lr){5-6}",
             r"Election & Winner & Real & Joint null & Real & Joint null \\", r"\midrule"]
    for e in ELEC_ORDER:
        cells = []
        for var in (False, True):
            for src in ('real', 'joint_null'):
                r = w[(w.elec == e) & (w.residualized == var) & (w.source == src)].iloc[0]
                cells.append(cell(r))
        lines.append(f"{ELEC_LABEL[e]} & {'Dem.' if win[e] == 'dem' else 'Con.'} & " + " & ".join(cells) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(path, 'w').write("\n".join(lines) + "\n")
    w.assign(winner=w.elec.map(win)).to_csv(path.replace('_table.tex', '_results.csv'), index=False)
    return win


def make_figure(d, path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 2, figsize=(10, 9))
    for col, var in enumerate(('raw', 'residualized')):
        for row, (key, lab) in enumerate((('fraud_share', r'Klimek fraud share $f_i+f_e$'),
                                          ('fe', r'extreme-fraud share $f_e$'))):
            ax = axes[row, col]
            sub = d[d.variant == var]
            real = sub[sub.source == 'real'].set_index(['elec', 'level', 'channel', 'leader_side'])[key]
            # explicit colours and edges: a hollow marker with no edge colour set is
            # drawn invisibly by matplotlib (the edge inherits the 'none' face colour)
            # Joint null only: the marginal null keeps each unit at its own observed
            # position, so its fingerprint is the real fingerprint plus small noise and
            # cannot serve as a fraud-free control for a purely distributional method.
            for src, mk, colour in (('joint_null', '^', 'tab:orange'),):
                nul = sub[sub.source == src].set_index(['elec', 'level', 'channel', 'leader_side'])[key]
                j = pd.concat([real, nul], axis=1, keys=['real', 'null']).dropna()
                ax.scatter(j['null'], j['real'], marker=mk, s=42, facecolors=colour, edgecolors='black',
                           linewidths=0.5, alpha=0.75, label=f"{src.replace('_', ' ')} (n={len(j)})")
            lim = max(0.01, float(np.nanmax(sub[key])) * 1.1)
            ax.plot([0, lim], [0, lim], 'k--', lw=0.8)
            ax.set_xlim(-0.01 * lim, lim); ax.set_ylim(-0.01 * lim, lim)
            ax.set_xlabel(f'null: {lab}'); ax.set_ylabel(f'real: {lab}')
            ax.set_title(f'{var} fingerprints')
            ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--outdir', default='klimek_output')
    a = ap.parse_args()
    d = load(a.outdir)
    d.to_csv(os.path.join(a.outdir, 'klimek_all_results.csv'), index=False)
    make_table(d, os.path.join(a.outdir, 'klimek_table.tex'))
    print("winners:", winner_table(d, os.path.join(a.outdir, 'klimek_winner_table.tex')))
    make_figure(d, os.path.join(a.outdir, 'klimek_summary.pdf'))
    print(f"{len(d)} rows from {d.groupby(['elec', 'level', 'channel', 'leader_side', 'variant']).ngroups} cells")
    print(d.groupby(['variant', 'source'])[['fraud_share', 'fe']].median().round(3))
