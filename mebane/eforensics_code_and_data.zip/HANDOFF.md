# HANDOFF: eforensics / Klimek South Korea election-forensics paper

Read this first in a new chat, together with the two `.tex` files and the
code zip. It exists because this project has been worked on across a very
long conversation and a fresh chat has none of that history.

## What this project is

A paper arguing that two statistical election-forensics methods -- Mebane's
`eforensics` (Bayesian finite mixture model) and Klimek et al.'s
election-fingerprint model -- cannot distinguish real South Korean election
returns from synthetic fraud-free data built from those same returns, across
eleven national elections (2002-2025). The argument is made empirically: real
data, and two/three kinds of engineered fraud-free "null" data, are run
through both models, and the fraud estimates are compared.

## FINAL STATE (2026-09-26) -- the project is complete

This was the last editing round. Deliverables:

- `eforensics_manuscript_bundle.zip`
  - `eforensics_no_appendix.tex/.pdf` -- main manuscript (16 pages).
  - `eforensics_appendix_only.tex/.pdf` -- appendix, a separate document (70 pages).
  - `eforensics_combined.tex/.pdf` -- main text + appendix in one file, one
    bibliography, appendix numbering A.1, B.2, ... (85 pages).
  - `eforensics_korean.tex/.pdf` -- Korean translation of the MAIN TEXT ONLY,
    anonymized: no author name, affiliation, email, ORCID or personal GitHub
    link (the Data availability sentence says code is "supplementary
    material"). Figures stay in English; captions are translated.
  - `references.bib`, all figure PDFs, all `appendix_tables*.tex` / `tau_summary_table.tex`.
- `eforensics_code_and_data.zip` -- all code, data, logs and results.
- `eforensics_korean_page_images.zip` -- the 19 pages of the Korean PDF as
  150-dpi PNGs (anonymized, like the Korean PDF).

**Compiling.**
- Main, appendix and combined: `pdflatex X; bibtex X; pdflatex X; pdflatex X`.
  Each compiles on its own; there are NO cross-document references any more
  (the earlier `xr-hyper` setup was removed because Overleaf always compiles
  with `--jobname=output` and can never produce the sibling `.aux` file).
  Pointers between main text and appendix are plain text ("see the appendix",
  "the appendix's model-specification section"). Verified with Overleaf's
  exact invocation (`-jobname=output`) in isolated directories.
- Korean: `xelatex eforensics_korean; bibtex eforensics_korean; xelatex x2`.
  Needs `xetexko` (TeX Live `texlive-lang-korean`) and the Noto Serif/Sans CJK
  KR fonts. On Overleaf, set the compiler to XeLaTeX.

**Word limit:** the main text must stay under 6,000 words INCLUDING headers and
captions (`texcount -total -brief eforensics_no_appendix.tex`; final count
5,752). The model equations and priors, the null-dataset constructions
(Appendix A), all numeric result tables (Appendix B) and the Klimek details
(Appendix D) were moved to the appendix for this reason. The fraud-share
derivation in Appendix A is commented out by the user. Add new material to the
appendix, not the main text.

**Province groups:** the fixed effects use the first-level divisions with Seoul
split into its three Gangnam-area districts (Gangnam, Seocho, Songpa) vs the
rest (17 groups 2002-2008, 18 from 2012). The manuscript says so.

**Terminology and style (user's standing rules):**
- "observed-turnout form" (package default) vs "latent-turnout form"; never
  "conditional likelihood", "latent form" or bare "likelihood". In code the
  setting values stay `EFORENSICS_WFORM=conditional|tau`; comments state the
  mapping.
- Klimek: "sweep" is Klimek et al. (2018)'s term (one simulation + one full
  parameter search; 200 sweeps per fit). Never "plug-in" in the manuscript
  (the code keeps the function name `plugins()`, with a mapping note). The
  fraud-free distributions are computed "from the observed data before
  estimation", centered on the MODES (most populated 1% bin).
- Klimek logic, corrected in the appendix: fraud never lowers a unit's
  share, but units below the mode are NOT fraud-free; the model treats the
  spread below the mode, "where fraud has less effect", as true variation.
  (Simulation: with 30% fraud, 22% of below-mode units are fraudulent.)
- Honam lies far below the leader-share mode only for the CONSERVATIVE leader;
  for the Democratic winner in 2002 the below-mode cluster is Yeongnam.
- Avoid "pipeline", "workflow", overuse of "exactly", "respectively", "own",
  unnecessary commas, inverted sentences, spaced hyphens used as dashes, and
  evaluative AI-style summary sentences. American spelling throughout.
- Correlations must always name what is correlated (e.g. "real-data and
  joint-null fraud shares"); r = -0.42 is "weakly negatively correlated".
- Do not add material to the manuscript except to fix logic or errors.
- Figures must stay readable in black and white (shapes/fill/hatching; colour
  kept), except region-colour scatters.

**Code review (final round):** comments were checked for submission
suitability. No process notes, author names, absolute paths or informal
language remain. Terminology in comments now matches the manuscript (12
files); a date-stamped note and a stale `make_figures.py` docstring were
fixed; unused parsed CSVs were moved to `archive_pre_v2/` and
`long_chain_archive/`. All scripts parse (Python, R, bash), and regenerating
the manuscript's stats files and tables gives byte-identical output.

## The pipeline, at a glance

1. **Data**: Korean National Election Commission CSVs -> `mebane_r_driver_bidirectional.py`
   builds per-unit (dong or constituency) tables, and generates two fraud-free
   null datasets (`generate_marginal_null`, `generate_joint_null`, both seed=1
   by default) from the real data.
2. **eforensics model** (JAGS via R): `mebane_crosscheck.R` /
   `mebane_crosscheck_selfnull_fit.R`, driven by
   `run_mebane_r_all_parallel_bidirectional.sh`. Supports env-var switches:
   `EFORENSICS_CONV=psrf` (PSRF stopping rule instead of package default
   MCMCSE) and `EFORENSICS_WFORM=tau` (a model fork, unused in the paper).
3. **Klimek-type fingerprint model** (pure Python, no R/JAGS): see "Klimek
   estimator history" below -- **the paper now uses `klimek_2018.py`**, not
   the earlier `klimek_analysis.py`.
4. **Results CSVs** are parsed from run logs (`parse_mebane_logs.py`,
   `parse_psrf_logs.py`) or written directly by the Python drivers.
5. **Tables/figures** are generated by dedicated scripts (see README) reading
   those CSVs, never hand-edited.

## Defaults are now SHORT-CHAIN (changed 2026-09-23)

run_mebane_r_all_parallel_bidirectional.sh, mebane_r_driver_bidirectional.py,
mebane_crosscheck.R and mebane_crosscheck_selfnull_fit.R now default to
n.iter=1000, burn-in=300 (n.adapt=1000), matching the self-null scripts and
the paper's primary configuration. Long chain: R_N_ITER=5000 R_BURN_IN=1000.
Self-null MAX_PARALLEL default is 3 (was 2).

## Latent-turnout (tau-form) robustness check (v2)

MAIN: 348 runs (174 per coding) in output_data_v2_tau/mebane_r_all_logs (Dem)
and output_data_v2_tau/con_leader (Con), paired by make_tau_comparison.py.
SELF-NULL: both codings, 58/58 each (same folders), reported in the manuscript.
Headline (tau_stats.txt): see "Key numerical results". Older tau logs (old F
convention) are in archive_pre_v2/output_data_tau.

## Self-null crash narratives removed; feasibility now discussed in Section 2

Neither self-null's pres21/dong/early crash is mentioned anymore (the
conditional run's "completed when rerun" note and the tau run's "1 of 3553
units redrawn" note, in text and table captions). The appendix keeps only a
general one-sentence statement of the feasibility redraw. Section 2 now argues
the conditional form's practical advantage: under the latent form A and W are
independent binomials, so W > N - A has positive probability; the conditional
form bounds E[W] by votes cast and cuts the variance. Example numbers (N=5000,
tau=.30, nu=.95; checked by 4M-draw Monte Carlo): P(invalid) 4.8% latent vs
0.93% conditional. The package's own documentation gives no reason, so the text
presents this as a plausible practical reason, not their stated one.

## CURRENT STATE: all eforensics results from the v2 rerun (2026-09-25)

Every eforensics number, table and figure in the manuscript comes from the v2
rerun (output_data_v2, output_data_v2_tau, output_data_v2_psrf; 1,138 logs, all
with fraud_votes_definition=model). Collected with collect_eforensics_results.py,
parse_selfnull_logs.py, parse_psrf_logs.py, make_tau_comparison.py; every number
cited in the main text is printed by make_eforensics_stats.py
(eforensics_stats.txt), make_chainlength_check.py (chainlength_stats.txt) and
make_tau_comparison.py (tau_stats.txt).
- F_w/F_t are restored and model-consistent (N*f.m*(1-tau), N*f.s*tau*(1-nu), per draw).
- EXACT JOINT 95% HPD intervals are used wherever available: the fraud share
  (appendix tables, REPORT_EXACT_HPD=True) and F_w/F_t. The self-null logs of
  this rerun do not print the fraud-share interval (driver fixed afterwards),
  so self-null tables show no interval.
- The LONG-CHAIN configuration is removed from the paper and the mega scripts.
  Chain length is instead verified with the constituency PSRF runs (main text
  Section 3.3, fig_chainlength_psrf.pdf). Long-chain CSVs are kept in
  long_chain_archive/ (plus raw_5000_iter_parsed.csv etc. at top level).
- Pre-rerun logs/CSVs (old F convention) are in archive_pre_v2/. Do not use them.
- Both leader codings are reported for both self-nulls (conditional and tau).
- Claims revised to match the v2 data: the largest dong-level Dem-coded estimates
  are no longer all pre-early (2025/2022 pooled now rank above 2012/2002); the
  Dem-coded tau real-vs-null correlation is no longer "higher than conditional".

## Rule: the manuscript cites only data listed in the appendix (2026-09-24)

Removed: the first PSRF run (32 met / 2.4% / r=0.97), "diagnostic runs" of our
joint-fit Klimek estimator, the "earlier version of this analysis" remark, and
the numeric results of code checks (Klimek solver 60/60, from_sweeps 4e-16,
klimek_units vs eforensics loader). The scripts still exist and still perform
those checks; just don't cite their results unless an appendix table lists them.

## Self-null feasibility redraw (added 2026-09-24)

pres21 dong early (tau self-null) crashed in stage 2: the R layer rejected 3
synthetic rows with w + a > N. Under the tau form a ~ Bin(N, 1-tau) and
w ~ Bin(N, nu*tau) are independent, so near-unanimous units (Honam early
votes) can draw more leader votes than votes cast on ANY seed; changing
SEED_BASE does not help and would amount to seed selection.
generate_model_self_null now redraws each infeasible unit's (a, w) pair jointly
until w <= N - a (the model's joint distribution conditional on feasibility),
after all ordinary draws: cells with no infeasible unit are reproduced bit for
bit (verified), so all 54 completed tau self-null cells and every conditional
self-null cell are unaffected. The log prints the count; parse_selfnull_logs.py
records it as n_redrawn. When the rerun result arrives, say in the manuscript's
tau self-null paragraph how many units were redrawn.

## PSRF check (v2, used for the chain-length verification)

output_data_v2_psrf/: 210 constituency runs. Rule met 37 (36 at first check);
173 used all 10 extensions (15,300 vs 1,300 iterations/chain, 11.8x; 9.3x run
time). Median max R-hat 1.42 extended vs 1.47 short; share <=1.05 16.7% vs
17.1%. Fraud share r=0.96, median |diff| 0.4pp, mean diff 0.0. Runs meeting the
rule: 35/37 <=1% fraud share, max 2.0%. run_psrf_dong.sh exists (dong level,
138 runs) but has not been run.

## Channel composition (documented, not changed in code)

The constituency `early_out` channel is built from ALL constituency-only rows
(SPECIAL_DONG_NAMES_*: 관외사전투표 plus 거소·선상, 국외부재자/재외, misfiled),
not only 관외사전투표: 92-95% out-of-precinct early votes, 5-8% other.
`early_total` and `total` inherit this, so constituency `total` = all valid
votes. `pooled` (dong) omits all constituency-only ballots (87-92% of valid
votes); `total_no_early` (both levels) omits absentee/2012-overseas ballots
(96-97%). The manuscript's Terminology section and Table `tab:channels` now
state this. Restricting `early_out` to 관외사전투표 would require rerunning the
constituency eforensics grid (R/JAGS).

## Self-null under the tau likelihood form

`EFORENSICS_WFORM=tau` now also switches the self-null SIMULATION step
(generate_model_self_null in mebane_self_null_driver.py), not only the two R
fits: class-1 leader votes are drawn from Binomial(N, mu.tau*mu.nu) instead of
Binomial(N, mu.nu*(1 - a/N)). Before this change a tau self-null would have
simulated from the conditional form and refit with the tau form, i.e. a
misspecified "self"-null. Each log records `w_form`. Both codings' tau
self-null results (58/58 each, v2) are in the manuscript.

## Klimek estimator history -- READ THIS BEFORE TOUCHING KLIMEK RESULTS

This is the part most likely to confuse a fresh session, because the code
directory contains **three different Klimek-model estimators** and only one
of them is used for the numbers in the paper:

| File | What it is | Used for paper's numbers? |
|---|---|---|
| `klimek_analysis.py` | Our own first attempt: fits the clean component jointly with the fraud parameters (Nelder-Mead + NNLS), 3 simulation seeds | **No** (superseded; retained only as the "ours" comparison column in appendix Table `tab:app_klimek_compare`) |
| `klimek_original.py` | Reconstruction of Klimek et al. (2012)'s *original* procedure: plug-in clean component, 1-D relative statistic on vote-share alone, grid search | **No** (built only to benchmark against; performs worst in recovery tests -- invents large false-positive fraud) |
| `klimek_2018.py` | Klimek et al.'s **own 2018 update** (Klimek, Jimenez, Hidalgo, Hinteregger & Thurner, PLOS ONE, the Turkey paper): plug-in clean component, RSS on 1%-binned 2-D fingerprints, exact sparse grid solve (verified identical to the dense solver, 60/60), 200 sweeps | **YES -- this is what the manuscript's Klimek results, tables, and figures are built from** |

We switched from `klimek_analysis.py` to `klimek_2018.py` mid-project after
finding the 2018 paper and running a three-way parameter-recovery comparison
(appendix Section on "Comparison with alternative estimation procedures").
The reasoning, as written up in the appendix: the 2018 procedure is Klimek and
coauthors' own most recent specification. It is NOT chosen for better recovery
-- its errors run in both directions (fraud-free data give f_i of 0.16-0.30), and
an earlier claim that its bias is "one-directional and bounded" was found false
and removed. Do not reintroduce it; reread the appendix section first.

**If asked to change anything about the Klimek results:** use
`klimek_2018.py` / `klimek_2018_all.py` / `klimek_2018_viz.py` /
`klimek_2018_winner_table.py` / `klimek_2018_summary_figure.py`. Do not
silently fall back to `klimek_analysis.py`'s output for anything that ends up
in the manuscript.

## Key numerical results (sanity checks, don't recompute from memory)

- eforensics (v2, short chain, 348 runs): 77 of 232 null runs >5% fraud share
  (54 with HPD lower bound >5%); largest null 31.1% (HPD 21.6-39.6), F_w 3.7M
  (pres21 const total joint dem). Real vs null r: Dem 0.992 marginal / 0.942
  joint; Con 0.981 / 0.985. 88.8% of runs not converged.
- Self-null (conditional, 58 cells per coding): >5% in 17 (Dem) and 14 (Con);
  r with real 0.948 / 0.978. Tau self-null: 11 / 10 cells >5%, r 0.95 / 0.97.
- Tau (348 pairs): null runs >5% 77/232 -> 46/232; largest tau null 40.0%
  (pres21 const total joint con); r(cond,tau)=0.94.
- Pre-early (Dem): presidential 6.7-17.3%, F_w 0.3-1.6M; Con-coded Pres 2012
  dong 26.1% is the largest dong-level real estimate of any election.
- PSRF / chain length: see the PSRF section above.
- Klimek 2018-procedure (complete as of 2026-09-22; five pre-early-voting
  elections; 200 sweeps, 1% bins; 80 main + 30 exclusion fits over dong and
  polling-district (tpg) levels). f_e <= 0.07% everywhere. Raw, dong: no real or
  null fit below 5% (0/10 each), r(real,null)=0.80. Raw, tpg: null <5% in 4/10
  but 85% (Gen08) and 87% (Pres02, con coding); r=-0.42. Dong vs tpg same cell:
  median |diff| 10.5pp, max 79.5pp. All numbers: klimek_2018_output/klimek_2018_stats.txt.

If any of these numbers look different in the current `.tex` files, the
manuscript is more authoritative than this summary -- this file can go stale.

## The 14 figure files the manuscript includes

```
fig1b_new_settings.pdf           fig2_chronological.pdf
fig3_pres18_bidirectional.pdf    fig4_2024_bidirectional.pdf
fig7_selfnull_scatter.pdf        fig_chainlength_psrf.pdf
klimek_summary.pdf               fig_klimek_pres2012.pdf
fig_klimek_preearly_fit_pres.pdf fig_klimek_preearly_fit_gen.pdf
fig_klimek_preearly_nulls_pres.pdf fig_klimek_preearly_nulls_gen.pdf
fig_tau_vs_cond.pdf              fig_tau_real_vs_null.pdf
```

Regenerate with (from inside the unzipped code directory):
```bash
python3 make_figures.py                    # fig1b, fig2, fig3, fig4 (from appendix_full_results.csv)
python3 make_fig7_selfnull.py              # fig7_selfnull_scatter (both codings)
python3 make_chainlength_check.py          # fig_chainlength_psrf (+ chainlength_stats.txt)
python3 klimek_2018_summary_figure.py      # klimek_summary
python3 make_klimek_preearly_figures.py    # the 5 fig_klimek_preearly_*/pres2012 files
python3 make_tau_comparison.py output_data_v2_tau/mebane_r_all_logs output_data_v2_tau/con_leader
```
All scatter/correlation-style figures now annotate Pearson r directly in the
panel title or legend (added on user request); if you add a new scatter
figure, match that convention.

## Things already tried and rejected (don't redo without new information)

- **Exact replication of Klimek et al. (2012)'s original procedure** as the
  paper's primary method -- tried (`klimek_original.py`), fails its own
  recovery tests (invents large fraud on simulated fraud-free data), so we
  use their 2018 update instead. See appendix.
- **No independent implementation of the Klimek model exists online** -- web
  search turned up no code from the original authors; `klimek_original.py`
  and `klimek_2018.py` are our own reconstructions from the published papers,
  each validated by parameter-recovery tests and (for `klimek_2018.py`) an
  exact-vs-brute-force grid check.
- **The tau-form eforensics model fork** (`ef_qbl_tau.R`,
  `EFORENSICS_WFORM=tau`) exists in the code but produces no results used in
  the paper. Leave it alone unless asked about it specifically.
- **`klimek_fingerprint.py`** (an early, separate diagnostic script) was
  deleted as unused; don't recreate it.

## Style/workflow conventions established in this project

- Every numeric claim in the manuscript should be traceable to a CSV/script
  in the zip -- no hand-typed numbers. When editing results text, regenerate
  the underlying table/figure first, then copy numbers from its actual
  output.
- Always run `pdflatex` twice and check for `^! ` errors and
  `undefined` references before delivering a `.tex` file.
- After any script edit, re-run it and diff the output against what's cited
  in the manuscript before touching the manuscript text.
- Keep a `diff` against the previous delivered version of each `.tex` file so
  the user can review changes without rereading the whole document (this was
  done via `changes.diff` / `appendix_changes.diff` in past turns).
- The user has been doing careful correctness review throughout (catching a
  broken PSRF run, an unremoved import, a coordinate-order bug, etc.) --
  verify claims (via brute-force checks, recovery tests, or cross-checking
  two independent computations) before presenting numbers as settled,
  especially for anything estimator-related.

## Suggested first message to the user in a new chat

"I've read the handoff file. The project is in its final state: main text
(5,752 words), appendix, combined file and the anonymized Korean translation
all compile cleanly, and the code and data are in the code zip. What would you
like to do?"
