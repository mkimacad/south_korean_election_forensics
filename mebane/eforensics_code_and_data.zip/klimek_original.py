#!/usr/bin/env python3
"""
klimek_original.py

Klimek, Yegorov, Hanel & Thurner (2012, PNAS 109:16469) fraud-parameter
estimation, implemented as specified in their main text ("Parametric model",
"Estimating the fraud parameters") and Supporting Information ("Fitting the
model" and the model protocol), applied to the same real and fraud-free null
datasets as the eforensics analysis.

PROCEDURE (per dataset)
  Data.  Units with electorate N_i < 100 are excluded. Turnout a_i = V_i/N_i,
         winner vote share v_i = W_i/V_i.
  Plug-in clean component and fraud widths (SI):
         a, v   = peak of the empirical turnout / vote-share distribution
                  (1% bins; the bin that maximizes the distribution),
         sigma_vL = sqrt(mean((v_i - v)^2 | v_i < v))   left-sided width,
         sigma_vR = sqrt(mean((v_i - v)^2 | v_i > v))   right-sided width,
                    = the incremental-fraud intensity width,
         sigma_a  = sqrt(mean((a_i - a)^2 | a_i < a and v_i < v)),
         sigma_x  = 0.075 (extreme-fraud width, fixed).
  Model units (one per real unit, same N_i):
         turnout a_i^m ~ N(a, sigma_a), vote share v_i^m ~ N(v, sqrt(2) sigma_vL),
         both restricted to (0,1);
         with prob. f_i incremental fraud: x_i ~ |N(0, sigma_vR)| on (0,1),
             winner votes N_i (a v + x (1-a) + x^alpha (1-v) a), turnout a + x(1-a);
         with prob. f_e extreme fraud: the same with y_i = 1 - |N(0, sigma_x)|.
  Fit.   S(f_i, f_e, alpha) = sum over units i of
             ((pdf(v_i) - pdf_model(v_i)) / pdf(v_i))^2
         where pdf is the 1%-binned distribution of the winner's vote share.
         Minimized over the full grid f_i, f_e in {0, 0.01, ..., 1} (with
         f_i + f_e <= 1) and alpha in {0, 0.1, ..., 5}.
  Repetition. 100 independent realizations of the model units; the mean and
         standard deviation of the minimizing (f_i, f_e, alpha) are reported.

IMPLEMENTATION NOTE (exact, not an approximation). In each realization every
model unit carries one uniform U_i; it is incremental if U_i < f_i and extreme
if f_i <= U_i < f_i + f_e, exactly as "with probability f_i / f_e", with the
same U_i across the grid (common random numbers). Because both f_i and
f_i + f_e lie on the 0.01 grid, the model histogram at every grid point is a
sum of cumulative histograms over the U-ordered units evaluated at 101
thresholds, and S is a quadratic form in them. The whole (f_i, f_e) grid is
therefore evaluated by one small matrix product per alpha, with results
identical to evaluating each grid point separately.

Two points the paper leaves open, resolved as follows: the "(first local)
maximum" of the SI is taken as the maximizing bin, as stated in the main
text; draws outside (0,1) are resampled (inverse-CDF truncation), following
the SI's "only accepted if they lie in the range 0 < x_i < 1".

USAGE
    python3 klimek_original.py <elec_id> <level> <channel> <leader_side> [--residualize]
                               [--sources real,joint_null] [--outdir klimek_original_output]
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd
from scipy.special import ndtr, ndtri

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

SIGMA_X = 0.075
FGRID = np.round(np.arange(0, 101) / 100, 2)          # f_i and f_i + f_e grid
AGRID = np.round(np.arange(0, 51) / 10, 1)            # alpha grid
NBIN = 100                                            # 1% bins
N_REAL = 100                                          # realizations
MIN_ELECTORATE = 100
EPS = 1e-9


def trunc_normal(u, mu, sd):
    lo, hi = ndtr((0 - mu) / sd), ndtr((1 - mu) / sd)
    return np.clip(mu + sd * ndtri(lo + u * (hi - lo)), EPS, 1 - EPS)


def half_normal_01(u, scale):
    top = 2 * ndtr(1.0 / scale) - 1
    return np.clip(scale * ndtri(0.5 + 0.5 * u * top), EPS, 1 - EPS)


def plugins(a_obs, v_obs):
    """Klimek et al.'s plug-in peaks and widths."""
    ha, _ = np.histogram(a_obs, bins=NBIN, range=(0, 1))
    hv, _ = np.histogram(v_obs, bins=NBIN, range=(0, 1))
    a = (np.argmax(ha) + 0.5) / NBIN
    v = (np.argmax(hv) + 0.5) / NBIN
    left, right = v_obs[v_obs < v], v_obs[v_obs > v]
    s_vL = np.sqrt(np.mean((left - v) ** 2)) if len(left) else 1e-3
    s_vR = np.sqrt(np.mean((right - v) ** 2)) if len(right) else 1e-3
    both = (a_obs < a) & (v_obs < v)
    s_a = np.sqrt(np.mean((a_obs[both] - a) ** 2)) if both.sum() else np.std(a_obs)
    return dict(a=a, v=v, sigma_vL=max(s_vL, 1e-3), sigma_vR=max(s_vR, 1e-3), sigma_a=max(s_a, 1e-3))


def model_units(p, n, rng):
    """One realization: clean draws, fraud intensities and class uniforms for n units."""
    u = rng.random((5, n))
    return dict(a=trunc_normal(u[0], p['a'], p['sigma_a']),
                v=trunc_normal(u[1], p['v'], np.sqrt(2) * p['sigma_vL']),
                x=half_normal_01(u[2], p['sigma_vR']),
                y=1 - half_normal_01(u[3], SIGMA_X),
                U=u[4])


def fraud_share(m, frac, alpha):
    a, v = m['a'], m['v']
    w = a * v + frac * (1 - a) + frac ** alpha * (1 - v) * a
    return np.clip(w / (a + frac * (1 - a)), 0, 1 - EPS)


def vbin(s):
    return np.minimum((s * NBIN).astype(int), NBIN - 1)


def fit_realization(obs_counts, m):
    """Exact grid minimization of S for one realization of model units."""
    n = obs_counts.sum()
    nm = float(len(m['v']))                             # model units (n, or n x replicates)
    nb = obs_counts > 0
    w = (n ** 2) / obs_counts[nb]                       # S = sum_b (n^2/n_b)(p_b - m_b)^2
    p = obs_counts[nb] / n
    g = np.minimum((m['U'] * 100).astype(int), 100)     # U-interval of each unit on the 0.01 grid

    def cum_hist(bins):                                  # cumulative counts for U < j/100, j = 0..100
        c = np.bincount(g * NBIN + bins, minlength=101 * NBIN).reshape(101, NBIN)
        return np.vstack([np.zeros((1, NBIN)), np.cumsum(c, axis=0)[:-1]])

    C = cum_hist(vbin(m['v']))
    C_tot = np.bincount(vbin(m['v']), minlength=NBIN).astype(float)
    r = p - C_tot[nb] / nm
    best = (np.inf, None)
    jj, ll = np.meshgrid(np.arange(101), np.arange(101), indexing='ij')
    valid = ll >= jj                                     # f_i + f_e >= f_i
    for alpha in AGRID:
        I = cum_hist(vbin(fraud_share(m, m['x'], alpha)))
        E = cum_hist(vbin(fraud_share(m, m['y'], alpha)))
        A = ((I - E)[:, nb]) / nm                        # indexed by j:  f_i = j/100
        B = ((E - C)[:, nb]) / nm                        # indexed by l:  f_i + f_e = l/100
        # S(j,l) = sum_b w_b (r_b - A_jb - B_lb)^2
        Sa = (w * (r - A) ** 2).sum(1)[:, None]
        Sb = (w * B ** 2).sum(1)[None, :] - 2 * (w * r * B).sum(1)[None, :]
        cross = 2 * (A * w) @ B.T
        S = Sa + Sb + cross
        S = np.where(valid, S, np.inf)
        k = np.unravel_index(np.argmin(S), S.shape)
        if S[k] < best[0]:
            best = (S[k], (k[0] / 100, (k[1] - k[0]) / 100, alpha))
    return best[1]


def estimate(a_obs, v_obs, n_real=N_REAL, seed=0):
    p = plugins(a_obs, v_obs)
    obs_counts = np.bincount(vbin(v_obs), minlength=NBIN).astype(float)
    rng = np.random.default_rng(seed)
    fits = np.array([fit_realization(obs_counts, model_units(p, len(v_obs), rng)) for _ in range(n_real)])
    out = dict(p)
    for k, name in enumerate(('fi', 'fe', 'alpha')):
        out[name] = float(fits[:, k].mean()); out[name + '_sd'] = float(fits[:, k].std(ddof=1))
    out['fraud_share'] = float((fits[:, 0] + fits[:, 1]).mean())
    out['fraud_share_sd'] = float((fits[:, 0] + fits[:, 1]).std(ddof=1))
    out['n'] = len(v_obs)
    return out


def prepare(df, resid=False):
    d = df[(df['eligible'] >= MIN_ELECTORATE) & (df['total_votes'] > 0) & (df['leader_votes'] <= df['total_votes'])]
    a = (d['total_votes'] / d['eligible']).to_numpy(float)
    v = (d['leader_votes'] / d['total_votes']).to_numpy(float)
    keep = (a > 0) & (a <= 1)
    a, v, prov = a[keep], v[keep], d['prov_code'].to_numpy()[keep]
    if resid:
        import klimek_analysis as K
        a, v = K.residualize(a, v, prov)
    return a, v


def run_cell(elec, level, channel, leader, resid=False, sources=('real', 'joint_null'),
             outdir='klimek_original_output', exclude=None, tag_extra=''):
    import mebane_r_driver_bidirectional as base
    loader = base.load_pure_unit_table if level == 'dong' else base.load_pure_constituency_table
    real = loader(elec, channel, leader_side=leader)
    if exclude:
        real = real[~real['province_tag'].isin(exclude)]
    gen = {'real': lambda: real, 'marginal_null': lambda: base.generate_marginal_null(real),
           'joint_null': lambda: base.generate_joint_null(real)}
    rows = []
    for src in sources:
        a, v = prepare(gen[src](), resid)
        r = estimate(a, v)
        r.update(elec=elec, level=level, channel=channel, leader_side=leader, residualized=resid,
                 source=src, excluded='+'.join(sorted(exclude)) if exclude else '')
        rows.append(r)
    out = pd.DataFrame(rows)
    os.makedirs(outdir, exist_ok=True)
    tag = f"{elec}_{level}_{channel}_{leader}" + ("_resid" if resid else "") + tag_extra
    out.to_csv(os.path.join(outdir, f"{tag}_klimek_original.csv"), index=False)
    return out


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('elec'); ap.add_argument('level'); ap.add_argument('channel'); ap.add_argument('leader')
    ap.add_argument('--residualize', action='store_true')
    ap.add_argument('--sources', default='real,joint_null')
    ap.add_argument('--outdir', default='klimek_original_output')
    a = ap.parse_args()
    res = run_cell(a.elec, a.level, a.channel, a.leader, a.residualize, tuple(a.sources.split(',')), a.outdir)
    print(res[['source', 'fi', 'fi_sd', 'fe', 'fe_sd', 'alpha', 'alpha_sd', 'v', 'sigma_vL', 'sigma_vR']].round(3).to_string(index=False))
