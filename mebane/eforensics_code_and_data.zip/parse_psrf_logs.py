#!/usr/bin/env python3
"""
parse_psrf_logs.py

Parses the logs of run_psrf_constituency.sh (eforensics with the package's
PSRF stopping rule: psrf < 1.05 on every pi component, chains extended up to
max.auto = 10 times) into one CSV, one row per run.

Input : output_data_psrf/mebane_r_all_logs/*.log (Democratic-coded)
        output_data_psrf/con_leader/*.log        (conservative-coded)
Output: psrf_constituency_results.csv

Columns
  elec, level, channel, source, leader_side   cell identifiers (from the RESULT block)
  stopping_rule        rule named in the "[R-Model] Stopping rule:" line (should be "PSRF")
  n_extensions         number of chain extensions the package made (0-10)
  pkg_converged        True if the package's PSRF rule was eventually met, i.e. the log
                       does NOT end with the package's "chain(s) didn't converge" note
  final_psrf_max       largest pi psrf in the package's last diagnostic table
  rhat_kept            max R-hat of pi on the kept draws (RESULT block, our computation)
  fraud_share          sum of posterior medians of pi[2] and pi[3] (RESULT block)
  fraud_share_cons_lo/hi  conservative 95% interval (sum of component HPD bounds)
  fraud_share_hpd_lo/hi   exact joint 95% HPD of pi[2]+pi[3], where logged
  n_flagged, n_units   units with a non-clean MAP class / total units
  elapsed_seconds      wall-clock time of the run

Usage: python3 parse_psrf_logs.py [log_root] [out_csv]
"""
import glob
import os
import re
import sys

import pandas as pd

NAN = float('nan')


def num(pattern, text, group=1):
    m = re.search(pattern, text, re.MULTILINE)
    return float(m.group(group)) if m else NAN


def parse(path):
    t = open(path, errors='ignore').read()
    m = re.search(r'RESULT: (\S+?)/(\S+?)/(\S+?)/(\S+?)/leader=(\w+)', t)
    if not m:
        return None
    elec, level, channel, source, leader = m.groups()
    rule = re.search(r'\[R-Model\] Stopping rule: (\w+)', t)
    tables = re.findall(r'1 pi\[1\]\s+([\d.]+).*?\n2 pi\[2\]\s+([\d.]+).*?\n3 pi\[3\]\s+([\d.]+)', t)
    flagged = re.search(r'^n_regions_flagged\s*:\s*(\d+)/(\d+)', t, re.MULTILINE)
    cons = re.search(r'^fraud_share_cons95\s*:\s*\[\s*([\d.eE+-]+)\s*,\s*([\d.eE+-]+)\s*\]', t, re.MULTILINE)
    hpd = re.search(r'^fraud_share_hpd95\s*:\s*\[\s*([\d.eE+-]+)\s*,\s*([\d.eE+-]+)\s*\]', t, re.MULTILINE)
    return dict(
        elec=elec, level=level, channel=channel, source=source, leader_side=leader,
        stopping_rule=rule.group(1) if rule else '',
        n_extensions=len(re.findall(r'Extending the chains \(attempt', t)),
        pkg_converged="didn't converge" not in t,
        final_psrf_max=max(map(float, tables[-1])) if tables else NAN,
        rhat_kept=num(r'^rhat_pi\s*:\s*([\d.eE+-]+)', t),
        fraud_share=num(r'^fraud_share_median\s*:\s*([\d.eE+-]+)', t),
        fraud_share_cons_lo=float(cons.group(1)) if cons else NAN,
        fraud_share_cons_hi=float(cons.group(2)) if cons else NAN,
        fraud_share_hpd_lo=float(hpd.group(1)) if hpd else NAN,
        fraud_share_hpd_hi=float(hpd.group(2)) if hpd else NAN,
        n_flagged=int(flagged.group(1)) if flagged else None,
        n_units=int(flagged.group(2)) if flagged else None,
        elapsed_seconds=num(r'^elapsed_seconds[^:]*:\s*([\d.eE+-]+)', t),
    )


if __name__ == '__main__':
    root = sys.argv[1] if len(sys.argv) > 1 else 'output_data_psrf'
    out = sys.argv[2] if len(sys.argv) > 2 else 'psrf_constituency_results.csv'
    rows = [r for f in sorted(glob.glob(os.path.join(root, '*', '*.log'))) if (r := parse(f))]
    d = pd.DataFrame(rows).drop_duplicates(['elec', 'level', 'channel', 'source', 'leader_side'], keep='last')
    d.to_csv(out, index=False)
    bad = d[d.stopping_rule != 'PSRF']
    print(f"{len(d)} runs -> {out}")
    if len(bad):
        print(f"WARNING: {len(bad)} runs did not use the PSRF rule")
    print(f"package PSRF rule met: {d.pkg_converged.sum()} ({100 * d.pkg_converged.mean():.1f}%); "
          f"all 10 extensions used: {(d.n_extensions == 10).sum()}; "
          f"median R-hat (kept draws) {d.rhat_kept.median():.2f}")
