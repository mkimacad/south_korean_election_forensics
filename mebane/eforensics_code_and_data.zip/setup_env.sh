#!/bin/bash
# setup_env.sh
#
# One-shot, self-contained setup for the eforensics project. Uses ONLY
# conda and pip -- no apt-get/brew/system package manager, no admin rights.
# In particular, JAGS itself (normally a system-level install like
# `apt-get install jags`) is pulled from conda-forge instead.
#
# What it does:
#   1. Create (or update) a conda environment from environment.yml, which
#      provides: python + numpy/pandas/scipy/matplotlib, and r-base + jags +
#      r-rjags + r-coda + r-remotes + r-diptest + a compiler toolchain.
#   2. pip-install anything listed in requirements-pip.txt into that env
#      (currently empty by default -- everything needed ships via
#      conda-forge above -- but kept as a real step so pip-only additions
#      just work without touching this script).
#   3. Run install_eforensics.R, which uses R's `remotes` package to install
#      the `eforensics` R package from GitHub (it isn't on CRAN/conda-forge).
#   4. Verify both the Python and R/JAGS stacks import/load cleanly.
#
# Usage:
#   ./setup_env.sh                  # env name defaults to "eforensics"
#   ENV_NAME=my_env ./setup_env.sh  # override env name
#
# After setup, either:
#   conda activate eforensics
# or prefix commands with:
#   conda run -n eforensics <command>
#
# Then, e.g.:
#   conda run -n eforensics python3 mebane_r_driver_bidirectional.py pres18 dong total_no_early real
#   conda run -n eforensics ./run_mebane_r_all_parallel_bidirectional.sh "pres18" "dong"
#   conda run -n eforensics python3 make_figures.py

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

ENV_NAME="${ENV_NAME:-eforensics}"
ENV_FILE="environment.yml"
PIP_REQS="requirements-pip.txt"

# --- 0. Make sure conda itself is available ---------------------------------
if ! command -v conda >/dev/null 2>&1; then
  echo "ERROR: 'conda' was not found on PATH." >&2
  echo "Install Miniforge/Miniconda first: https://github.com/conda-forge/miniforge" >&2
  exit 1
fi

# `conda activate` needs conda's shell functions sourced; `conda run` (used
# throughout this script) does not, so we rely on that instead and never
# assume the calling shell has already run `conda init`.
CONDA_BASE="$(conda info --base)"

echo "[setup_env] Using conda at: $(command -v conda)"
echo "[setup_env] Target environment: $ENV_NAME"
echo ""

# --- 1. Create or update the conda environment ------------------------------
if conda env list | awk '{print $1}' | grep -qx "$ENV_NAME"; then
  echo "[setup_env] Environment '$ENV_NAME' already exists -- updating from $ENV_FILE ..."
  conda env update -n "$ENV_NAME" -f "$ENV_FILE" --prune
else
  echo "[setup_env] Creating environment '$ENV_NAME' from $ENV_FILE ..."
  conda env create -n "$ENV_NAME" -f "$ENV_FILE"
fi
echo ""

# --- 2. pip extras (kept as a real, always-run step) -------------------------
if [ -f "$PIP_REQS" ] && [ -s "$PIP_REQS" ]; then
  echo "[setup_env] Installing pip requirements from $PIP_REQS ..."
  conda run -n "$ENV_NAME" python3 -m pip install --no-input -r "$PIP_REQS"
else
  echo "[setup_env] No (non-empty) $PIP_REQS found -- skipping pip step (all current"
  echo "            Python deps are covered by conda-forge in $ENV_FILE)."
fi
echo ""

# --- 3. Install the GitHub-only 'eforensics' R package -----------------------
echo "[setup_env] Installing/verifying the R 'eforensics' package (from GitHub, via remotes)..."
conda run -n "$ENV_NAME" Rscript install_eforensics.R
echo ""

# --- 4. Final verification ---------------------------------------------------
echo "[setup_env] Verifying Python stack..."
conda run -n "$ENV_NAME" python3 -c "
import numpy, pandas, scipy, matplotlib
print(f'  numpy      {numpy.__version__}')
print(f'  pandas     {pandas.__version__}')
print(f'  scipy      {scipy.__version__}')
print(f'  matplotlib {matplotlib.__version__}')
"
echo ""
echo "[setup_env] Verifying Rscript is reachable on PATH inside the env (used by the"
echo "            Python drivers via subprocess)..."
conda run -n "$ENV_NAME" bash -c "command -v Rscript"
echo ""

echo "[setup_env] Setup complete. Environment '$ENV_NAME' is ready."
echo ""
echo "Next steps:"
echo "  conda activate $ENV_NAME"
echo "  python3 mebane_r_driver_bidirectional.py pres18 dong total_no_early real   # single-cell smoke test"
echo ""
echo "or, without activating:"
echo "  conda run -n $ENV_NAME python3 mebane_r_driver_bidirectional.py pres18 dong total_no_early real"
