"""
make_appendix_table_selfnull.py

Builds the LaTeX longtable for the model-consistent self-null results
(appendix_selfnull_results.csv), in the same format as make_appendix_table.py.
"""
import pandas as pd

df = pd.read_csv('appendix_selfnull_results.csv')
df['elec'] = df['elec'].astype(str)

# As in make_appendix_table.py: the manuscript reports the conservative interval
# throughout, so no HPD column is printed here by default. Set
# REPORT_EXACT_HPD = True to add the exact joint HPD of pi[2]+pi[3] (requires
# result files from the current mebane_crosscheck_selfnull_fit.R).
REPORT_EXACT_HPD = False

HAS_EXACT = REPORT_EXACT_HPD \
    and {'fraud_share_hpd_lo', 'fraud_share_hpd_hi'}.issubset(df.columns) \
    and df['fraud_share_hpd_lo'].notna().any()
if REPORT_EXACT_HPD and not HAS_EXACT:
    print("NOTE: REPORT_EXACT_HPD is set but appendix_selfnull_results.csv has "
          "no exact joint HPD columns; omitting the column.")

elec_label = {'pres16':'Pres02','pres17':'Pres07','18':'Gen08','19':'Gen12','pres18':'Pres12',
              '20':'Gen16','pres19':'Pres17','21':'Gen20','pres20':'Pres22','22':'Gen24','pres21':'Pres25'}

def esc(s):
    return str(s).replace('_', '-')

def fmt_pct3(v):
    return f"{100*v:.2f}" if pd.notna(v) else '--'

def fmt_rhat(v, conv):
    if pd.isna(v):
        return '--'
    marker = '$^{*}$' if conv else ''
    return f"{v:.2f}{marker}"

lines = []
lines.append(r"{\footnotesize")
COLSPEC = (r"p{1.0cm}p{1.15cm}p{1.55cm}rrrp{1.5cm}rc" if HAS_EXACT
           else r"p{1.0cm}p{1.15cm}p{1.55cm}rrrrc")
HEADER = (r"Elec. & Level & Channel & $N$ & $\pi_1$ (no fraud) \% & Fraud share \% & 95\% HPD & Flagged & $\hat{R}$ \\"
          if HAS_EXACT else
          r"Elec. & Level & Channel & $N$ & $\pi_1$ (no fraud) \% & Fraud share \% & Flagged & $\hat{R}$ \\")
NCOL = 9 if HAS_EXACT else 8
lines.append(r"\setlength{\tabcolsep}{4pt}")
lines.append(rf"\begin{{longtable}}{{{COLSPEC}}}")
CAPTION = (
    r"Model-consistent self-null results: $\pi$ forced to $(1,0,0)$ using the qbl "
    r"model's own fitted class-1 (no-fraud) data-generating equations, short-chain "
    r"configuration, Democratic-coded leader. $N$ is the unit count; ``Flagged'' is "
    r"the number of units receiving a non-clean MAP classification."
    + (r" The 95\% HPD interval is the exact joint interval for $\pi_2+\pi_3$, "
       r"computed from the per-draw sum." if HAS_EXACT else "")
    + r" One cell (pres21/dong/early) failed with an invalid simulated draw and is "
      r"omitted (Appendix~\ref{sec:appendix_selfnull})."
)
lines.append(rf"\caption{{{CAPTION}}} \label{{tab:app_selfnull}} \\")
lines.append(r"\toprule")
lines.append(HEADER)
lines.append(r"\midrule")
lines.append(r"\endfirsthead")
lines.append(rf"\multicolumn{{{NCOL}}}{{c}}{{\tablename\ \thetable{{}} -- continued}} \\")
lines.append(r"\toprule")
lines.append(HEADER)
lines.append(r"\midrule")
lines.append(r"\endhead")
lines.append(r"\bottomrule")
lines.append(r"\endfoot")
lvl_label = {'dong': 'dong', 'constituency': 'const.'}
for _, row in df.iterrows():
    e = elec_label.get(row['elec'], row['elec'])
    lvl = lvl_label.get(row['level'], row['level'])
    ch = esc(row['channel'])
    N = f"{int(row['n_units'])}"
    pi1 = fmt_pct3(row['p_no_fraud'])
    fs = fmt_pct3(row['fraud_share'])
    flagged = f"{int(row['n_flagged'])}/{int(row['n_units'])}"
    rhat = fmt_rhat(row['rhat'], row['not_converged'])
    if HAS_EXACT:
        lo, hi = row.get('fraud_share_hpd_lo'), row.get('fraud_share_hpd_hi')
        hpd = '--' if pd.isna(lo) or pd.isna(hi) else f"[{100*lo:.1f},{100*hi:.1f}]"
        cells = [e, lvl, ch, N, pi1, fs, hpd, flagged, rhat]
    else:
        cells = [e, lvl, ch, N, pi1, fs, flagged, rhat]
    lines.append(" & ".join(cells) + r" \\")
lines.append(r"\end{longtable}")
lines.append(r"}")

open('appendix_tables_selfnull.tex', 'w').write('\n'.join(lines))
print(f"Written appendix_tables_selfnull.tex ({len(df)} rows)")
