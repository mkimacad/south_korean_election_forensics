"""
make_appendix_table_selfnull.py

Builds the LaTeX longtable for the model-consistent self-null results
(appendix_selfnull_results.csv), in the same format as make_appendix_table.py.
"""
import pandas as pd

df = pd.read_csv('appendix_selfnull_results.csv')
df['elec'] = df['elec'].astype(str)

elec_label = {'pres16':'Pres02','pres17':'Pres07','18':'Gen08','19':'Gen12','pres18':'Pres12',
              '20':'Gen16','pres19':'Pres17','21':'Gen20','pres20':'Pres22','22':'Gen24','pres21':'Pres25'}

def esc(s):
    return str(s).replace('_', '-')

def fmt_pct3(v):
    return f"{100*v:.2f}" if pd.notna(v) else '--'

def fmt_rhat(v, conv):
    if pd.isna(v):
        return '--'
    marker = '$^{*}$' if conv else ''
    return f"{v:.2f}{marker}"

lines = []
lines.append(r"{\footnotesize")
lines.append(r"\begin{longtable}{p{1.0cm}p{1.15cm}p{1.55cm}rrrrc}")
lines.append(r"\caption{Model-consistent self-null results: $\pi$ forced to $(1,0,0)$ using the qbl model's own fitted class-1 (no-fraud) data-generating equations, short-chain configuration, Democratic-coded leader. $N$ is the unit count; ``Flagged'' is the number of units receiving a non-clean MAP classification. One cell (pres21/dong/early) failed with an invalid simulated draw and is omitted (Appendix~\ref{sec:appendix_selfnull}).} \label{tab:app_selfnull} \\")
lines.append(r"\toprule")
lines.append(r"Elec. & Level & Channel & $N$ & $\pi_1$ (no fraud) \% & Fraud share \% & Flagged & $\hat{R}$ \\")
lines.append(r"\midrule")
lines.append(r"\endfirsthead")
lines.append(r"\multicolumn{8}{c}{\tablename\ \thetable{} -- continued} \\")
lines.append(r"\toprule")
lines.append(r"Elec. & Level & Channel & $N$ & $\pi_1$ (no fraud) \% & Fraud share \% & Flagged & $\hat{R}$ \\")
lines.append(r"\midrule")
lines.append(r"\endhead")
lines.append(r"\bottomrule")
lines.append(r"\endfoot")
lvl_label = {'dong': 'dong', 'constituency': 'const.'}
for _, row in df.iterrows():
    e = elec_label.get(row['elec'], row['elec'])
    lvl = lvl_label.get(row['level'], row['level'])
    ch = esc(row['channel'])
    N = f"{int(row['n_units'])}"
    pi1 = fmt_pct3(row['p_no_fraud'])
    fs = fmt_pct3(row['fraud_share'])
    flagged = f"{int(row['n_flagged'])}/{int(row['n_units'])}"
    rhat = fmt_rhat(row['rhat'], row['not_converged'])
    lines.append(f"{e} & {lvl} & {ch} & {N} & {pi1} & {fs} & {flagged} & {rhat} \\\\")
lines.append(r"\end{longtable}")
lines.append(r"}")

open('appendix_tables_selfnull.tex', 'w').write('\n'.join(lines))
print(f"Written appendix_tables_selfnull.tex ({len(df)} rows)")
