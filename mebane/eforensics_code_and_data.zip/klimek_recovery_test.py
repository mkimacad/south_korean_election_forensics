"""Parameter-recovery test for klimek_analysis.fit_klimek: simulate from the
Klimek et al. model with known fraud fractions and check the fit returns them.
Dong-scale samples (n in the thousands) recover well; constituency-scale
samples (n ~ 250) do not, which is why the Klimek analysis is run at dong level."""
import sys, time, numpy as np
sys.path.insert(0,'.')
import klimek_analysis as K
def simulate(n, fi, fe, theta, alpha, seed):
    r=np.random.default_rng(seed)
    tau=K.trunc_normal(r.random(n),0.70,0.07); nu=K.trunc_normal(r.random(n),0.50,0.10)
    u=r.random(n); x=K.half_normal_01(r.random(n),theta); y=K.half_normal_01(r.random(n),K.SIGMA_X)
    frac=np.where(u<fi,x,np.where(u<fi+fe,1-y,0.0))
    a=(1-frac)*(1-tau); w=tau*nu+frac*(1-tau)+np.where(frac>0,frac**alpha,0)*(1-nu)*tau
    t=1-a; return t, np.clip(w/t,0,1)
CASES = [(0,0,.1,1,3500),(0.15,0.03,0.1,1.0,3500),(0.30,0.0,0.2,0.75,3500),
         (0,0,.1,1,2700),(0.15,0.03,0.1,1.0,2700),
         (0,0,.1,1,250),(0.10,0.02,0.1,1.0,250)]
rows=[]
for (fi,fe,th,al,n) in CASES:
    t,s=simulate(n,fi,fe,th,al,seed=11)
    t0=time.time(); b,_,_=K.fit_klimek(t,s,seed=3)
    rows.append(dict(n=n,true_fi=fi,true_fe=fe,true_theta=th,true_alpha=al,
                     fit_fi=b['fi'],fit_fe=b['fe'],fit_theta=b['theta'],fit_alpha=b['alpha'],
                     sse_reduction=b['sse_reduction']))
    print(f"true fi={fi:.3f} fe={fe:.3f} th={th} al={al} n={n} -> fit fi={b['fi']:.3f} fe={b['fe']:.3f} "
          f"th={b['theta']:.3f} al={b['alpha']:.2f} red={b['sse_reduction']:.2f} ({time.time()-t0:.1f}s)")
import os, pandas as pd
os.makedirs('klimek_output', exist_ok=True)
pd.DataFrame(rows).to_csv('klimek_output/klimek_recovery_results.csv', index=False)
print("wrote klimek_output/klimek_recovery_results.csv")
