#!/usr/bin/env Rscript
# mebane_crosscheck_selfnull_fit.R
#
# Identical to mebane_crosscheck.R (same model, same MCMC settings, same
# output_summary.csv / output_units.csv), EXCEPT it additionally monitors and
# writes out the posterior medians of the qbl model's class-1 ("no fraud")
# hyperparameters, so that a downstream Python generator can simulate a
# "model-consistent self-null" -- synthetic data drawn from the fitted qbl
# model's own no-fraud data-generating equations, with pi forced to (1,0,0)
# by construction (see the "model-consistent self-null" section of the manuscript).
#
# IMPORTANT SUBTLETY, read before using the extra output:
#   In the qbl JAGS model (ef_models.R), the per-unit turnout equation is
#       omt[j]    <- inprod(Xa[j,], beta.tau1)
#       th[j]     ~  dnorm(tau.alpha, tau.beta)
#       mu.tau[j] <- ilogit(th[j] + omt[j])
#   i.e. the province design matrix Xa is multiplied by the RAW vector
#   beta.tau1 (a free coefficient at every index, including the intercept
#   position; note that JAGS's dmnorm takes a PRECISION matrix, and the qbl
#   model sets that precision to 10000 at the intercept position, so the
#   intercept entry of beta.tau1 is effectively pinned near zero rather than
#   given a flat prior -- the overall intercept is carried by tau.alpha
#   instead), while the
#   per-unit random intercept th[j] is centered on the SEPARATE parameter
#   tau.alpha (a N(0,1) prior). The commonly-reported combined vector
#   "beta.tau" (used elsewhere in this driver / in output_summary.csv)
#   overwrites position 1 with tau.alpha:
#       beta.tau[i] <- ifelse(i == 1, tau.alpha, beta.tau1[i])
#   so beta.tau[1] != beta.tau1[1] in general. If you reconstruct omt[j]
#   using the reported "beta.tau" instead of the raw "beta.tau1", the
#   simulated turnout will be systematically off. The same applies to
#   beta.nu1/beta.nu and nu.alpha. This script therefore monitors and saves
#   beta.tau1, beta.nu1, tau.alpha, nu.alpha, tb, and nb explicitly, and
#   generate_model_self_null.py uses beta.tau1/beta.nu1 (NOT beta.tau/
#   beta.nu) for the province design-matrix term, adding tau.alpha/nu.alpha
#   only as the mean of the freshly-simulated per-unit random intercept.
#
# Usage:
#   Rscript mebane_crosscheck_selfnull_fit.R <input.csv> <output.csv> [n_iter] [n_chains] [burn_in] [use_parcomp]
#
# input.csv must contain columns: leader_votes, total_votes, eligible, prov_code
#
# Outputs (in addition to the usual <output.csv> and <output.csv>_units.csv):
#   <output.csv> with "_hyperparams.csv" substituted for ".csv" -- long-format
#   CSV with columns (param, median), where param is one of:
#     beta_tau1_1, beta_tau1_2, ..., beta_tau1_<dxa>   (raw province vector, turnout eqn)
#     beta_nu1_1,  beta_nu1_2,  ..., beta_nu1_<dxw>    (raw province vector, vote-share eqn)
#     tau_alpha, nu_alpha                              (per-unit random-intercept means)
#     tb, nb                                           (per-unit random-intercept variances;
#                                                        JAGS precisions are tau.beta=1/tb, nu.beta=1/nb)
#   The province level ordering matches R's default factor()/model.matrix()
#   treatment contrasts on prov_code: levels sorted ascending, first level is
#   the reference (absorbed into the intercept, i.e. column 1 of Xa/Xw).

suppressMessages(library(eforensics))

# --- Optional latent-turnout (tau) form of the leader-vote likelihood -------
# Set EFORENSICS_WFORM=tau to swap the package's qbl model for the fork in
# ef_qbl_tau.R, which writes p.w[j] in terms of the latent turnout mu.tau[j]
# instead of the realized abstentions a[j]/N[j]. Unset (default) or
# "conditional" runs the package's own qbl unchanged.
W_FORM <- tolower(Sys.getenv("EFORENSICS_WFORM", "conditional"))
if (W_FORM == "tau") {
  script_dir <- tryCatch(dirname(normalizePath(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]))),
                         error = function(e) ".")
  source(file.path(script_dir, "ef_qbl_tau.R"))
  activate_tau_form()
} else if (W_FORM != "conditional") {
  stop("EFORENSICS_WFORM must be 'conditional' (default) or 'tau', got '", W_FORM, "'")
}

# --- Optional PSRF (Gelman-Rubin) stopping rule -----------------------------
# eforensics() defaults to autoConv = TRUE with mcmc.conv.diagnostic = "MCMCSE"
# (per-chain Monte Carlo SE of pi below 0.05; up to max.auto = 10 extensions).
# Set EFORENSICS_CONV=psrf to use the package's own alternative rule instead,
# which requires psrf < 1.05 for every monitored pi component, extending the
# chains up to EFORENSICS_MAX_AUTO times (default: the package's 10). Unset
# (default) or "mcmcse" leaves the package defaults untouched.
CONV_RULE <- tolower(Sys.getenv("EFORENSICS_CONV", "mcmcse"))
if (!CONV_RULE %in% c("mcmcse", "psrf")) stop("EFORENSICS_CONV must be 'mcmcse' (default) or 'psrf', got '", CONV_RULE, "'")
MAX_AUTO <- suppressWarnings(as.integer(Sys.getenv("EFORENSICS_MAX_AUTO", "10")))
if (is.na(MAX_AUTO) || MAX_AUTO < 0) MAX_AUTO <- 10L
suppressMessages(library(coda))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2) {
  stop("Usage: Rscript mebane_crosscheck_selfnull_fit.R <input.csv> <output.csv> [n_iter] [n_chains] [burn_in] [use_parcomp]")
}

input_path   <- args[1]
output_path  <- args[2]
n_iter       <- if (length(args) >= 3) as.integer(args[3]) else 1000   # short-chain default
n_chains     <- if (length(args) >= 4) as.integer(args[4]) else 4
burn_in      <- if (length(args) >= 5) as.integer(args[5]) else 300    # short-chain default
use_parcomp  <- if (length(args) >= 6) as.logical(args[6]) else TRUE

cat(sprintf("[R-Model] Reading input data from: %s\n", input_path))
raw <- read.csv(input_path)

required_cols <- c("leader_votes", "total_votes", "eligible", "prov_code")
missing <- setdiff(required_cols, names(raw))
if (length(missing) > 0) {
  stop(sprintf("Input CSV missing required column(s): %s", paste(missing, collapse = ", ")))
}

data <- data.frame(
  w = round(raw$leader_votes),
  a = round(raw$eligible - raw$total_votes),
  N = round(raw$eligible),
  prov = factor(raw$prov_code)   # sorted ascending by factor()'s default; first level = reference
)

bad <- data$w < 0 | data$a < 0 | (data$w + data$a) > data$N
if (any(bad)) {
  stop(sprintf("Data sanity error: %d row(s) have invalid vote counts (w<0, a<0, or w+a>N).", sum(bad)))
}

cat(sprintf("[R-Model] N=%d units, %d province(s). Fitting Quasi-Binomial-Logistic ('qbl') model (self-null hyperparameter extraction)...\n",
            nrow(data), nlevels(data$prov)))

mcmc_params <- list(burn.in = burn_in, n.adapt = 1000, n.iter = n_iter, n.chains = n_chains)

ef_formal_names <- names(formals(eforensics))
if ("eligible.voters" %in% ef_formal_names) {
  eligible_arg_name <- "eligible.voters"
} else if ("elegible.voters" %in% ef_formal_names) {
  eligible_arg_name <- "elegible.voters"
} else {
  stop("Could not find an eligible-voters argument in the installed eforensics package.")
}
cat(sprintf("[R-Model] Detected eforensics() eligible-voters argument name: '%s'\n", eligible_arg_name))

# Same base parameter set as mebane_crosscheck.R, PLUS the raw province
# vectors (beta.tau1/beta.nu1), the random-intercept means (tau.alpha/
# nu.alpha), and the random-intercept variances (tb/nb) needed to rebuild
# the class-1 data-generating process exactly.
qbl_parameters <- c("pi", "beta.tau", "beta.nu", "beta.iota.m", "beta.iota.s",
                     "beta.chi.m", "beta.chi.s", "Z",
                     "beta.tau1", "beta.nu1", "tau.alpha", "nu.alpha", "tb", "nb",
                     "mu.tau", "mu.nu")   # for model-consistent fraudulent-vote counts

ef_args <- list(
  formula1 = w ~ prov,
  formula2 = a ~ prov,
  data = data,
  model = "qbl",
  mcmc = mcmc_params,
  get.dic = 0,
  parComp = use_parcomp,
  parameters = qbl_parameters
)
ef_args[[eligible_arg_name]] <- "N"
ef_args$autoConv <- TRUE
ef_args$max.auto <- MAX_AUTO
if (CONV_RULE == "psrf") {
  ef_args$mcmc.conv.diagnostic <- "PSRF"
  cat(sprintf("[R-Model] Stopping rule: PSRF < 1.05 on pi, up to %d extensions.\n", MAX_AUTO))
} else {
  # Logged in both cases so that every log records which rule was in force.
  cat(sprintf("[R-Model] Stopping rule: MCMCSE < 0.05 on pi (package default), up to %d extensions.\n", MAX_AUTO))
}

t0 <- Sys.time()
samples <- do.call(eforensics, ef_args)
elapsed <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
cat(sprintf("[R-Model] Execution complete in %.1f seconds.\n", elapsed))

pi_pooled <- do.call(rbind, lapply(samples, function(ch) {
  ch$parameters[, c("pi[1]", "pi[2]", "pi[3]")]
}))
pi_median <- apply(pi_pooled, 2, median)
pi_hpd <- coda::HPDinterval(coda::as.mcmc(pi_pooled), prob = 0.95)

# --- Fraud share (pi[2] + pi[3]) -------------------------------------------
# Computed per MCMC draw, so that its 95% HPD interval is a TRUE interval for
# the sum rather than the sum of the two component intervals. The two differ
# because pi[2] and pi[3] are posteriorly dependent: adding the separate HPD
# bounds ignores that dependence and yields a strictly conservative (wider)
# outer bound. Both are written out below so downstream tables can report
# either. Note also that median(pi[2] + pi[3]) is not in general equal to
# median(pi[2]) + median(pi[3]); the manuscript's headline fraud share is the
# sum of the component medians, reported here as fraud_share_sum_of_medians,
# while fraud_share_joint_median is the median of the per-draw sum.
fraud_share_draws <- as.numeric(pi_pooled[, "pi[2]"]) + as.numeric(pi_pooled[, "pi[3]"])
fraud_share_joint_median <- median(fraud_share_draws)
fraud_share_joint_hpd <- coda::HPDinterval(
  coda::as.mcmc(matrix(fraud_share_draws, ncol = 1)), prob = 0.95)

pi_mcmc_list <- coda::mcmc.list(lapply(samples, function(ch) {
  coda::as.mcmc(ch$parameters[, c("pi[1]", "pi[2]", "pi[3]")])
}))
rhat <- tryCatch({
  gd <- coda::gelman.diag(pi_mcmc_list, autoburnin = FALSE, multivariate = FALSE)
  max(gd$psrf[, "Point est."])
}, error = function(e) NA_real_)

chain_pi_means <- do.call(rbind, lapply(samples, function(ch) {
  colMeans(ch$parameters[, c("pi[1]", "pi[2]", "pi[3]")])
}))
M_pi <- if (nrow(chain_pi_means) > 1) apply(chain_pi_means, 2, function(x) max(x) - min(x)) else c(NA_real_, NA_real_, NA_real_)

D_pi <- tryCatch({
  if (!requireNamespace("diptest", quietly = TRUE)) stop("diptest not installed")
  apply(pi_pooled, 2, function(x) diptest::dip.test(x)$p.value)
}, error = function(e) {
  cat(sprintf("[R-Model] NOTE: D(pi_j) dip test unavailable (%s) -- reporting NA.\n", conditionMessage(e)))
  c(NA_real_, NA_real_, NA_real_)
})

# Same model-consistent fraudulent-vote computation as mebane_crosscheck.R.
fraud_votes <- tryCatch({
  raw <- attr(samples, "samples")
  if (is.null(raw)) stop("attr(samples, 'samples') is NULL -- package version does not expose raw draws")
  chains <- raw[[1]]
  n_units <- nrow(data)
  unit_cols <- function(ch, node) {
    cn <- paste0(node, "[", seq_len(n_units), "]")
    miss <- setdiff(cn, colnames(ch))
    if (length(miss)) stop(sprintf("node '%s' not monitored (missing e.g. %s)", node, miss[1]))
    ch[, cn, drop = FALSE]
  }
  Ft_d <- Fw_d <- Ftp_d <- Fwp_d <- numeric(0)
  unit_m <- unit_s <- numeric(n_units); n_draws <- 0
  for (ch in chains) {
    ch  <- as.matrix(ch)
    Z   <- unit_cols(ch, "Z")
    tau <- unit_cols(ch, "mu.tau")
    nu  <- unit_cols(ch, "mu.nu")
    f_m <- (Z == 2) * unit_cols(ch, "iota.m") + (Z == 3) * unit_cols(ch, "chi.m")
    f_s <- (Z == 2) * unit_cols(ch, "iota.s") + (Z == 3) * unit_cols(ch, "chi.s")
    m <- f_m * (1 - tau)
    s <- f_s * tau * (1 - nu)
    Ft_d  <- c(Ft_d,  as.vector(m %*% data$N))
    Fw_d  <- c(Fw_d,  as.vector((m + s) %*% data$N))
    Ftp_d <- c(Ftp_d, as.vector(f_m %*% data$N))
    Fwp_d <- c(Fwp_d, as.vector((f_m + f_s) %*% data$N))
    unit_m <- unit_m + colSums(m); unit_s <- unit_s + colSums(s)
    n_draws <- n_draws + nrow(ch)
  }
  hpd <- function(x) coda::HPDinterval(coda::as.mcmc(matrix(x, ncol = 1)), prob = 0.95)[1, ]
  ht <- hpd(Ft_d); hw <- hpd(Fw_d)
  list(Ft_total = mean(Ft_d), Ft_total_lo = unname(ht["lower"]), Ft_total_hi = unname(ht["upper"]),
       Fw_total = mean(Fw_d), Fw_total_lo = unname(hw["lower"]), Fw_total_hi = unname(hw["upper"]),
       Ft_pkg_total = mean(Ftp_d), Fw_pkg_total = mean(Fwp_d),
       unit_manufactured = data$N * unit_m / n_draws, unit_stolen = data$N * unit_s / n_draws,
       available = TRUE)
}, error = function(e) {
  cat(sprintf("[R-Model] NOTE: Ft/Fw computation failed (%s) -- reporting NA.\n", conditionMessage(e)))
  list(Ft_total = NA_real_, Ft_total_lo = NA_real_, Ft_total_hi = NA_real_,
       Fw_total = NA_real_, Fw_total_lo = NA_real_, Fw_total_hi = NA_real_,
       Ft_pkg_total = NA_real_, Fw_pkg_total = NA_real_,
       unit_manufactured = rep(NA_real_, nrow(data)), unit_stolen = rep(NA_real_, nrow(data)),
       available = FALSE)
})

piZi_avg <- Reduce(`+`, lapply(samples, function(ch) ch$piZi)) / length(samples)
map_class <- apply(piZi_avg, 1, which.max)
n_no_fraud    <- sum(map_class == 1)
n_incremental <- sum(map_class == 2)
n_extreme     <- sum(map_class == 3)
n_flagged     <- n_incremental + n_extreme

out_summary <- data.frame(
  total_units = nrow(data),
  p_no_fraud_median = pi_median[1],
  p_incremental_median = pi_median[2],
  p_extreme_median = pi_median[3],
  fraud_share_sum_of_medians = pi_median[2] + pi_median[3],
  fraud_share_joint_median = fraud_share_joint_median,
  fraud_share_hpd95_lo = fraud_share_joint_hpd[1, "lower"],
  fraud_share_hpd95_hi = fraud_share_joint_hpd[1, "upper"],
  fraud_share_cons_hpd95_lo = pi_hpd["pi[2]", "lower"] + pi_hpd["pi[3]", "lower"],
  fraud_share_cons_hpd95_hi = pi_hpd["pi[2]", "upper"] + pi_hpd["pi[3]", "upper"],
  rhat_pi = rhat,
  w_form = W_FORM,
  conv_rule = CONV_RULE,
  max_auto = MAX_AUTO,
  M_pi_no_fraud = M_pi[1], M_pi_incremental = M_pi[2], M_pi_extreme = M_pi[3],
  D_pi_no_fraud = D_pi[1], D_pi_incremental = D_pi[2], D_pi_extreme = D_pi[3],
  Ft_total = fraud_votes$Ft_total, Fw_total = fraud_votes$Fw_total,
  fraud_votes_available = fraud_votes$available,
  n_regions_flagged = n_flagged, n_regions_no_fraud = n_no_fraud,
  n_regions_incremental = n_incremental, n_regions_extreme = n_extreme,
  elapsed_seconds = elapsed
)
write.csv(out_summary, output_path, row.names = FALSE)

units_path <- sub("\\.csv$", "_units.csv", output_path)
write.csv(data.frame(unit_index = seq_len(nrow(data)),
                     p_no_fraud = piZi_avg[, 1],
                     p_incremental = piZi_avg[, 2],
                     p_extreme = piZi_avg[, 3],
                     map_class = map_class - 1),
          units_path, row.names = FALSE)

# ---- Class-1 hyperparameters for the model-consistent self-null ----------
extract_vec_median <- function(prefix) {
  pooled <- do.call(rbind, lapply(samples, function(ch) {
    cols <- grep(paste0("^", prefix, "\\["), colnames(ch$parameters), value = TRUE)
    ch$parameters[, cols, drop = FALSE]
  }))
  # order columns numerically by their bracket index, not lexicographically
  idx <- as.integer(sub(paste0(prefix, "\\[(\\d+)\\]"), "\\1", colnames(pooled)))
  pooled <- pooled[, order(idx), drop = FALSE]
  apply(pooled, 2, median)
}
extract_scalar_median <- function(name) {
  pooled <- do.call(c, lapply(samples, function(ch) ch$parameters[, name]))
  median(pooled)
}

beta_tau1_median <- extract_vec_median("beta.tau1")
beta_nu1_median  <- extract_vec_median("beta.nu1")
tau_alpha_median <- extract_scalar_median("tau.alpha")
nu_alpha_median  <- extract_scalar_median("nu.alpha")
tb_median <- extract_scalar_median("tb")
nb_median <- extract_scalar_median("nb")

hyper_path <- sub("\\.csv$", "_hyperparams.csv", output_path)
write.csv(data.frame(
  param = c(paste0("beta_tau1_", seq_along(beta_tau1_median)),
            paste0("beta_nu1_", seq_along(beta_nu1_median)),
            "tau_alpha", "nu_alpha", "tb", "nb"),
  median = c(beta_tau1_median, beta_nu1_median,
             tau_alpha_median, nu_alpha_median, tb_median, nb_median)
), hyper_path, row.names = FALSE)

# Also record the ascending prov_code level order used for Xa/Xw, so the
# Python side can map beta_tau1_2/beta_nu1_2, etc. to the correct prov_code
# (position 1 is always the reference level, absorbed into the intercept).
levels_path <- sub("\\.csv$", "_provlevels.csv", output_path)
write.csv(data.frame(position = seq_len(nlevels(data$prov)),
                     prov_code = as.integer(levels(data$prov))),
          levels_path, row.names = FALSE)

cat(sprintf("[R-Model] Summaries saved to %s, %s, %s, and %s\n",
            output_path, units_path, hyper_path, levels_path))
