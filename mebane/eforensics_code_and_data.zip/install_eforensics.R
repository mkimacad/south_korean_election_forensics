#!/usr/bin/env Rscript
# install_eforensics.R
#
# Installs the `eforensics` R package, which is only distributed on GitHub
# (UMeforensics/eforensics_public) -- it is not on CRAN or conda-forge, so it
# can't be pulled in by environment.yml directly. Everything else this
# project needs (R itself, JAGS, rjags, coda, diptest, remotes) is already
# provided by the conda environment; this script's only job is the one
# GitHub-only piece, using R's own `remotes` package (itself installed via
# conda) rather than a raw system call.
#
# Run inside the activated conda env, e.g.:
#   conda run -n eforensics Rscript install_eforensics.R
# (setup_env.sh does this automatically.)

repo <- "UMeforensics/eforensics_public"

cat(sprintf("[install_eforensics] Checking for an existing 'eforensics' install...\n"))

if (requireNamespace("eforensics", quietly = TRUE)) {
  cat(sprintf("[install_eforensics] 'eforensics' already installed (version %s) -- skipping.\n",
              as.character(utils::packageVersion("eforensics"))))
} else {
  cat(sprintf("[install_eforensics] Installing 'eforensics' from GitHub (%s)...\n", repo))
  if (!requireNamespace("remotes", quietly = TRUE)) {
    stop("'remotes' is not installed. It should come from environment.yml (r-remotes); ",
         "re-run setup_env.sh or `conda install -n eforensics -c conda-forge r-remotes`.")
  }
  remotes::install_github(repo, upgrade = "never", dependencies = TRUE)
}

# diptest is also in environment.yml (r-diptest), but mebane_crosscheck.R only
# *degrades* gracefully without it (reports NA for the dip-test diagnostic) --
# it doesn't hard-fail. Fall back to CRAN here just in case someone runs this
# script against an env that skipped r-diptest for some reason.
if (!requireNamespace("diptest", quietly = TRUE)) {
  cat("[install_eforensics] 'diptest' not found -- installing from CRAN as a fallback...\n")
  install.packages("diptest", repos = "https://cloud.r-project.org")
}

# --- Sanity check: load everything mebane_crosscheck*.R actually needs ---
cat("[install_eforensics] Verifying required libraries load cleanly...\n")
suppressMessages({
  library(eforensics)
  library(coda)
  library(rjags)
})
cat(sprintf("[install_eforensics] OK -- eforensics %s, coda %s, rjags %s, JAGS library version %s\n",
            as.character(utils::packageVersion("eforensics")),
            as.character(utils::packageVersion("coda")),
            as.character(utils::packageVersion("rjags")),
            tryCatch(as.character(rjags::JAGS.version()), error = function(e) "unknown")))

cat("[install_eforensics] Done.\n")
