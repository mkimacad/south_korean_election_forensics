#!/usr/bin/env Rscript
# install_eforensics.R
#
# Installs the `eforensics` R package, which is only distributed on GitHub
# (UMeforensics/eforensics_public) -- it is not on CRAN or conda-forge, so it
# can't be pulled in by environment.yml directly. Everything else this
# project needs (R itself, JAGS, rjags, coda, diptest, remotes, and the
# system libraries several CRAN dependencies need to compile -- zlib,
# libxml2, fftw, libuv, pkg-config) is already provided by the conda
# environment; this script's only job is the one GitHub-only piece, using
# R's own `remotes` package (itself installed via conda) rather than a raw
# system call.
#
# Run inside the activated conda env, e.g.:
#   conda run -n eforensics Rscript install_eforensics.R
# (setup_env.sh does this automatically.)

# `conda run` doesn't always fully propagate every package's
# etc/conda/activate.d PKG_CONFIG_PATH hook down to subprocesses that R's
# own package installer spawns (e.g. `configure` scripts calling
# pkg-config). Set it explicitly from CONDA_PREFIX here so pkg-config-based
# dependency detection (e.g. libxml2, for the xml2 package) works
# regardless of how this script was launched.
conda_prefix <- Sys.getenv("CONDA_PREFIX")
if (nzchar(conda_prefix)) {
  pkgconfig_dir <- file.path(conda_prefix, "lib", "pkgconfig")
  existing_pkg_config_path <- Sys.getenv("PKG_CONFIG_PATH")
  Sys.setenv(PKG_CONFIG_PATH = if (nzchar(existing_pkg_config_path)) {
    paste(pkgconfig_dir, existing_pkg_config_path, sep = .Platform$path.sep)
  } else {
    pkgconfig_dir
  })
  cat(sprintf("[install_eforensics] PKG_CONFIG_PATH set to: %s\n", Sys.getenv("PKG_CONFIG_PATH")))
}

repo <- "UMeforensics/eforensics_public"

# eforensics's DESCRIPTION lists 'LCA' as a hard Import, but per its own
# cran-comments.md ("Namespaces in Imports field not imported from: 'LCA'
# 'rjags' -- All declared Imports should be used"), the package's code never
# actually calls anything from LCA -- it's a declared-but-unused dependency.
# It's a genuine small CRAN package (not a stand-in for something else), but
# on some CRAN mirror snapshots it doesn't resolve through the normal
# available.packages() lookup that remotes uses, which then blocks the whole
# eforensics install even though nothing in this pipeline needs LCA's
# functionality. Install it directly by URL first so remotes finds it
# already present and skips re-resolving it.
if (!requireNamespace("LCA", quietly = TRUE)) {
  cat("[install_eforensics] 'LCA' not found -- installing directly (eforensics declares it ")
  cat("as an Import but its own cran-comments.md confirms the code never calls it)...\n")
  lca_urls <- c(
    "https://cran.r-project.org/src/contrib/LCA_0.1.1.tar.gz",
    "https://cran.r-project.org/src/contrib/Archive/LCA/LCA_0.1.1.tar.gz"
  )
  lca_installed <- FALSE
  for (url in lca_urls) {
    result <- tryCatch({
      install.packages(url, repos = NULL, type = "source")
      requireNamespace("LCA", quietly = TRUE)
    }, error = function(e) FALSE)
    if (isTRUE(result)) {
      lca_installed <- TRUE
      break
    }
  }
  if (!lca_installed) {
    stop("Could not install 'LCA' from any known URL. Try installing it manually first, e.g.\n",
         "  install.packages('https://cran.r-project.org/src/contrib/LCA_0.1.1.tar.gz', repos = NULL, type = 'source')\n",
         "then re-run this script.")
  }
}

cat(sprintf("[install_eforensics] Checking for an existing 'eforensics' install...\n"))

if (requireNamespace("eforensics", quietly = TRUE)) {
  cat(sprintf("[install_eforensics] 'eforensics' already installed (version %s) -- skipping.\n",
              as.character(utils::packageVersion("eforensics"))))
} else {
  cat(sprintf("[install_eforensics] Installing 'eforensics' from GitHub (%s)...\n", repo))
  if (!requireNamespace("remotes", quietly = TRUE)) {
    stop("'remotes' is not installed. It should come from environment.yml (r-remotes); ",
         "re-run setup_env.sh or `conda install -n eforensics -c conda-forge r-remotes`.")
  }
  remotes::install_github(repo, upgrade = "never", dependencies = TRUE)
}

# diptest is also in environment.yml (r-diptest), but mebane_crosscheck.R only
# *degrades* gracefully without it (reports NA for the dip-test diagnostic) --
# it doesn't hard-fail. Fall back to CRAN here just in case someone runs this
# script against an env that skipped r-diptest for some reason.
if (!requireNamespace("diptest", quietly = TRUE)) {
  cat("[install_eforensics] 'diptest' not found -- installing from CRAN as a fallback...\n")
  install.packages("diptest", repos = "https://cloud.r-project.org")
}

# --- Sanity check: load everything mebane_crosscheck*.R actually needs ---
cat("[install_eforensics] Verifying required libraries load cleanly...\n")
suppressMessages({
  library(eforensics)
  library(coda)
  library(rjags)
})
cat(sprintf("[install_eforensics] OK -- eforensics %s, coda %s, rjags %s, JAGS library version %s\n",
            as.character(utils::packageVersion("eforensics")),
            as.character(utils::packageVersion("coda")),
            as.character(utils::packageVersion("rjags")),
            tryCatch(as.character(rjags::JAGS.version()), error = function(e) "unknown")))

cat("[install_eforensics] Done.\n")
