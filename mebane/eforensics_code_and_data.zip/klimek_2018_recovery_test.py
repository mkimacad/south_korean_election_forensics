"""Parameter-recovery test for klimek_2018.py (Klimek et al.'s 2018 procedure:
2-D RSS on 1% fingerprints, plug-in clean component, 200 sweeps), on the same
simulated cases as klimek_recovery_test.py and klimek_original_recovery_test.py,
plus three cases at n = 13,500 (the size of the 투표구-level datasets)."""
import os
import sys
import time

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import klimek_2018 as K18


def simulate(n, fi, fe, theta, alpha, seed):
    r = np.random.default_rng(seed)
    tau = K18.trunc_normal(r.random(n), 0.70, 0.07)
    nu = K18.trunc_normal(r.random(n), 0.50, 0.10)
    u = r.random(n)
    x = K18.half_normal_01(r.random(n), theta)
    y = K18.half_normal_01(r.random(n), K18.SIGMA_X)
    frac = np.where(u < fi, x, np.where(u < fi + fe, 1 - y, 0.0))
    a = (1 - frac) * (1 - tau)
    w = tau * nu + frac * (1 - tau) + np.where(frac > 0, frac ** alpha, 0) * (1 - nu) * tau
    t = 1 - a
    return t, np.clip(w / t, 0, 1)


OUT = 'klimek_original_output/klimek_2018_recovery_results.csv'

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description="Resumable: cases already in the output CSV are skipped.")
    ap.add_argument('--n-max', type=int, default=None, help="only run cases with n <= this")
    ap.add_argument('--fresh', action='store_true', help="discard existing results first")
    args = ap.parse_args()
    CASES = [(0, 0, .1, 1, 3500), (0.15, 0.03, 0.1, 1.0, 3500), (0.30, 0.0, 0.2, 0.75, 3500),
             (0, 0, .1, 1, 2700), (0.15, 0.03, 0.1, 1.0, 2700), (0, 0, .1, 1, 250), (0.10, 0.02, 0.1, 1.0, 250),
             (0, 0, .1, 1, 13500), (0.15, 0.03, 0.1, 1.0, 13500), (0.30, 0.0, 0.2, 0.75, 13500)]
    os.makedirs('klimek_original_output', exist_ok=True)
    if args.fresh and os.path.exists(OUT):
        os.remove(OUT)
    done = set()
    if os.path.exists(OUT):
        d0 = pd.read_csv(OUT)
        if 'n_real' in d0 and (d0.n_real == K18.N_REAL).all() and (d0.bins == K18.NB).all():
            done = set(zip(d0.n, d0.true_fi, d0.true_fe))
        else:
            os.remove(OUT)   # results from an earlier estimator configuration
    for fi, fe, th, al, n in CASES:
        if (args.n_max and n > args.n_max) or (n, fi, fe) in done:
            continue
        t, s = simulate(n, fi, fe, th, al, seed=11)
        t0 = time.time()
        r = K18.estimate(t, s)
        row = dict(n=n, true_fi=fi, true_fe=fe, true_theta=th, true_alpha=al,
                   fit_fi=r['fi'], fit_fi_sd=r['fi_sd'], fit_fe=r['fe'], fit_fe_sd=r['fe_sd'],
                   fit_alpha=r['alpha'], bins=r['bins'], n_real=r['n_real'])
        pd.DataFrame([row]).to_csv(OUT, mode='a', header=not os.path.exists(OUT), index=False)
        print(f"true fi={fi:.2f} fe={fe:.2f} th={th} al={al} n={n} -> fi={r['fi']:.3f}({r['fi_sd']:.3f}) "
              f"fe={r['fe']:.3f}({r['fe_sd']:.3f}) alpha={r['alpha']:.2f} bins={r['bins']} [{time.time()-t0:.1f}s]",
              flush=True)
