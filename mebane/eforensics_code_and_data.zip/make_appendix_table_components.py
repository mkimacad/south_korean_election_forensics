import pandas as pd
import numpy as np

df = pd.read_csv('appendix_components_results.csv')
df['elec'] = df['elec'].astype(str)

elec_label = {'pres16':'Pres02','pres17':'Pres07','18':'Gen08','19':'Gen12','pres18':'Pres12',
              '20':'Gen16','pres19':'Pres17','21':'Gen20','pres20':'Pres22','22':'Gen24','pres21':'Pres25'}
src_label = {'real':'real','marginal_null':'marg.null','joint_null':'joint.null'}
lvl_label = {'dong': 'dong', 'constituency': 'const.'}

def esc(s):
    return str(s).replace('_', '-')

def fmt_pct(v, lo, hi):
    if pd.isna(v):
        return '--'
    base = f"{100*v:.2f}"
    if pd.isna(lo) or pd.isna(hi):
        return base
    return f"{base} [{100*lo:.1f},{100*hi:.1f}]"

def make_table(sub, caption, label):
    lines = []
    lines.append(r"{\footnotesize")
    lines.append(r"\begin{longtable}{p{0.9cm}p{0.85cm}p{1.3cm}p{1.15cm}p{2.2cm}p{2.2cm}p{2.1cm}}")
    lines.append(rf"\caption{{{caption}}} \label{{{label}}} \\")
    lines.append(r"\toprule")
    lines.append(r"Elec. & Level & Channel & Source & $p_{\text{no-fraud}}$ \% [CI] & $p_{\text{incr.}}$ \% [CI] & $p_{\text{extr.}}$ \% [CI] \\")
    lines.append(r"\midrule")
    lines.append(r"\endfirsthead")
    lines.append(rf"\multicolumn{{7}}{{c}}{{\tablename\ \thetable{{}} -- continued}} \\")
    lines.append(r"\toprule")
    lines.append(r"Elec. & Level & Channel & Source & $p_{\text{no-fraud}}$ \% [CI] & $p_{\text{incr.}}$ \% [CI] & $p_{\text{extr.}}$ \% [CI] \\")
    lines.append(r"\midrule")
    lines.append(r"\endhead")
    lines.append(r"\bottomrule")
    lines.append(r"\endfoot")
    for _, row in sub.iterrows():
        e = elec_label.get(row['elec'], row['elec'])
        lvl = lvl_label.get(row['level'], row['level'])
        ch = esc(row['channel'])
        src = src_label.get(row['source'], row['source'])
        p1 = fmt_pct(row['p_no_fraud'], row['p_nf_lo'], row['p_nf_hi'])
        p2 = fmt_pct(row['p_incr'], row['p_incr_lo'], row['p_incr_hi'])
        p3 = fmt_pct(row['p_ext'], row['p_ext_lo'], row['p_ext_hi'])
        lines.append(f"{e} & {lvl} & {ch} & {src} & {p1} & {p2} & {p3} \\\\")
    lines.append(r"\end{longtable}")
    lines.append(r"}")
    return '\n'.join(lines)

blocks = []
specs = [
    ('previous_settings', 'dem', "Mixture-component probabilities, long-chain configuration (n.iter=5000), Democratic-coded leader. Full coverage, all 11 elections. $p_{\\text{no-fraud}}+p_{\\text{incr.}}+p_{\\text{extr.}}=1$ for every row up to rounding; fraud share as reported elsewhere in this paper is $p_{\\text{incr.}}+p_{\\text{extr.}}$.", "tab:app_comp_prev_dem"),
    ('previous_settings', 'con', "Mixture-component probabilities, long-chain configuration (n.iter=5000), conservative-coded leader. Full coverage, all 11 elections.", "tab:app_comp_prev_con"),
    ('new_settings', 'dem', "Mixture-component probabilities, short-chain configuration, Democratic-coded leader. Full coverage, all 11 elections.", "tab:app_comp_new_dem"),
    ('new_settings', 'con', "Mixture-component probabilities, short-chain configuration, conservative-coded leader. Full coverage, all 11 elections.", "tab:app_comp_new_con"),
]
for dataset, leader, caption, label in specs:
    sub = df[(df['dataset']==dataset) & (df['leader_side']==leader)].copy()
    elec_order = ['18','19','pres16','pres17','pres18','20','pres19','21','pres20','22','pres21']
    sub['eo'] = sub['elec'].map({e:i for i,e in enumerate(elec_order)})
    so = {'real':0,'marginal_null':1,'joint_null':2}
    sub['so'] = sub['source'].map(so)
    sub = sub.sort_values(['eo','level','channel','so'])
    blocks.append(make_table(sub, caption, label))
    print(f"{dataset}/{leader}: {len(sub)} rows")

open('appendix_tables_components.tex', 'w').write('\n\n\\newpage\n\n'.join(blocks))
print("Written appendix_tables_components.tex")
