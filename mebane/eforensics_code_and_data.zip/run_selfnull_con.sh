#!/usr/bin/env bash
# ============================================================================
# run_selfnull_con.sh
#
# The two model-consistent self-null analyses with the CONSERVATIVE-coded leader:
#   1. self-null, observed-turnout form        -> output_data_v2/con_leader
#   2. self-null, latent-turnout (tau) form -> output_data_v2_tau/con_leader
# Same settings, output directories, preflight check and resumability as
# run_all_eforensics_con.sh, which now also includes these two steps. Use this
# script only if run_all_eforensics_con.sh has already run without them. Do NOT
# run it at the same time as run_all_eforensics_con.sh: both write the same
# cells, and two launchers starting the same cell at once would clash.
#
# Do NOT edit any .R/.py/.sh file in this directory while this is running.
#
# Usage (from the code directory):   nohup ./run_selfnull_con.sh > run_selfnull_con.out 2>&1 &
# ============================================================================
set -u
cd "$(dirname "$0")"

MAX_PARALLEL=8
SIDE=con
STATUS_DIR="run_all_status"
mkdir -p "$STATUS_DIR"
SUMMARY="$STATUS_DIR/run_selfnull_${SIDE}.summary"

# ---- preflight: refuse to start with code that predates the current fixes ----
fail=0
need() { grep -q "$2" "$1" 2>/dev/null || { echo "PREFLIGHT FAIL: $1 lacks '$2' ($3)"; fail=1; }; }
for f in run_mebane_r_all_parallel_bidirectional.sh run_mebane_self_null_parallel.sh run_psrf_constituency.sh \
         mebane_r_driver_bidirectional.py mebane_self_null_driver.py mebane_crosscheck.R \
         mebane_crosscheck_selfnull_fit.R ef_qbl_tau.R; do
  [ -f "$f" ] || { echo "PREFLIGHT FAIL: missing $f"; fail=1; }
done
need mebane_crosscheck.R 'fraud_votes_definition = "model"' "model-consistent fraudulent-vote counts"
need mebane_crosscheck.R '"mu.tau", "mu.nu"' "monitors latent turnout and leader share"
need mebane_crosscheck_selfnull_fit.R '"mu.tau", "mu.nu"' "self-null stage 1 monitors"
need mebane_self_null_driver.py 'redrawn jointly' "self-null feasibility redraw"
need mebane_r_driver_bidirectional.py 'fraud_votes_definition' "driver prints the F definition"
command -v Rscript >/dev/null || { echo "PREFLIGHT FAIL: Rscript not found"; fail=1; }
[ "$fail" = 0 ] || { echo "Aborting: fix the problems above first."; exit 1; }

echo "run_selfnull_${SIDE}: started $(date)" | tee "$SUMMARY"
failed_steps=()

step() {   # step <name> <env assignments...> -- <command...>
  local name="$1"; shift
  local envs=()
  while [ "$1" != "--" ]; do envs+=("$1"); shift; done; shift
  local out="$STATUS_DIR/selfnull_${SIDE}_${name}.out"
  echo "---- [$(date '+%F %T')] START $name" | tee -a "$SUMMARY"
  env "${envs[@]}" "$@" > "$out" 2>&1
  local rc=$?
  if [ $rc -eq 0 ]; then
    echo "---- [$(date '+%F %T')] DONE  $name" | tee -a "$SUMMARY"
  else
    echo "---- [$(date '+%F %T')] FAILED $name (exit $rc; see $out)" | tee -a "$SUMMARY"
    failed_steps+=("$name")
  fi
}

# FORCE_RERUN=0 keeps runs resumable; SEED_BASE=0 is the self-null seeding convention.
COMMON=(LEADER_SIDES=$SIDE MAX_PARALLEL=$MAX_PARALLEL R_N_CHAINS=4 R_N_ADAPT=1000 FORCE_RERUN=0 SEED_BASE=0)
SHORT=(R_N_ITER=1000 R_BURN_IN=300)

step 1_selfnull          "${COMMON[@]}" "${SHORT[@]}" EFORENSICS_WFORM=conditional EFORENSICS_CONV=mcmcse OUT_SUFFIX=_v2 \
     -- ./run_mebane_self_null_parallel.sh
step 2_tau_selfnull      "${COMMON[@]}" "${SHORT[@]}" EFORENSICS_WFORM=tau EFORENSICS_CONV=mcmcse OUT_SUFFIX=_v2_tau \
     -- ./run_mebane_self_null_parallel.sh

echo "run_selfnull_${SIDE}: finished $(date)" | tee -a "$SUMMARY"
if [ ${#failed_steps[@]} -gt 0 ]; then
  echo "FAILED steps: ${failed_steps[*]} -- inspect $STATUS_DIR/selfnull_${SIDE}_<step>.out, then rerun this script (completed cells are skipped)." | tee -a "$SUMMARY"
  exit 1
fi
echo "Both conservative-coded self-null steps completed (collect with parse_selfnull_logs.py; see README)." | tee -a "$SUMMARY"
