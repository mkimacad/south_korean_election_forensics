"""Main-text table of Klimek et al. (2018)-procedure fraud shares f_i+f_e,
winner-coded, both unit levels, from klimek_2018_output/klimek_2018_all_results.csv."""
import pandas as pd
import klimek_units as KU

d = pd.read_csv('klimek_2018_output/klimek_2018_all_results.csv', dtype={'elec': str})
w = d[d.apply(lambda r: r.leader_side == KU.WINNER[r.elec], axis=1)]
w.to_csv('klimek_2018_output/klimek_2018_winner_results.csv', index=False)
LEVELS = KU.complete_levels(d, KU.MAIN_PER_LEVEL)
HEAD = {'dong': 'Dong', 'tpg': 'Polling district'}


def cell(level, resid, src, e):
    r = w[(w.elec == e) & (w.level == level) & (w.residualized == resid) & (w.source == src)].iloc[0]
    return f"{100 * r.fraud_share:.0f}$\\pm${100 * r.fraud_share_sd:.0f}"


k = len(LEVELS)
lines = [r"\begin{tabular}{ll" + " cccc" * k + "}", r"\toprule"]
if k > 1:
    lines += [" & & " + " & ".join(rf"\multicolumn{{4}}{{c}}{{{HEAD[lv]}}}" for lv in LEVELS) + r" \\",
              "".join(rf"\cmidrule(lr){{{3 + 4*i}-{6 + 4*i}}}" for i in range(k))]
lines += [" & & " + " & ".join([r"\multicolumn{2}{c}{Raw} & \multicolumn{2}{c}{Prov.-adjusted}"] * k) + r" \\",
          "".join(rf"\cmidrule(lr){{{3 + 2*i}-{4 + 2*i}}}" for i in range(2 * k)),
          r"Election & Winner & " + " & ".join(["Real & Null"] * 2 * k) + r" \\", r"\midrule"]
for e in KU.PREEARLY:
    cells = [cell(lv, rs, src, e) for lv in LEVELS for rs in (False, True) for src in ('real', 'joint_null')]
    lines.append(f"{KU.LABEL[e]} & {'Dem.' if KU.WINNER[e] == 'dem' else 'Con.'} & " + " & ".join(cells) + r" \\")
n = w[w.level.isin(LEVELS)].groupby('level').n.agg(['min', 'max'])
lines += [r"\midrule", "Units & & " + " & ".join(
    rf"\multicolumn{{4}}{{c}}{{{n.loc[lv, 'min']:,}--{n.loc[lv, 'max']:,}}}" for lv in LEVELS) + r" \\",
    r"\bottomrule", r"\end{tabular}"]
open('klimek_2018_output/klimek_winner_table.tex', 'w').write("\n".join(lines) + "\n")
print("wrote klimek_2018_output/klimek_winner_table.tex and klimek_2018_winner_results.csv")
