"""Appendix tables for the Klimek et al. (2018)-procedure analysis:
  appendix_tables_klimek2018.tex       -- all 80 main-grid fits
  appendix_tables_klimek_compare.tex   -- three-way recovery-test comparison
"""
import pandas as pd
import klimek_units as KU

SHORT = {'pres16': 'Pres02', 'pres17': 'Pres07', '18': 'Gen08', '19': 'Gen12', 'pres18': 'Pres12'}
LV = {'dong': 'dong', 'tpg': 'p.\\ district'}


def longtable(colspec, header, rows, caption, label, ncol, tabcolsep=3):
    out = [r"{\footnotesize", rf"\setlength{{\tabcolsep}}{{{tabcolsep}pt}}",
           rf"\begin{{longtable}}{{{colspec}}}", rf"\caption{{{caption}}} \label{{{label}}} \\",
           r"\toprule", header, r"\midrule", r"\endfirsthead",
           rf"\multicolumn{{{ncol}}}{{c}}{{\tablename\ \thetable{{}} -- continued}} \\",
           r"\toprule", header, r"\midrule", r"\endhead", r"\bottomrule", r"\endfoot"]
    out += [" & ".join(r) + r" \\" for r in rows]
    out += [r"\end{longtable}", "}"]
    return "\n".join(out) + "\n"


d = pd.read_csv('klimek_2018_output/klimek_2018_all_results.csv', dtype={'elec': str})
LEVELS = KU.complete_levels(d, KU.MAIN_PER_LEVEL)
d = d[d.level.isin(LEVELS)]
d['eo'] = d.elec.map({e: i for i, e in enumerate(KU.PREEARLY)})
d['lo'] = d.level.map({'dong': 0, 'tpg': 1})
d['so'] = d.source.map({'real': 0, 'joint_null': 1})
d = d.sort_values(['lo', 'eo', 'leader_side', 'residualized', 'so'], ascending=[True, True, False, True, True])
rows = [[LV[r.level], SHORT[r.elec], 'Dem.' if r.leader_side == 'dem' else 'Con.',
         'resid.' if r.residualized else 'raw', 'real' if r.source == 'real' else 'joint null', f"{r.n:,}",
         f"{100*r.fi:.1f}", f"{100*r.fi_sd:.1f}", f"{100*r.fe:.2f}", f"{100*r.fe_sd:.2f}",
         f"{r.alpha:.2f}", f"{r.alpha_sd:.2f}"] for r in d.itertuples()]
header = (r"Level & Elec. & Leader & Fingerpr. & Source & $n$ & $f_i$ \% & SD & $f_e$ \% & SD & "
          r"$\alpha$ & SD \\")
LVTXT = {('dong',): 'dong level', ('tpg',): 'polling-district level', ('dong', 'tpg'): 'dong and polling-district levels'}[tuple(LEVELS)]
cap = (r"All \citet{klimek2018turkey}-procedure fits: the five elections held before early voting, at the "
       + LVTXT + r", both leader codings, raw and province-residualized fingerprints, real data "
       r"and the joint null. Each entry is the mean, with the standard deviation beside it, across 200 sweeps.")
open('appendix_tables_klimek2018.tex', 'w').write(
    longtable(r"llllllrrrrrr", header, rows, cap, 'tab:app_klimek2018', 12))
print("klimek2018 rows:", len(rows))

a = pd.read_csv('klimek_output/klimek_recovery_results.csv')
b = pd.read_csv('klimek_original_output/klimek_original_recovery_results.csv')
c = pd.read_csv('klimek_original_output/klimek_2018_recovery_results.csv')
key = ['n', 'true_fi', 'true_fe']
m = c.merge(b, on=key, suffixes=('', '_12')).merge(a[key + ['fit_fi', 'fit_fe']].rename(
    columns={'fit_fi': 'ours_fi', 'fit_fe': 'ours_fe'}), on=key, how='left')
lines = [r"\begin{tabular}{r cc cc ccc ccc}", r"\toprule",
         r" & \multicolumn{2}{c}{True} & \multicolumn{2}{c}{Ours (joint fit)} & "
         r"\multicolumn{3}{c}{2018 procedure (2-D)} & \multicolumn{3}{c}{2012 procedure (1-D)} \\",
         r"\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-8}\cmidrule(lr){9-11}",
         r"$n$ & $f_i$ & $f_e$ & $f_i$ & $f_e$ & $f_i$ & $f_e$ & SD & $f_i$ & $f_e$ & SD \\", r"\midrule"]
for r in m.itertuples():
    ours = (f"{r.ours_fi:.3f} & {r.ours_fe:.3f}" if pd.notna(r.ours_fi) else "-- & --")
    lines.append(f"{int(r.n):,} & {r.true_fi:.2f} & {r.true_fe:.2f} & {ours} & "
                 f"{r.fit_fi:.3f} & {r.fit_fe:.3f} & {r.fit_fi_sd:.3f} & "
                 f"{r.fit_fi_12:.3f} & {r.fit_fe_12:.3f} & {r.fit_fi_sd_12:.3f} \\\\")
lines += [r"\bottomrule", r"\end{tabular}"]
open('appendix_tables_klimek_compare.tex', 'w').write("\n".join(lines) + "\n")
print("comparison rows:", len(m))
