#!/usr/bin/env python3
"""
collect_eforensics_results.py

Rebuilds the aggregated result CSVs that the appendix-table and figure scripts
read, directly from the per-cell eforensics logs (real data, marginal null and
joint null; the self-null has its own collector, parse_selfnull_logs.py, and the
PSRF check has parse_psrf_logs.py):

  appendix_full_results.csv        fraud share, F_w, flags, R-hat, elapsed
  appendix_components_results.csv  pi_1, pi_2, pi_3 medians and 95% HPDs
  appendix_mebane_md_results.csv   Mebane (2023) M(pi_j), D(pi_j) and flag

The 'dataset' column follows the existing convention:
  new_settings       short-chain configuration (n.iter=1000, burn-in=300)
  previous_settings  long-chain configuration  (n.iter=5000, burn-in=1000)

FRAUDULENT-VOTE COUNTS. By default only logs that declare
'fraud_votes_definition : model' are accepted, i.e. logs written by the current
mebane_crosscheck.R, whose F_t/F_w are the model-consistent counts
N*[f.m*(1-tau) + f.s*tau*(1-nu)] with exact joint 95% HPD intervals. Older logs
report the package convention (rates x N) and are rejected, so the two can
never be mixed in one table. --allow-package-fw overrides this (not for use in
the manuscript).

Usage:
  python3 collect_eforensics_results.py \
      --short output_data_v2/mebane_r_all_logs output_data_v2/con_leader \
      --long  output_data_v2_long/mebane_r_all_logs output_data_v2_long/con_leader
"""
import argparse
import glob
import os
import re
import sys

import pandas as pd

NUM = r"([0-9.eE+-]+|nan|NaN)"
RESULT_RE = re.compile(r"^RESULT:\s*([^/]+)/([^/]+)/([^/]+)/([^/]+)/leader=(\w+)\s*$", re.M)
CI_RE = {k: re.compile(rf"^{k}_median\s*:\s*{NUM}(?:\s*\[\s*{NUM}\s*,\s*{NUM}\s*\])?", re.M)
         for k in ('p_no_fraud', 'p_incremental', 'p_extreme')}
FS_RE = re.compile(rf"^fraud_share_median\s*:\s*{NUM}", re.M)
FS_CONS_RE = re.compile(rf"^fraud_share_cons95\s*:\s*\[\s*{NUM}\s*,\s*{NUM}\s*\]", re.M)
FS_HPD_RE = re.compile(rf"^fraud_share_hpd95\s*:\s*\[\s*{NUM}\s*,\s*{NUM}\s*\]", re.M)
FW_RE = re.compile(rf"^Fw_total \(total fraud\)\s*:\s*{NUM}(?:\s*\[\s*{NUM}\s*,\s*{NUM}\s*\])?", re.M)
FWDEF_RE = re.compile(r"^fraud_votes_definition\s*:\s*(\w+)", re.M)
FWPKG_RE = re.compile(rf"^Fw_pkg_total \(package\)\s*:\s*{NUM}", re.M)
FLAG_RE = re.compile(r"^n_regions_flagged\s*:\s*(\d+)/(\d+)", re.M)
RHAT_RE = re.compile(rf"^rhat_pi\s*:\s*{NUM}", re.M)
M_RE = re.compile(rf"^M\(pi_j\).*?:\s*{NUM}/{NUM}/{NUM}", re.M)
D_RE = re.compile(rf"^D\(pi_j\).*?:\s*{NUM}/{NUM}/{NUM}", re.M)
EL_RE = re.compile(rf"^elapsed_seconds\s*:\s*{NUM}", re.M)
MAIN_SOURCES = ('real', 'marginal_null', 'joint_null')


def f(x):
    return float(x) if x is not None else float('nan')


def parse(path, dataset):
    t = open(path, errors='replace').read()
    m = RESULT_RE.search(t)
    if not m or m.group(4) not in MAIN_SOURCES:
        return None
    r = dict(dataset=dataset, elec=m.group(1), level=m.group(2), channel=m.group(3), source=m.group(4),
             leader_side=m.group(5), log=os.path.basename(path))
    for k, rx in CI_RE.items():
        g = rx.search(t)
        r[k], r[k + '_lo'], r[k + '_hi'] = (f(g.group(1)), f(g.group(2)), f(g.group(3))) if g else (float('nan'),) * 3
    g = FS_RE.search(t); r['fraud_share'] = f(g.group(1)) if g else float('nan')
    g = FS_CONS_RE.search(t); r['fraud_share_lo'], r['fraud_share_hi'] = (f(g.group(1)), f(g.group(2))) if g else (float('nan'),) * 2
    g = FS_HPD_RE.search(t); r['fraud_share_hpd_lo'], r['fraud_share_hpd_hi'] = (f(g.group(1)), f(g.group(2))) if g else (float('nan'),) * 2
    g = FW_RE.search(t); r['Fw'], r['Fw_lo'], r['Fw_hi'] = (f(g.group(1)), f(g.group(2)), f(g.group(3))) if g else (float('nan'),) * 3
    g = FWDEF_RE.search(t); r['fraud_votes_definition'] = g.group(1) if g else 'package'
    g = FWPKG_RE.search(t); r['Fw_pkg'] = f(g.group(1)) if g else float('nan')
    g = FLAG_RE.search(t); r['n_flagged'], r['n_units'] = (int(g.group(1)), int(g.group(2))) if g else (None, None)
    g = RHAT_RE.search(t); r['rhat'] = f(g.group(1)) if g else float('nan')
    for rx, key in ((M_RE, 'M'), (D_RE, 'D')):
        g = rx.search(t)
        for j in range(3):
            r[f'{key}{j + 1}'] = f(g.group(j + 1)) if g else float('nan')
    g = EL_RE.search(t); r['elapsed'] = f(g.group(1)) if g else float('nan')
    return r


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--short', nargs='*', default=[], help="log dirs, short-chain runs (dataset new_settings)")
    ap.add_argument('--long', nargs='*', default=[], help="log dirs, long-chain runs (dataset previous_settings)")
    ap.add_argument('--allow-package-fw', action='store_true')
    ap.add_argument('--outdir', default='.')
    a = ap.parse_args()
    rows, skipped = [], 0
    for dataset, dirs in (('previous_settings', a.long), ('new_settings', a.short)):
        for d in dirs:
            if not os.path.isdir(d):
                sys.exit(f"ERROR: no such directory {d}")
            for p in sorted(glob.glob(os.path.join(d, '*.log'))):
                r = parse(p, dataset)
                if r is None:
                    skipped += 1
                else:
                    rows.append(r)
    if not rows:
        sys.exit("ERROR: no completed real/marginal/joint runs found")
    df = pd.DataFrame(rows)
    old = df[df.fraud_votes_definition != 'model']
    if len(old) and not a.allow_package_fw:
        sys.exit(f"ERROR: {len(old)} log(s) report fraudulent votes in the package convention (rates x N), "
                 f"e.g. {old.log.iloc[0]}. Rerun them with the current mebane_crosscheck.R, or pass "
                 f"--allow-package-fw (not for the manuscript).")
    key = ['dataset', 'leader_side', 'elec', 'level', 'channel', 'source']
    dup = df[df.duplicated(key, keep=False)]
    if len(dup):
        sys.exit(f"ERROR: duplicate cells across the given directories, e.g. {dup[key].iloc[0].tolist()}")
    df['not_converged'] = df.rhat > 1.05
    df = df.sort_values(key)
    full = df[key + ['n_units', 'fraud_share', 'fraud_share_lo', 'fraud_share_hi', 'Fw', 'Fw_lo', 'Fw_hi',
                     'n_flagged', 'rhat', 'not_converged', 'elapsed', 'fraud_share_hpd_lo', 'fraud_share_hpd_hi',
                     'Fw_pkg', 'fraud_votes_definition']]
    comp = df[key + ['n_units']].assign(
        p_no_fraud=df.p_no_fraud, p_nf_lo=df.p_no_fraud_lo, p_nf_hi=df.p_no_fraud_hi,
        p_incr=df.p_incremental, p_incr_lo=df.p_incremental_lo, p_incr_hi=df.p_incremental_hi,
        p_ext=df.p_extreme, p_ext_lo=df.p_extreme_lo, p_ext_hi=df.p_extreme_hi,
        rhat=df.rhat, not_converged=df.not_converged)
    Ms, Ds = df[['M1', 'M2', 'M3']].values, df[['D1', 'D2', 'D3']].values
    md = df[key + ['n_units', 'M1', 'M2', 'M3', 'D1', 'D2', 'D3']].assign(
        mebane_flag=((Ms > 0.01) & (Ds < 0.05)).any(axis=1), rhat=df.rhat, not_converged=df.not_converged)
    for name, t in (('appendix_full_results.csv', full), ('appendix_components_results.csv', comp),
                    ('appendix_mebane_md_results.csv', md)):
        t.to_csv(os.path.join(a.outdir, name), index=False)
    counts = df.groupby(['dataset', 'leader_side']).size().to_dict()
    print(f"wrote appendix_full_results.csv, appendix_components_results.csv, appendix_mebane_md_results.csv: "
          f"{len(df)} runs {counts}; {skipped} log(s) skipped (self-null, unfinished or other)")


if __name__ == '__main__':
    main()
