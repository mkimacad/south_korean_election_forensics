#!/usr/bin/env bash
# ============================================================================
# run_all_eforensics_dem.sh
#
# Every eforensics run in the paper with the DEMOCRATIC-coded leader:
#   1. short-chain configuration   real / marginal null / joint null   -> output_data_v2/mebane_r_all_logs
#   2. model-consistent self-null (conditional form)                    -> output_data_v2/mebane_r_all_logs
#   3. latent-turnout (tau) form   real / marginal null / joint null   -> output_data_v2_tau/mebane_r_all_logs
#   4. latent-turnout (tau) form   model-consistent self-null          -> output_data_v2_tau/mebane_r_all_logs
#   5. PSRF stopping-rule check    (constituency level)                -> output_data_v2_psrf/mebane_r_all_logs
#   6. long-chain configuration    real / marginal null / joint null   -> output_data_v2_long/mebane_r_all_logs
# (The long-chain step comes last because it takes longest.)
#
# All output goes to NEW output_data_v2* directories, so earlier results are
# never overwritten or reused. Every setting is fixed explicitly per step
# (likelihood form, stopping rule, chain lengths), whatever is in the calling
# environment. MAX_PARALLEL=8 cells run at a time within each step.
#
# RESUMABLE: each launcher skips cells whose log already exists and is
# non-empty, so if this script is interrupted, rerun it and it continues.
# A failed step is recorded and the remaining steps still run.
#
# Do NOT edit any .R/.py/.sh file in this directory while this is running:
# Rscript reads scripts as it executes them, and a file changed mid-run makes
# running jobs fail with parse errors.
#
# Usage (from the code directory):   nohup ./run_all_eforensics_dem.sh > run_all_dem.out 2>&1 &
# ============================================================================
set -u
cd "$(dirname "$0")"

MAX_PARALLEL=8
SIDE=dem
STATUS_DIR="run_all_status"
mkdir -p "$STATUS_DIR"
SUMMARY="$STATUS_DIR/run_all_${SIDE}.summary"

# ---- preflight: refuse to start with code that predates the current fixes ----
fail=0
need() { grep -q "$2" "$1" 2>/dev/null || { echo "PREFLIGHT FAIL: $1 lacks '$2' ($3)"; fail=1; }; }
for f in run_mebane_r_all_parallel_bidirectional.sh run_mebane_self_null_parallel.sh run_psrf_constituency.sh \
         mebane_r_driver_bidirectional.py mebane_self_null_driver.py mebane_crosscheck.R \
         mebane_crosscheck_selfnull_fit.R ef_qbl_tau.R; do
  [ -f "$f" ] || { echo "PREFLIGHT FAIL: missing $f"; fail=1; }
done
need mebane_crosscheck.R 'fraud_votes_definition = "model"' "model-consistent fraudulent-vote counts"
need mebane_crosscheck.R '"mu.tau", "mu.nu"' "monitors latent turnout and leader share"
need mebane_crosscheck_selfnull_fit.R '"mu.tau", "mu.nu"' "self-null stage 1 monitors"
need mebane_self_null_driver.py 'redrawn jointly' "self-null feasibility redraw"
need mebane_r_driver_bidirectional.py 'fraud_votes_definition' "driver prints the F definition"
command -v Rscript >/dev/null || { echo "PREFLIGHT FAIL: Rscript not found"; fail=1; }
[ "$fail" = 0 ] || { echo "Aborting: fix the problems above first."; exit 1; }

echo "run_all_eforensics_${SIDE}: started $(date)" | tee "$SUMMARY"
failed_steps=()

step() {   # step <name> <env assignments...> -- <command...>
  local name="$1"; shift
  local envs=()
  while [ "$1" != "--" ]; do envs+=("$1"); shift; done; shift
  local out="$STATUS_DIR/${SIDE}_${name}.out"
  echo "---- [$(date '+%F %T')] START $name" | tee -a "$SUMMARY"
  env "${envs[@]}" "$@" > "$out" 2>&1
  local rc=$?
  if [ $rc -eq 0 ]; then
    echo "---- [$(date '+%F %T')] DONE  $name" | tee -a "$SUMMARY"
  else
    echo "---- [$(date '+%F %T')] FAILED $name (exit $rc; see $out)" | tee -a "$SUMMARY"
    failed_steps+=("$name")
  fi
}

# FORCE_RERUN=0 keeps runs resumable; SEED_BASE=0 is the self-null seeding convention.
COMMON=(LEADER_SIDES=$SIDE MAX_PARALLEL=$MAX_PARALLEL R_N_CHAINS=4 R_N_ADAPT=1000 FORCE_RERUN=0 SEED_BASE=0)
SHORT=(R_N_ITER=1000 R_BURN_IN=300)
LONG=(R_N_ITER=5000 R_BURN_IN=1000)

step 1_short_main        "${COMMON[@]}" "${SHORT[@]}" EFORENSICS_WFORM=conditional EFORENSICS_CONV=mcmcse OUT_SUFFIX=_v2 \
     -- ./run_mebane_r_all_parallel_bidirectional.sh
step 2_selfnull          "${COMMON[@]}" "${SHORT[@]}" EFORENSICS_WFORM=conditional EFORENSICS_CONV=mcmcse OUT_SUFFIX=_v2 \
     -- ./run_mebane_self_null_parallel.sh
step 3_tau_main          "${COMMON[@]}" "${SHORT[@]}" EFORENSICS_WFORM=tau EFORENSICS_CONV=mcmcse OUT_SUFFIX=_v2_tau \
     -- ./run_mebane_r_all_parallel_bidirectional.sh
step 4_tau_selfnull      "${COMMON[@]}" "${SHORT[@]}" EFORENSICS_WFORM=tau EFORENSICS_CONV=mcmcse OUT_SUFFIX=_v2_tau \
     -- ./run_mebane_self_null_parallel.sh
step 5_psrf_constituency "${COMMON[@]}" "${SHORT[@]}" EFORENSICS_WFORM=conditional OUT_SUFFIX=_v2_psrf MAX_AUTO=10 \
     -- ./run_psrf_constituency.sh
step 6_long_main         "${COMMON[@]}" "${LONG[@]}" EFORENSICS_WFORM=conditional EFORENSICS_CONV=mcmcse OUT_SUFFIX=_v2_long \
     -- ./run_mebane_r_all_parallel_bidirectional.sh

echo "run_all_eforensics_${SIDE}: finished $(date)" | tee -a "$SUMMARY"
if [ ${#failed_steps[@]} -gt 0 ]; then
  echo "FAILED steps: ${failed_steps[*]} -- inspect $STATUS_DIR/${SIDE}_<step>.out, then rerun this script (completed cells are skipped)." | tee -a "$SUMMARY"
  exit 1
fi
echo "All steps completed. When run_all_eforensics_con.sh has also finished, collect the results (see README, 'Rebuilding all results')." | tee -a "$SUMMARY"
