"""Every number the manuscript's Klimek section cites, computed from
klimek_2018_output/*.csv. Writes klimek_2018_output/klimek_2018_stats.txt."""
import numpy as np
import pandas as pd
import klimek_units as KU

d = pd.read_csv('klimek_2018_output/klimek_2018_all_results.csv', dtype={'elec': str})
x = pd.read_csv('klimek_2018_output/klimek_2018_exclusion_results.csv', dtype={'elec': str})
LV = KU.complete_levels(d, KU.MAIN_PER_LEVEL)
d = d[d.level.isin(LV)]
x = x[x.level.isin(KU.complete_levels(x, KU.EXCL_PER_LEVEL))]
out = []
P = lambda s: out.append(s)

P(f"fits: {len(d)} main, {len(x)} exclusion; n_real={sorted(d.n_real.unique())}, bins={sorted(d.bins.unique())}")
for lv in LV:
    s = d[d.level == lv]
    P(f"[{lv}] n units {s.n.min()}-{s.n.max()}")
P(f"max f_e overall: {100*d.fe.max():.2f}% ({d.loc[d.fe.idxmax(), ['elec','level','leader_side','residualized','source']].tolist()})")
for lv in LV + (['both'] if len(LV) > 1 else []):
    s = d if lv == 'both' else d[d.level == lv]
    for resid in (False, True):
        q = s[s.residualized == resid]
        idx = ['elec', 'level', 'leader_side']
        j = pd.concat([q[q.source == 'real'].set_index(idx).fraud_share, q[q.source == 'joint_null'].set_index(idx).fraud_share],
                      axis=1, keys=['real', 'null']).dropna()
        wj = j[[KU.WINNER[e] == sd for e, _, sd in j.index]]
        P(f"[{lv} {'resid' if resid else 'raw'}] r(real,null) both codings={j.real.corr(j.null):.2f} (n={len(j)}); "
          f"winner-coded r={wj.real.corr(wj.null):.2f} (n={len(wj)}); "
          f"winner real<5%: {(wj.real<.05).sum()}/{len(wj)}, null<5%: {(wj.null<.05).sum()}/{len(wj)}; "
          f"all-coding real<5%: {(j.real<.05).sum()}/{len(j)}, null<5%: {(j.null<.05).sum()}/{len(j)}; "
          f"null>=real: {(j.null>=j.real).sum()}/{len(j)}; "
          f"median |real-null| {100*np.median(abs(j.real-j.null)):.1f}pp")
w = d[d.apply(lambda r: r.leader_side == KU.WINNER[r.elec], axis=1)]
for lv in LV + (['both'] if len(LV) > 1 else []):
    s = w if lv == 'both' else w[w.level == lv]
    P(f"[{lv}] winner-table SDs: median {100*s.fraud_share_sd.median():.1f}pp; share >5pp {100*(s.fraud_share_sd>.05).mean():.0f}% "
      f"({(s.fraud_share_sd>.05).sum()}/{len(s)})")
# dong vs polling-district agreement for the same cell
if len(LV) > 1:
    k = ['elec', 'leader_side', 'residualized', 'source']
    dd = d[d.level == 'dong'].set_index(k).fraud_share
    tt = d[d.level == 'tpg'].set_index(k).fraud_share
    j = pd.concat([dd, tt], axis=1, keys=['dong', 'tpg']).dropna()
    for resid in (False, True):
        q = j.xs(resid, level='residualized')
        P(f"[{'resid' if resid else 'raw'}] dong vs tpg same cell: r={q.dong.corr(q.tpg):.2f}, median |diff| {100*np.median(abs(q.dong-q.tpg)):.1f}pp, "
          f"max |diff| {100*abs(q.dong-q.tpg).max():.1f}pp")
P("winner-coded raw real f_i by level and exclusion (mean, sd):")
m = w[(w.source == 'real') & (~w.residualized)].assign(variant='all')
e_all = pd.concat([m, x])
for lv in [l for l in LV if (x.level == l).any()]:
    for e in KU.PREEARLY:
        rows = e_all[(e_all.level == lv) & (e_all.elec == e)].set_index('variant')
        P(f"  {lv:4s} {KU.LABEL[e]:10s} " + "  ".join(f"{v}={100*rows.loc[v,'fi']:.0f}±{100*rows.loc[v,'fi_sd']:.0f}"
                                               for v in ['all', 'noH', 'noHY', 'noHTK']))
open('klimek_2018_output/klimek_2018_stats.txt', 'w').write("\n".join(out) + "\n")
print("\n".join(out))
