#!/usr/bin/env python3
"""
parse_mebane_logs.py

Parses the per-cell .log files written by run_mebane_r_all_parallel_bidirectional.sh
(one log per election/level/channel/source/leader_side cell, each containing a
RESULT: block from mebane_crosscheck.R) into a single flat CSV with one row per
cell: elec, level, channel, source, leader_side, fraud_share, rhat, converged,
n_regions_flagged, n_regions_total, elapsed_seconds.

Elections are split into two eras (see NO_EARLY_VOTING_ELECTIONS, sourced from
the 'no_early_voting' flag in mebane_r_driver_bidirectional.py's ELECTIONS
config): five pre-2014 elections that only ever had a 'total_no_early' channel,
and all later elections, which use the early-voting-era channel set (early,
early_out, early_total, pooled, sameday, total) instead. Any 'total_no_early'
log for a later election is a bonus/inapplicable cell -- occasionally produced
by ad hoc sweeps -- and is dropped by default; pass --keep-invalid-channels to
disable this.

Usage:
    python3 parse_mebane_logs.py <logs_dir> <output.csv> [--leader-side dem|con]

<logs_dir> should be an output_data/mebane_r_all_logs or output_data/con_leader
directory (or any directory of such .log files). If --leader-side is omitted,
it is inferred per-file from each log's own "RESULT: .../leader=dem|con" line.
"mebane_r_all_summary.txt" and any non-.log files are skipped automatically.
"""
import argparse
import glob
import os
import re
import sys

import pandas as pd

# Elections with 'no_early_voting': True in mebane_r_driver_bidirectional.py's
# ELECTIONS config -- the only ones for which a 'total_no_early' channel is
# valid. All other elections use the early-voting-era channel set instead.
NO_EARLY_VOTING_ELECTIONS = {"pres16", "pres17", "pres18", "18", "19"}

RESULT_RE = re.compile(
    r"^RESULT:\s*(?P<elec>[^/]+)/(?P<level>[^/]+)/(?P<channel>[^/]+)/(?P<source>[^/]+)/leader=(?P<leader_side>\w+)\s*$",
    re.MULTILINE,
)
FRAUD_SHARE_RE = re.compile(r"^fraud_share_median\s*:\s*([0-9.eE+-]+)", re.MULTILINE)
RHAT_RE = re.compile(r"^rhat_pi\s*:\s*([0-9.eE+-]+)", re.MULTILINE)
FLAGGED_RE = re.compile(r"^n_regions_flagged\s*:\s*(\d+)/(\d+)", re.MULTILINE)
ELAPSED_RE = re.compile(r"^elapsed_seconds\s*:\s*([0-9.eE+-]+)", re.MULTILINE)


def parse_log(path):
    with open(path, "r", errors="replace") as fh:
        text = fh.read()

    m = RESULT_RE.search(text)
    if not m:
        return None  # no RESULT: block -> cell never completed; skip

    fraud_share_m = FRAUD_SHARE_RE.search(text)
    rhat_m = RHAT_RE.search(text)
    flagged_m = FLAGGED_RE.search(text)
    elapsed_m = ELAPSED_RE.search(text)

    rhat = float(rhat_m.group(1)) if rhat_m else float("nan")

    row = {
        "elec": m.group("elec"),
        "level": m.group("level"),
        "channel": m.group("channel"),
        "source": m.group("source"),
        "leader_side": m.group("leader_side"),
        "fraud_share": float(fraud_share_m.group(1)) if fraud_share_m else float("nan"),
        "rhat": rhat,
        "converged": (rhat <= 1.05) if rhat_m else None,
        "n_regions_flagged": int(flagged_m.group(1)) if flagged_m else None,
        "n_regions_total": int(flagged_m.group(2)) if flagged_m else None,
        "elapsed_seconds": float(elapsed_m.group(1)) if elapsed_m else float("nan"),
    }
    return row


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("logs_dir")
    ap.add_argument("output_csv")
    ap.add_argument("--leader-side", choices=["dem", "con"], default=None,
                     help="Override/validate the leader_side rather than trusting each "
                          "log's own RESULT: line.")
    ap.add_argument("--keep-invalid-channels", action="store_true",
                     help="Keep 'total_no_early' cells for elections that had early "
                          "voting (see NO_EARLY_VOTING_ELECTIONS). Off by default.")
    args = ap.parse_args()

    log_paths = sorted(glob.glob(os.path.join(args.logs_dir, "*.log")))
    if not log_paths:
        sys.exit(f"No .log files found in {args.logs_dir}")

    rows = []
    skipped = []
    for path in log_paths:
        row = parse_log(path)
        if row is None:
            skipped.append(path)
            continue
        if args.leader_side and row["leader_side"] != args.leader_side:
            sys.exit(f"{path}: leader_side in log ('{row['leader_side']}') does not match "
                      f"--leader-side ('{args.leader_side}')")
        rows.append(row)

    if skipped:
        print(f"[parse_mebane_logs] Skipped {len(skipped)} file(s) with no RESULT: block "
              f"(incomplete/failed runs):", file=sys.stderr)
        for p in skipped:
            print(f"  {p}", file=sys.stderr)

    df = pd.DataFrame(rows)

    if not args.keep_invalid_channels:
        invalid = (df["channel"] == "total_no_early") & (~df["elec"].isin(NO_EARLY_VOTING_ELECTIONS))
        n_invalid = int(invalid.sum())
        if n_invalid:
            print(f"[parse_mebane_logs] Dropping {n_invalid} 'total_no_early' cell(s) for "
                  f"election(s) with early voting (not a valid channel for them): "
                  f"{sorted(df.loc[invalid, 'elec'].unique())}", file=sys.stderr)
            df = df[~invalid]

    df = df.sort_values(["elec", "level", "channel", "source", "leader_side"]).reset_index(drop=True)
    df.to_csv(args.output_csv, index=False)
    print(f"[parse_mebane_logs] Wrote {len(df)} row(s) to {args.output_csv}")


if __name__ == "__main__":
    main()
