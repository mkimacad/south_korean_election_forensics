#!/usr/bin/env python3
"""
make_eforensics_stats.py

Every eforensics number the manuscript's Results section cites (short-chain
configuration), plus the rows of the main-text tables, from the collected CSVs:
  appendix_full_results.csv, appendix_selfnull_results.csv (collect_eforensics_results.py,
  parse_selfnull_logs.py). Writes eforensics_stats.txt and main-text table bodies
  maintext_table_nullfp.tex, maintext_table_selfnull.tex, maintext_table_preearly.tex,
  maintext_table_pres18bidir.tex.
"""
import numpy as np
import pandas as pd

LBL = {'pres16': '2002 pres.', 'pres17': '2007 pres.', 'pres18': '2012 pres.', 'pres19': '2017 pres.',
       'pres20': '2022 pres.', 'pres21': '2025 pres.', '18': '2008 gen.', '19': '2012 gen.', '20': '2016 gen.',
       '21': '2020 gen.', '22': '2024 gen.'}
CH = {'total_no_early': 'total-no-early', 'early_out': 'early-out', 'early_total': 'early-total'}
SRC = {'marginal_null': 'marginal', 'joint_null': 'joint', 'real': 'real'}
f = pd.read_csv('appendix_full_results.csv'); f['elec'] = f.elec.astype(str)
f = f[f.dataset == 'new_settings']
sn = pd.read_csv('appendix_selfnull_results.csv'); sn['elec'] = sn.elec.astype(str)
out = []
P = out.append
pct = lambda x: f"{100 * x:.1f}\\%"
votes = lambda x: f"{x:,.0f}".replace(',', '{,}')

# ---- false positives on the two nulls ----
nul = f[f.source != 'real']
P(f"[nulls] runs {len(nul)}; >5%: {int((nul.fraud_share > .05).sum())} ({100*(nul.fraud_share > .05).mean():.1f}%); "
  f">15%: {int((nul.fraud_share > .15).sum())}; median {100*nul.fraud_share.median():.1f}%")
for side in ('dem', 'con'):
    q = nul[nul.leader_side == side]
    P(f"   [{side}] runs {len(q)}; >5%: {int((q.fraud_share > .05).sum())} ({100*(q.fraud_share > .05).mean():.1f}%)")
top = nul.loc[nul.fraud_share.idxmax()]
P(f"[nulls] max {100*top.fraud_share:.1f}% HPD [{100*top.fraud_share_hpd_lo:.1f}, {100*top.fraud_share_hpd_hi:.1f}] "
  f"Fw {top.Fw:,.0f} [{top.Fw_lo:,.0f}, {top.Fw_hi:,.0f}] ({top.elec} {top.level} {top.channel} {top.source} {top.leader_side}; "
  f"flagged {top.n_flagged}/{top.n_units})")
P(f"[nulls] runs whose HPD lower bound exceeds 5%: {int((nul.fraud_share_hpd_lo > .05).sum())}; exceeds 0: "
  f"{int((nul.fraud_share_hpd_lo > 0.001).sum())} (>0.1%)")
# Table: six largest Dem-coded null runs
t = nul[nul.leader_side == 'dem'].sort_values('fraud_share', ascending=False).head(6)
rows = [f"{LBL[r.elec]}, {r.level}, {CH.get(r.channel, r.channel)}, {SRC[r.source]} & {pct(r.fraud_share)} & "
        f"{votes(r.Fw)} & {r.n_flagged}/{r.n_units} \\\\" for r in t.itertuples()]
open('maintext_table_nullfp.tex', 'w').write("\n".join(rows) + "\n")
P("[table nullfp] " + " | ".join(f"{r.elec}/{r.level}/{r.channel}/{r.source} {100*r.fraud_share:.1f}% Fw={r.Fw:,.0f} fl={r.n_flagged}/{r.n_units}" for r in t.itertuples()))
few = nul[(nul.fraud_share > .15) & (nul.n_flagged <= 5)]
P("[few flags, large share] " + "; ".join(f"{r.elec}/{r.level}/{r.channel}/{r.source}/{r.leader_side} {100*r.fraud_share:.1f}% fl={r.n_flagged}/{r.n_units}" for r in few.itertuples()))

# ---- real vs null correlation ----
idx = ['elec', 'level', 'channel']
for side in ('dem', 'con', 'both'):
    q = f if side == 'both' else f[f.leader_side == side]
    k = idx + (['leader_side'] if side == 'both' else [])
    pv = q.pivot_table(index=k, columns='source', values='fraud_share').dropna()
    P(f"[real vs null {side}] n={len(pv)} r(marginal)={pv.real.corr(pv.marginal_null):.3f} r(joint)={pv.real.corr(pv.joint_null):.3f}; "
      f"joint>=real {int((pv.joint_null >= pv.real).sum())}; marginal>=real {int((pv.marginal_null >= pv.real).sum())}")

# ---- convergence ----
P(f"[convergence] not converged (max R-hat > 1.05): {100*f.not_converged.mean():.1f}% of {len(f)}; median max R-hat {f.rhat.median():.2f}")
for side in ('dem', 'con'):
    q = f[f.leader_side == side]
    P(f"   [{side}] not converged {100*q.not_converged.mean():.1f}%")

# ---- self-null (observed-turnout form) ----
sr = f[f.source == 'real'][idx + ['leader_side', 'fraud_share']]
for side in ('dem', 'con'):
    s = sn[sn.leader_side == side]; x = s.fraud_share
    j = s.merge(sr, on=idx + ['leader_side'], suffixes=('_sn', '_real'))
    P(f"[selfnull {side}] n={len(s)} median {100*x.median():.1f}% mean {100*x.mean():.1f}% >5%: {int((x > .05).sum())} "
      f"({100*(x > .05).mean():.1f}%) >15%: {int((x > .15).sum())} ({100*(x > .15).mean():.1f}%) max {100*x.max():.1f}% "
      f"({s.loc[x.idxmax(), 'elec']} {s.loc[x.idxmax(), 'level']} {s.loc[x.idxmax(), 'channel']}); "
      f"r(real)={j.fraud_share_real.corr(j.fraud_share_sn):.3f}; selfnull>=real {int((j.fraud_share_sn >= j.fraud_share_real).sum())}; "
      f"not converged {100*s.not_converged.mean():.0f}%; HPD lo>5% {int((s.fraud_share_hpd_lo > .05).sum())}")
rows = []
for side, lab in (('dem', 'Dem'), ('con', 'Con')):
    t = sn[sn.leader_side == side].sort_values('fraud_share', ascending=False).head(3)
    rows += [f"{lab} & {LBL[r.elec]}, {r.level}, {CH.get(r.channel, r.channel)} & {pct(r.fraud_share)} & {r.n_flagged}/{r.n_units} \\\\"
             for r in t.itertuples()]
open('maintext_table_selfnull.tex', 'w').write("\n".join(rows) + "\n")

# ---- pre-early-voting elections (real data) ----
pe = f[(f.channel == 'total_no_early') & (f.source == 'real')]
order = ['pres16', 'pres17', 'pres18', '18', '19']
rows = []
for e in order:
    for lvl in ('constituency', 'dong'):
        r = pe[(pe.elec == e) & (pe.level == lvl) & (pe.leader_side == 'dem')].iloc[0]
        nm = {'pres16': 'Pres.\\ 2002', 'pres17': 'Pres.\\ 2007', 'pres18': 'Pres.\\ 2012', '18': 'Gen.\\ 2008', '19': 'Gen.\\ 2012'}[e]
        rows.append(f"{nm} & {lvl.capitalize()} & {pct(r.fraud_share)} & {votes(r.Fw)} & {r.n_flagged}/{r.n_units} \\\\")
open('maintext_table_preearly.tex', 'w').write("\n".join(rows) + "\n")
for side in ('dem', 'con'):
    q = pe[(pe.leader_side == side) & pe.elec.str.startswith('pres')]
    P(f"[preearly pres {side}] fraud share {100*q.fraud_share.min():.1f}-{100*q.fraud_share.max():.1f}%; Fw {q.Fw.min():,.0f}-{q.Fw.max():,.0f}; "
      + "; ".join(f"{r.elec}/{r.level} {100*r.fraud_share:.1f}% Fw={r.Fw:,.0f}" for r in q.sort_values(['elec', 'level']).itertuples()))
    g = pe[(pe.leader_side == side) & ~pe.elec.str.startswith('pres')]
    P(f"[preearly gen {side}] fraud share {100*g.fraud_share.min():.1f}-{100*g.fraud_share.max():.1f}%")
# dong-level: are the largest real-data estimates in pre-early elections?
d = f[(f.level == 'dong') & (f.source == 'real') & (f.leader_side == 'dem')].sort_values('fraud_share', ascending=False)
P("[dong real dem top 5] " + "; ".join(f"{r.elec}/{r.channel} {100*r.fraud_share:.1f}%" for r in d.head(5).itertuples()))
d = f[(f.level == 'dong') & (f.source == 'real') & (f.leader_side == 'dem') & (f.channel == 'sameday')]
P(f"[dong sameday real dem] max {100*d.fraud_share.max():.1f}%")

# ---- 2012 presidential election, both codings ----
rows = []
for lvl in ('dong', 'constituency'):
    for side in ('dem', 'con'):
        for src in ('real', 'marginal_null', 'joint_null'):
            r = f[(f.elec == 'pres18') & (f.level == lvl) & (f.channel == 'total_no_early') & (f.leader_side == side) & (f.source == src)].iloc[0]
            v = pct(r.fraud_share)
            rows.append(f"{lvl.capitalize()} & {side.capitalize()} & {dict(real='Real', marginal_null='Marginal null', joint_null='Joint null')[src]} & "
                        f"{v} & {r.rhat:.2f} \\\\")
open('maintext_table_pres18bidir.tex', 'w').write("\n".join(rows) + "\n")
for lvl in ('dong', 'constituency'):
    q = f[(f.elec == 'pres18') & (f.level == lvl) & (f.channel == 'total_no_early') & (f.source == 'real')].set_index('leader_side')
    P(f"[pres2012 {lvl} real] dem {100*q.loc['dem', 'fraud_share']:.1f}% con {100*q.loc['con', 'fraud_share']:.1f}%")
pe_con = pe[pe.leader_side == 'con'].sort_values('fraud_share', ascending=False)
P("[preearly con top] " + "; ".join(f"{r.elec}/{r.level} {100*r.fraud_share:.1f}%" for r in pe_con.head(3).itertuples()))

open('eforensics_stats.txt', 'w').write("\n".join(out) + "\n")
print("\n".join(out))
