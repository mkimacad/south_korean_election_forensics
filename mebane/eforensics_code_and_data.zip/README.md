# eforensics: election forensics analysis (Korean elections)

This repository fits the Ferrari/Mebane `eforensics` quasi-binomial-logistic
("qbl") election-fraud model to Korean general and presidential election
results (2002-2025), across multiple vote channels, both real and
null-model data sources, and both leader codings (Democratic-lineage and
conservative-lineage). It also includes a self-null robustness check and an
independent, non-JAGS "election fingerprint" diagnostic (Klimek et al. 2012).

## Requirements

- A conda installation (e.g. [Miniforge](https://github.com/conda-forge/miniforge)
  or Miniconda). No other system packages, compilers, or admin rights are
  needed -- `setup_env.sh` provisions everything, including JAGS itself,
  through conda and pip.
- Linux or macOS. (Windows users: run these steps inside WSL.)

## 1. Installation

From the repository root:

```bash
/bin/bash setup_env.sh
```

This creates a conda environment named `eforensics` (from `environment.yml`)
containing:
- Python 3.11 + numpy/pandas/scipy/matplotlib
- R + JAGS + rjags + coda + diptest (all from conda-forge, including the
  JAGS binary itself)

and then installs the `eforensics` R package, which is distributed only on
GitHub (not CRAN/conda-forge), via `install_eforensics.R`. The script ends
by verifying that both the Python and R/JAGS stacks import/load correctly.

Re-running `setup_env.sh` later (e.g. after pulling updates) is safe: it
updates the existing environment in place rather than failing or
duplicating it.

To use a different environment name:

```bash
ENV_NAME=my_env_name /bin/bash setup_env.sh
```

### Troubleshooting: R package build failures

`eforensics` pulls in a fairly heavy chain of CRAN dependencies (`mcmcse`,
`ggExtra` -> `shiny` -> `httpuv`/`bslib`, plus `fftwtools`), several of which
need system libraries to compile from source: zlib, libxml2, libuv, FFTW,
and `pkg-config` to locate them. `environment.yml` already provides all of
these via conda-forge, and `install_eforensics.R` explicitly points
`pkg-config` at the conda environment's `lib/pkgconfig` directory (some
package-level conda activation hooks don't reliably propagate through
`conda run`), so a normal `setup_env.sh` run shouldn't hit this. If you see
`configure: error: pkg-config not found`, `fatal error: zlib.h`, `fatal
error: libxml/tree.h`, or `fatal error: uv.h` during the
`install_eforensics.R` step, re-run `/bin/bash setup_env.sh` to pick up the
current `environment.yml`, or add the missing package directly with
`conda install -n eforensics -c conda-forge <package>`.

Two warnings you may see and can ignore: (1) `installation of package
'xml2' had non-zero exit status` / the same for `roxygen2` -- both are
`Suggests`-only for `eforensics` (used for building documentation, not for
fitting models) and don't block the install; and (2) `install_eforensics.R`
installs `LCA` directly by URL rather than through the normal package
index -- `eforensics` declares `LCA` as an Import but its own
`cran-comments.md` confirms the code never actually calls it, and on some
CRAN mirrors it doesn't resolve through the lookup `remotes` normally uses.

## 2. Activate the environment

```bash
conda activate eforensics
```

If `conda activate` doesn't work in your shell (common on a fresh conda
install), either run `conda init bash` once and restart your shell, or
replace `conda activate eforensics` below with prefixing each command with
`conda run -n eforensics`.

## 3. Run the model sweeps

```bash
/bin/bash run_mebane_r_all_parallel_bidirectional.sh
/bin/bash run_mebane_self_null_parallel.sh
```

(`/bin/bash` is used explicitly because these two scripts are not marked
executable in this repository and rely on bash-specific job-control features
-- `wait -n` / `jobs -r -p` -- so they must be run with `bash`, not `sh`.)

- `run_mebane_r_all_parallel_bidirectional.sh` fits every
  election/level/channel/source/leader_side cell (real, marginal-null, and
  joint-null data) via `mebane_r_driver_bidirectional.py` /
  `mebane_crosscheck.R`.
- `run_mebane_self_null_parallel.sh` runs the model-consistent self-null
  check (fit to real data, then refit to a synthetic no-fraud dataset drawn
  from those fitted hyperparameters) via `mebane_self_null_driver.py` /
  `mebane_crosscheck_selfnull_fit.R`.

Both scripts are resumable (a cell with an existing non-empty log is
skipped) and run cells concurrently as separate OS processes. Useful
environment-variable overrides (see each script's header comments for the
full list):

```bash
# Quick smoke test on a single election/level instead of the full grid:
MAX_PARALLEL=2 LEADER_SIDES="con" /bin/bash run_mebane_r_all_parallel_bidirectional.sh "pres18" "dong"

# Force a full rerun, ignoring existing logs:
FORCE_RERUN=1 /bin/bash run_mebane_r_all_parallel_bidirectional.sh
```

Logs land in `output_data/mebane_r_all_logs/` (dem-coded leader) and
`output_data/con_leader/` (con-coded leader), with a combined
`*_summary.txt` written to each directory once a run completes.

## 4. Post-processing

Once results are available, the appendix tables can be regenerated from the
included aggregated result CSVs:

```bash
python3 make_appendix_table.py            # reads appendix_full_results.csv
python3 make_appendix_table_components.py # reads appendix_components_results.csv
python3 make_appendix_table_mebane_md.py  # reads appendix_mebane_md_results.csv
python3 make_appendix_table_selfnull.py   # reads appendix_selfnull_results.csv
```

`make_figures.py` reproduces the manuscript's figures from four already-parsed
result CSVs, included in this repository:

| File | Configuration | Leader coding | Rows |
|---|---|---|---|
| `eforensics_parsed_results_dem.csv` | long-chain (n.iter=5000, burn.in=1000, n.adapt=1000) | dem-coded | 174 |
| `parsed_con_results.csv` | long-chain | con-coded | 174 |
| `test_parsed_dem.csv` | short-chain (n.iter=1000, burn.in=300, n.adapt=1000) | dem-coded | 174 |
| `test_parsed_con.csv` | short-chain | con-coded | 174 |

Each row is one election/level/channel/source/leader_side cell. These were
built with `parse_mebane_logs.py`, which extracts the `RESULT:` block
(`fraud_share_median`, `rhat_pi`, convergence status, etc.) from every
per-cell `.log` file written by `run_mebane_r_all_parallel_bidirectional.sh`.
By default it also drops any `total_no_early` cell for an election that
actually had early voting (a channel that isn't valid for that election, and
occasionally produced by ad hoc sweeps) -- pass `--keep-invalid-channels` to
disable that. To regenerate the CSVs from a fresh sweep's logs:

```bash
python3 parse_mebane_logs.py output_data/mebane_r_all_logs eforensics_parsed_results_dem.csv --leader-side dem
python3 parse_mebane_logs.py output_data/con_leader        parsed_con_results.csv          --leader-side con
```

(run against a short-chain sweep's `output_data/` and save to
`test_parsed_dem.csv` / `test_parsed_con.csv` instead, to regenerate those
two.)

`klimek_fingerprint.py` runs the independent, non-JAGS "election
fingerprint" diagnostic for a single election/level/channel cell (no R/JAGS
dependency -- numpy/pandas/scipy/matplotlib only):

```bash
python3 klimek_fingerprint.py pres18 dong total_no_early dem
```

A sample run's output (CSV + density plot) is included in
`klimek_sample_output/`.

## Repository layout

- `environment.yml`, `install_eforensics.R`, `requirements-pip.txt`,
  `setup_env.sh` -- installation.
- `mebane_crosscheck.R`, `mebane_crosscheck_selfnull_fit.R` -- R/JAGS model
  fitting (`eforensics::eforensics()`, `model = "qbl"`).
- `mebane_r_driver_bidirectional.py`, `mebane_self_null_driver.py` -- Python
  data loaders/drivers that build the model's input tables and invoke the R
  scripts above.
- `run_mebane_r_all_parallel_bidirectional.sh`,
  `run_mebane_self_null_parallel.sh` -- parallel, resumable sweeps across
  the full election/level/channel/source/leader_side grid.
- `klimek_fingerprint.py` -- independent fingerprint diagnostic.
- `make_appendix_table*.py`, `make_figures.py` -- table/figure generation.
- `parse_mebane_logs.py` -- parses raw per-cell sweep logs into the flat
  result CSVs `make_figures.py` reads.
- `*_election_result.csv`, `*_presidential_election_result.csv` -- raw
  election data.
- `appendix_*_results.csv`, `self_null_results.csv`,
  `raw_5000_iter_parsed.csv`, `eforensics_parsed_results_dem.csv`,
  `parsed_con_results.csv`, `test_parsed_dem.csv`, `test_parsed_con.csv` --
  aggregated results.
