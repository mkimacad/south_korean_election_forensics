#!/usr/bin/env python3
"""
make_appendix_table_extra.py

Generates the appendix tables for the supplementary analyses:

  appendix_tables_psrf.tex            from psrf_constituency_results.csv
      every constituency run under the package's PSRF stopping rule
  appendix_tables_klimek.tex          from klimek_output/klimek_all_results.csv
      every Klimek-type fit (11 elections x 2 leader codings x raw/residualized
      fingerprints x real / marginal null / joint null)
  appendix_tables_klimek_recovery.tex from klimek_output/klimek_recovery_results.csv
      parameter-recovery test on data simulated from the Klimek model

Usage: python3 make_appendix_table_extra.py
"""
import numpy as np
import pandas as pd

ELEC_LABEL = {'pres16': 'Pres02', 'pres17': 'Pres07', '18': 'Gen08', '19': 'Gen12', 'pres18': 'Pres12',
              '20': 'Gen16', 'pres19': 'Pres17', '21': 'Gen20', 'pres20': 'Pres22', '22': 'Gen24', 'pres21': 'Pres25'}
ELEC_ORDER = ['pres16', 'pres17', '18', '19', 'pres18', '20', 'pres19', '21', 'pres20', '22', 'pres21']
SRC_LABEL = {'real': 'real', 'marginal_null': 'marg.null', 'joint_null': 'joint.null'}
SRC_ORDER = {'real': 0, 'marginal_null': 1, 'joint_null': 2}


def longtable(colspec, header, rows, caption, label, ncol, tabcolsep=3):
    out = [r"{\footnotesize", rf"\setlength{{\tabcolsep}}{{{tabcolsep}pt}}",
           rf"\begin{{longtable}}{{{colspec}}}", rf"\caption{{{caption}}} \label{{{label}}} \\",
           r"\toprule", header, r"\midrule", r"\endfirsthead",
           rf"\multicolumn{{{ncol}}}{{c}}{{\tablename\ \thetable{{}} -- continued}} \\",
           r"\toprule", header, r"\midrule", r"\endhead", r"\bottomrule", r"\endfoot"]
    out += [" & ".join(r) + r" \\" for r in rows]
    out += [r"\end{longtable}", "}"]
    return "\n".join(out) + "\n"


def order(df):
    df = df.copy()
    df['elec'] = df['elec'].astype(str)
    df['eo'] = df['elec'].map({e: i for i, e in enumerate(ELEC_ORDER)})
    df['so'] = df['source'].map(SRC_ORDER)
    return df


def psrf_table():
    d = order(pd.read_csv('psrf_constituency_results.csv'))
    d = d.sort_values(['leader_side', 'eo', 'channel', 'so'], ascending=[False, True, True, True])
    rows = []
    for _, r in d.iterrows():
        rows.append([ELEC_LABEL[r.elec], r.channel.replace('_', '-'), SRC_LABEL[r.source],
                     'Dem.' if r.leader_side == 'dem' else 'Con.', f"{int(r.n_extensions)}",
                     'yes' if r.pkg_converged else 'no', f"{r.final_psrf_max:.2f}", f"{r.rhat_kept:.2f}",
                     f"{100 * r.fraud_share:.2f}", f"{int(r.n_flagged)}/{int(r.n_units)}"])
    header = (r"Elec. & Channel & Source & Leader & Ext. & Met & Final PSRF & $\hat{R}$ (kept) & "
              r"Fraud \% & Flagged \\")
    cap = (r"Constituency-level runs under the package's PSRF stopping rule (Democratic-coded runs first, "
           r"then conservative-coded). ``Ext.'' is the number of chain extensions (at most 10); ``Met'' is "
           r"whether the rule, PSRF $<1.05$ for every mixture weight, was eventually met; ``Final PSRF'' is "
           r"the largest mixture-weight PSRF at the package's last check; $\hat{R}$ (kept) is our maximum "
           r"$\hat{R}$ over the mixture weights on the retained draws. The two differ slightly because the "
           r"package checks the draws before the final sampling block.")
    open('appendix_tables_psrf.tex', 'w').write(
        longtable(r"p{0.95cm}p{2.0cm}p{1.4cm}p{0.9cm}rcrrrr", header, rows, cap, 'tab:app_psrf', 10))
    return len(rows)


def pct_range(med, lo, hi):
    v = f"{100 * med:.1f}"
    return v if (hi - lo) < 0.02 else f"{v} [{100 * lo:.0f}, {100 * hi:.0f}]"


def klimek_table():
    d = order(pd.read_csv('klimek_output/klimek_all_results.csv'))
    d = d.sort_values(['eo', 'leader_side', 'residualized', 'so'], ascending=[True, False, True, True])
    rows = []
    for _, r in d.iterrows():
        rows.append([ELEC_LABEL[r.elec], 'Dem.' if r.leader_side == 'dem' else 'Con.',
                     'resid.' if r.residualized else 'raw', SRC_LABEL[r.source],
                     pct_range(r.fi, r.fi_min, r.fi_max), f"{100 * r.fe:.2f}",
                     f"{r.theta:.2f}", f"{r.alpha:.2f}", f"{r.sse_reduction:.2f}"])
    header = (r"Elec. & Leader & Fingerprint & Source & $f_i$ \% & $f_e$ \% & $\theta$ & $\alpha$ & "
              r"SSE red. \\")
    cap = (r"All Klimek-type fits: aggregate dong-level channel, eleven elections, both leader codings, raw "
           r"and province-residualized fingerprints, real data and both nulls. $f_i$ and $f_e$ are medians "
           r"across three simulation seeds; brackets give the minimum and maximum of $f_i$ across the seeds "
           r"when these differ by two or more percentage points. $\theta$ and $\alpha$ are from the fit with "
           r"the median fraud share. ``SSE red.'' is $1-\mathrm{SSE}_{\text{fit}}/\mathrm{SSE}_{\text{no fraud}}$, "
           r"the proportional improvement in fit from allowing fraud components.")
    open('appendix_tables_klimek.tex', 'w').write(
        longtable(r"p{0.95cm}p{0.9cm}p{1.5cm}p{1.4cm}p{2.1cm}rrrr", header, rows, cap, 'tab:app_klimek', 9))
    return len(rows)


def recovery_table():
    d = pd.read_csv('klimek_output/klimek_recovery_results.csv')
    lines = [r"\begin{tabular}{r cccc cccc c}", r"\toprule",
             r" & \multicolumn{4}{c}{True} & \multicolumn{4}{c}{Fitted} & \\",
             r"\cmidrule(lr){2-5}\cmidrule(lr){6-9}",
             r"$n$ & $f_i$ & $f_e$ & $\theta$ & $\alpha$ & $f_i$ & $f_e$ & $\theta$ & $\alpha$ & SSE red. \\",
             r"\midrule"]
    for _, r in d.iterrows():
        lines.append(f"{int(r.n):,} & {r.true_fi:.2f} & {r.true_fe:.2f} & {r.true_theta:.2f} & {r.true_alpha:.2f} & "
                     f"{r.fit_fi:.3f} & {r.fit_fe:.3f} & {r.fit_theta:.2f} & {r.fit_alpha:.2f} & "
                     f"{r.sse_reduction:.2f} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open('appendix_tables_klimek_recovery.tex', 'w').write("\n".join(lines) + "\n")
    return len(d)


if __name__ == '__main__':
    print("psrf rows:", psrf_table())
    print("klimek rows:", klimek_table())
    print("recovery rows:", recovery_table())
