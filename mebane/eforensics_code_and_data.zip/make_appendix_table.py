import os
import pandas as pd
import numpy as np

df = pd.read_csv('appendix_full_results.csv')
df['elec'] = df['elec'].astype(str)

# The manuscript reports the CONSERVATIVE interval for the fraud share -- the
# sum of the separate pi[2] and pi[3] HPD bounds -- throughout, so that is what
# these tables print. mebane_crosscheck.R additionally computes the exact joint
# HPD of pi[2]+pi[3] from the per-draw sum and writes it to the result CSV as
# fraud_share_hpd_lo/hi; set REPORT_EXACT_HPD = True below to print that as a
# separate column instead. Doing so requires result files produced by the
# current mebane_crosscheck.R, i.e. a re-run of the fits.
REPORT_EXACT_HPD = True   # exact joint 95% HPD of pi_2 + pi_3 (available in all current results)

HAS_EXACT = REPORT_EXACT_HPD \
    and {'fraud_share_hpd_lo', 'fraud_share_hpd_hi'}.issubset(df.columns) \
    and df['fraud_share_hpd_lo'].notna().any()
if REPORT_EXACT_HPD and not HAS_EXACT:
    print("NOTE: REPORT_EXACT_HPD is set but appendix_full_results.csv has no "
          "exact joint HPD columns; falling back to the conservative interval. "
          "Re-run the fits with the current mebane_crosscheck.R.")

elec_label = {'pres16': 'Pres02', 'pres17': 'Pres07', '18': 'Gen08', '19': 'Gen12',
              'pres18': 'Pres12', '20': 'Gen16', 'pres19': 'Pres17', '21': 'Gen20',
              'pres20': 'Pres22', '22': 'Gen24', 'pres21': 'Pres25'}
src_label = {'real': 'real', 'marginal_null': 'marg.null', 'joint_null': 'joint.null'}


def esc(s):
    # Use hyphens rather than escaped underscores for channel names: LaTeX can break
    # lines at hyphens but not at \_ in a narrow p{} column, which was causing overfull
    # hboxes for long names like total_no_early.
    return str(s).replace('_', '-')


def fmt_interval(lo, hi):
    if pd.isna(lo) or pd.isna(hi):
        return '--'
    return f"[{100*lo:.1f},{100*hi:.1f}]"


def fmt_rhat(v, conv):
    if pd.isna(v):
        return '--'
    marker = '' if not conv else '$^{*}$'
    return f"{v:.2f}{marker}"


def fmt_flagged(n, total):
    if pd.isna(n) or pd.isna(total) or total == 0:
        return '--'
    return f"{int(n)} ({100*n/total:.1f})"


# Column layout. Ten columns at the default \tabcolsep (6pt) overruns the 6.5in
# text block, so \tabcolsep is reduced inside the group and the p{} widths below
# are tuned to leave roughly 0.5cm of slack; the width check at the bottom of
# this script recomputes the total and fails loudly if it no longer fits.
TABCOLSEP_PT = 3.0
TEXTWIDTH_CM = 16.51  # 6.5in at 1in margins on letterpaper

if HAS_EXACT:
    COLSPEC = r"p{0.95cm}p{0.85cm}p{2.15cm}p{1.4cm}rrp{1.2cm}p{1.45cm}rc"
    PWIDTHS = [0.95, 0.85, 2.15, 1.4, 1.2, 1.45]
    AUTOWIDTHS = [0.85, 1.25, 1.55, 0.95]   # N, Flagged, F_w, Rhat
    HEADER = (r"Elec. & Level & Channel & Source & $N$ & Flag. (\%) & "
              r"Fraud \% & 95\% HPD & $F_w$ & $\hat{R}$ \\")
    NCOL = 10
else:
    COLSPEC = r"p{0.95cm}p{0.9cm}p{2.15cm}p{1.4cm}rrp{2.6cm}rc"
    PWIDTHS = [0.95, 0.9, 2.15, 1.4, 2.6]
    AUTOWIDTHS = [0.85, 1.25, 1.55, 0.95]
    HEADER = (r"Elec. & Level & Channel & Source & $N$ & Flag. (\%) & "
              r"Fraud \% [95\% CI] & $F_w$ & $\hat{R}$ \\")
    NCOL = 9

# The F_w column is omitted until the model-consistent fraudulent-vote counts
# from the full rerun are available (INCLUDE_FW=1 restores it).
INCLUDE_FW = os.environ.get('INCLUDE_FW', '1') == '1'   # model-consistent F_w (current results)
if not INCLUDE_FW:
    assert COLSPEC.endswith('rc')
    COLSPEC = COLSPEC[:-2] + 'c'          # drop the F_w column (the 'r' before R-hat)
    AUTOWIDTHS = [w for k, w in enumerate(AUTOWIDTHS) if k != 2]
    HEADER = HEADER.replace(r"$F_w$ & ", "")
    NCOL -= 1

EST_WIDTH_CM = sum(PWIDTHS) + sum(AUTOWIDTHS) + NCOL * 2 * TABCOLSEP_PT / 28.4527


def make_table(sub, caption, label):
    lines = []
    lines.append(r"{\footnotesize")
    lines.append(rf"\setlength{{\tabcolsep}}{{{TABCOLSEP_PT:g}pt}}")
    lines.append(rf"\begin{{longtable}}{{{COLSPEC}}}")
    lines.append(rf"\caption{{{caption}}} \label{{{label}}} \\")
    lines.append(r"\toprule")
    lines.append(HEADER)
    lines.append(r"\midrule")
    lines.append(r"\endfirsthead")
    lines.append(rf"\multicolumn{{{NCOL}}}{{c}}{{\tablename\ \thetable{{}} -- continued}} \\")
    lines.append(r"\toprule")
    lines.append(HEADER)
    lines.append(r"\midrule")
    lines.append(r"\endhead")
    lines.append(r"\bottomrule")
    lines.append(r"\endfoot")
    lvl_label = {'dong': 'dong', 'constituency': 'const.'}
    for _, row in sub.iterrows():
        e = elec_label.get(row['elec'], row['elec'])
        lvl = lvl_label.get(row['level'], row['level'])
        ch = esc(row['channel'])
        src = src_label.get(row['source'], row['source'])
        N = f"{int(row['n_units'])}" if not pd.isna(row['n_units']) else '--'
        flg = fmt_flagged(row.get('n_flagged', np.nan), row.get('n_units', np.nan))
        share = '--' if pd.isna(row['fraud_share']) else f"{100*row['fraud_share']:.2f}"
        cons = fmt_interval(row['fraud_share_lo'], row['fraud_share_hi'])
        fw = f"{row['Fw']:,.0f}" if not pd.isna(row['Fw']) else '--'
        rhat = fmt_rhat(row['rhat'], row['not_converged'])
        if HAS_EXACT:
            exact = fmt_interval(row.get('fraud_share_hpd_lo', np.nan),
                                 row.get('fraud_share_hpd_hi', np.nan))
            cells = [e, lvl, ch, src, N, flg, share, exact] + ([fw] if INCLUDE_FW else []) + [rhat]
        else:
            cells = [e, lvl, ch, src, N, flg, f"{share} {cons}"] + ([fw] if INCLUDE_FW else []) + [rhat]
        lines.append(" & ".join(cells) + r" \\")
    lines.append(r"\end{longtable}")
    lines.append(r"}")
    return '\n'.join(lines)


INTERVAL_NOTE = (
    " $N$ is the unit count and ``Flag.'' the number (and percentage) of units"
    " receiving a non-clean MAP classification."
    + (" The 95\\% HPD interval is the exact joint interval for the fraud share"
       " $\\pi_2+\\pi_3$, computed from the per-draw sum."
       if HAS_EXACT else
       " The bracketed interval is the conservative sum of the separate $\\pi_2$"
       " and $\\pi_3$ HPD bounds.")
    + (" $F_w$ is the posterior mean of the estimated number of fraudulent (manufactured plus"
       " stolen) votes implied by the model."
       if INCLUDE_FW else "")
)

blocks = []
specs = [
    ('new_settings', 'dem',
     "Short-chain configuration, Democratic-coded leader (n.iter=1000, burn.in=300, n.adapt=1000). "
     "Full coverage, all 11 elections." + INTERVAL_NOTE, "tab:app_new_dem"),
    ('new_settings', 'con',
     "Short-chain configuration, conservative-coded leader. Full coverage, all 11 elections."
     + INTERVAL_NOTE, "tab:app_new_con"),
]
for dataset, leader, caption, label in specs:
    sub = df[(df['dataset'] == dataset) & (df['leader_side'] == leader)].copy()
    elec_order = ['18', '19', 'pres16', 'pres17', 'pres18', '20', 'pres19', '21',
                  'pres20', '22', 'pres21']
    sub['eo'] = sub['elec'].map({e: i for i, e in enumerate(elec_order)})
    so = {'real': 0, 'marginal_null': 1, 'joint_null': 2}
    sub['so'] = sub['source'].map(so)
    sub = sub.sort_values(['eo', 'level', 'channel', 'so'])
    blocks.append(make_table(sub, caption, label))
    print(f"{dataset}/{leader}: {len(sub)} rows")

open('appendix_tables.tex', 'w').write('\n\n\\newpage\n\n'.join(blocks))
print(f"Written appendix_tables.tex ({NCOL} columns, "
      f"estimated width {EST_WIDTH_CM:.2f}cm of {TEXTWIDTH_CM:.2f}cm available)")
if EST_WIDTH_CM > TEXTWIDTH_CM:
    raise SystemExit("ERROR: estimated table width exceeds the text block; "
                     "reduce a p{} width or TABCOLSEP_PT above.")
